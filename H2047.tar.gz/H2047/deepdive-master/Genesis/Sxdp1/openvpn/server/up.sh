#!/bin/sh

ovs-vsctl --may-exist add-port br0 $1 -- set interface $1 ofport_request=3 > /tmp/openvpn-brdige.log
/usr/sbin/ifconfig $1 up

