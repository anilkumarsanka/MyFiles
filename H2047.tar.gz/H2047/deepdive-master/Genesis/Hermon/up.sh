#!/bin/bash

PORT=$1
/usr/sbin/ifconfig $PORT -arp up

/usr/sbin/ip route add 192.168.2.0/24 dev tap0

