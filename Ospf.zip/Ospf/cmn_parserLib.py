import string
from cmn_variableLib import cmn_variableLib
from robot.api import logger

class cmn_parserLib():

        ROBOT_LIBRARY_SCOPE = 'TEST SUITE'

        def __init__(self,devicedict):
                self.devicedict=devicedict
                self.dutsall=cmn_variableLib(self.devicedict)

        def parse_cmd(self,dut,cmd,out,**kwargs):
                lduts = self.dutsall		

                vendor=getattr(lduts,dut+"__type__Vendor")
                os=getattr(lduts,dut+"__type__os")
                file = "parser_"+vendor+"_"+os
                #print "FILE:",file
		

                parsermod=__import__(file)
		
                parserclass=getattr(parsermod,file)

		pobj=parserclass()
		#print "OBJ",pobj,dir(pobj)
		#print "OUTTT:",out
		#print "ARGS:",kwargs

                cmd=cmd.replace(" ","_")
                cmdnew=cmd.replace("-","_")
              #  print "NEW CMD:1",cmdnew
		

		parse_out=getattr(parserclass(),cmdnew)(out,kwargs)
            #    parse_out=eval("getattr(pobj,cmdnew)(out,kwargs)")
		#print "I PRINT:",parse_out
		#try:
	       #         parse_out=getattr(pobj,cmdnew)(out,kwargs)
		#except:
			#print "I GOT ERROR"
			
                
                #print "PARSED OUT:",parse_out

                return parse_out
