from robot.libraries.OperatingSystem import OperatingSystem
from robot.libraries.BuiltIn import BuiltIn
import re
import string 

class Tip_N3k_Basic_Config:	
	def __init__(self):
            self. config = ""
	    self.config_cmd={}
####%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%	    
	def create_vlan(self, VlanID):	    
	    self. config = ""
            self.config_cmd={}            					    
            for vlan in VlanID:          
                self.config = """
config
!
vlan vlanid 
!
end
!
"""
	   	self.config_cmd[vlan]=self.config.replace("vlanid", vlan)
	    return self.config_cmd
##########################################################################################
	def port_in_vlan(self, PortID, Mode, VlanID):	    
	    self. config = ""
            self.config_cmd={}             
 	    self.config = """
config
!
interface intf
!
no shutdown
!
switchport
!
switchport mode vlan vid
!
end
!
"""
            self.config_cmd[PortID] = self.config.replace("intf",PortID).replace("mode", Mode).replace("vid",VlanID)
	    return self.config_cmd
##########################################################################################                        
	def config_ip_address(self, Ip, Mask, Intf):	    
	    self. config = ""
            self.config_cmd={}
            self.config = """config
!
interface intf
!
no switchport
!
no shutdown
!
no ip address
!
ip address Ip/mask
!
end
!
"""
            self.config_cmd[Intf] = self.config.replace("intf", Intf).replace("Ip",Ip).replace("mask", Mask)
            return self.config_cmd

##########################################################################################        
        def config_bgp_router(self, PID):
	    self. config = ""
            self.config_cmd={}
            self.config = """config
!
router bgp pid
!
end
!
"""
            self.config_cmd[PID] = self.config.replace("pid", PID)
            return self.config_cmd

##########################################################################################        
        def config_bgp_neighbor(self, DPID, PPID, Ip, Desc, Intf):
	    self. config = ""
            self.config_cmd={}
            self.config = """config
!
router bgp dpid
!
neighbor Ip remote-as ppid
!
bfd
!
description Desc 
!
update-source intf
!
address-family ipv4 unicast
!
soft-reconfiguration inbound
!
end
!
"""
            self.config_cmd[Ip] = self.config.replace("dpid", DPID).replace("Ip", Ip).replace("ppid", PPID).replace("Desc", Desc).replace("intf", Intf)
	    return self.config_cmd
##########################################################################################	
	def shutdown_interface(self,Intf,flag):            
	    self.config = ""
            self.config_cmd={}
            if flag == 'shut':
		self.config = """
config
!
interface Intf 
!
shutdown
!
end
!
"""
            else:
	        self.config="""
config
!
interface Intf
!
no shutdown
!
end
!
"""
            self.config_cmd[Intf] = self.config.replace("Intf",Intf)    
            return self.config_cmd
#########################################################################################
	def add_port_in_portchannel(self,Ports,PCID):             
## PC : Port Channel            
	    self.config = ""
            self.config_cmd={}
	    PC = re.sub(r'([a-zA-Z]+)', "", PCID)
            for port in Ports:
		self.config = """
config
!
interface intf 
!
no shutdown
!
no channel-group
!
no switchport
!
channel-group pcid mode active
!
end
!
"""
            	self.config_cmd[port] = self.config.replace("intf",port).replace("pcid",PC)    
            return self.config_cmd
#############################################################################################        
	def enable_bfd_on_interface(self,Intfs):            
	    self.config = ""
            self.config_cmd={}
            for Intf in Intfs:
		self.config = """
config
!
interface intf 
!
no shutdown
!
bfd
!
end
!
"""
            	self.config_cmd[intf] = self.config.replace("intf", Intf)    
            return self.config_cmd
################################################################################################
	def config_logging_timestamp(self,Input):            
	    self.config = ""
            self.config_cmd={}
            self.config = """
config
!
logging timestamp input 
!
end
!
"""
            self.config_cmd[Input] = self.config.replace("input",Input)    
            return self.config_cmd
################################################################################################
	def config_sub_interface(self,Intf,Dot1Q):
            self.config = ""
            self.config_cmd={}
	    parent = re.search(r'([\d\w\/]+)\.(\d+)',Intf).group(1)
            self.config = """
config
!
interface prnt
!
no switchport
!
exit
!
interface intf
!
encapsulation dot1Q vlanId
!
end
!
"""
            self.config_cmd[Intf] = self.config.replace("intf",Intf).replace("prnt",parent).replace("vlanId",Dot1Q)
            return self.config_cmd
################################################################################################
	def config_hsrp_interface(self,Intf,Vrsn,RD,Id,Prmpt,Prty,HT,HoT,Ip,TO,Value):

	    ''' RT=Reload Delay,Prmpt=Preempt,Prty=Priority,HT=HelloTime,HoT=HoldTime,TO=TrackObject'''

            self.config = ""
            self.config_cmd={}
            self.config = """
config
!
feature hsrp
!
interface intf
!
no switchport
!
no shutdown
!
hsrp version vrsn
!
hsrp delay reload rd
!
hsrp id
!
preempt delay minimum pd
!
priority prty
!
timers ht hot
!
ip Ip 
!
track tro decrement value
!
end
!
"""
            self.config_cmd[Intf] = self.config.replace("intf",Intf).replace("vrsn",Vrsn).replace("rd",RD).replace("id",Id).replace("pd",Prmpt).replace("prty",Prty).replace("ht",HT).replace("hot",HoT).replace("Ip",Ip).replace("tro",TO).replace("value",Value)
            return self.config_cmd
################################################################################################

	def config_vrrp_interface(self,Intf,Id,Prty,Ip):

            self.config = " "
            self.config_cmd={}
            self.config = """
config
!
feature vrrp
!
interface intf
!
no switchport
!
no shutdown
!
vrrp id
!
priority prty
!
address Ip 
!
no shutdown
!
preempt
!
end
!
"""
            self.config_cmd[Intf] = self.config.replace("intf",Intf).replace("id",Id).replace("prty",Prty).replace("Ip",Ip)
            return self.config_cmd
######################################################################################################


#****************  UnConfig Procs ****************************************************************************************************************************************************

class Tip_N3k_Basic_Unconfig:

    def __init__(self):
	self.config_cmd={}
####%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%	    
    def delete_vlan(self, VlanID):

	self.config = ""
        self.config_cmd={}

        for vlan in VlanID:
            self.config = """
config
!
no vlan vlanid 
!
end
!
"""
	self.config_cmd[vlan]=self.config.replace("vlanid", vlan)
        return self.config_cmd
####################################################################################################	
    def remove_port_from_vlan(self, PortID, Mode, VlanID):

	self.config = ""
        self.config_cmd={}

        for port in PortID:
            for vlan in VlanID:
                self.config = """
config
!
interface intf
!
no shutdown
!
no switchport mode vlan vid
!
no switchport
!
end
!
"""
        self.config_cmd[vlan] = self.config.replace("intf", port).replace("mode", Mode).replace("vid", vlan)
        return self.config_cmd 
########################################################################################################                                        
    def delete_ip_address(self,Intf):

	self.config = ""
        self.config_cmd={}

        self.config = """
config
!
interface intf
!
no ip address
!
exit
!
no interface intf
!
end
!
"""
        self.config_cmd[Intf] = self.config.replace("intf", Intf)            
        return self.config_cmd
####################################################################################################        
    def remove_bgp_router(self, PID):

        self.config = ""
        self.config_cmd={}
		
        self.config = """
config
!
no router bgp pid
!
end
!
"""
        self.config_cmd = self.config.replace("pid", PID)
        return self.config_cmd
####################################################################################################        
    def remove_bgp_neighbor(self, DPID, PPID, Ip):
            # DPID = 'DUT Process ID'; PPID = 'Partner DUT process ID', Ip = 'Neighbor Ip address'

	self.config = ""
        self.config_cmd={}

        self.config = """
config
!
router bgp dpid
!
no neighbor ip remote-as ppid
!
end
!
"""
        self.config_cmd[Ip] = self.config.replace("dpid", DPID).replace("ip", Ip).replace("ppid", PPID)
        return self.config_cmd
################################################################################################
    def remove_port_from_portchannel(self,Ports,PCID):             
## PC : Port Channel            
	    self.config = ""
            self.config_cmd={}
	    PC = re.sub(r'([a-zA-Z]+)', "", PCID)
            for port in Ports:
		self.config = """
config
!
interface intf 
!
no shutdown
!
no channel-group
!
exit
!
no interface port-channel pcid 
!
end
!
"""
            	self.config_cmd[port] = self.config.replace("intf",port).replace("pcid",PC)    
            return self.config_cmd
#########################################################################################################
    def remove_sub_interface(self,Intf):
        self.config = ""
        self.config_cmd={}
        self.config = """
config
!
no interface intf
!
end
!
"""
        self.config_cmd[Intf] = self.config.replace("intf",Intf)
        return self.config_cmd
############################################################################################################  	
    def unconfig_hsrp_interface(self,Intf,Id,TO,Value):

            ''' RT=Reload Delay,Prmpt=Preempt,Prty=Priority,HT=HelloTime,HoT=HoldTime,TO=TrackObject'''

            self.config = ""
            self.config_cmd={}
            self.config = """
config
!
interface intf
!
no hsrp version
!
no hsrp delay reload
!
hsrp id
!
no preempt
!
no priority 
!
no timers
!
no ip 
!
no track tro decrement value
!
exit
!
no hsrp id
!
end
!
"""
            self.config_cmd[Intf] = self.config.replace("intf",Intf).replace("id",Id).replace("tro",TO).replace("value",Value)
            return self.config_cmd
################################################################################################

    def unconfig_vrrp_interface(self,Intf,Id):

        self.config = ""
        self.config_cmd={}
        self.config = """
config
!
interface intf
!
no vrrp id
!
end
!
"""
        self.config_cmd[Intf] = self.config.replace("intf",Intf).replace("id",Id)
        return self.config_cmd
############################################################################################
