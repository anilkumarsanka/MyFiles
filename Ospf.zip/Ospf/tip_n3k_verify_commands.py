import re
from robot.libraries.BuiltIn import BuiltIn
from robot.api import logger

class Verifications(object):
    def __init__(self):
        pass 

    def verify_show_bfd_neighbors(self,parsed_out,Intf,Status,*args):
        self.status = 0
        fail_count = 0
        BfdNeighborIntfs = []
        dict_in = parsed_out[1]
       
        try:
	    inputkeys = dict_in.keys() 
            for key in inputkeys:
                value = dict_in[key]
                BfdNeighborIntfs.append(value['Int'])
		if Intf != '':
		    if Status == 'Up':
		        if value['Int'] == Intf:
		            if value['State'] != 'Up':
			        print "FAIL: Interface %s status is not Up" % Intf
			        fail_count += 1
		    if Status == 'Down':
			if value['Int'] == Intf:
			    if value['State'] != 'Down':
			        print "FAIL: Interface %s status is not Down" % Intf
			        fail_count += 1
		else:
		    if value['State'] != 'Up':
			print "FAIL: Bfd status is not Up for the interface %s", value['Int']
			fail_count += 1
            if Status == 'Up':
		if Intf not in BfdNeighborIntfs:
                    print "FAIL: provided interface  %s is not present in show bfd neighbors output" % Intf
		    fail_count += 1

	except Exception, self.errors:
            print "ERROR in verification of \"show bfd neighbors\"\n:",self.errors
            self.status = 0

        if fail_count == 0:
            self.status  = 1

	return self.status





