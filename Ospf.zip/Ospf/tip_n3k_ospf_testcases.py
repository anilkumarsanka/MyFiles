from cmn_genericLib import cmn_genericLib
from cmn_deviceLib import cmn_deviceLib
from robot.libraries.Collections import Collections
from robot.libraries.BuiltIn import BuiltIn
from cmn_parserLib import cmn_parserLib
from ixialib import *
import time
import re
from tip_n3k_verify_commands  import Verifications
from tip_n3k_config import Tip_N3k_Basic_Config
from tip_n3k_config import Tip_N3k_Basic_Unconfig
from robot.api import logger
class Tip_N3k_Ospf_00001:

    def setup(self):
        self.dutall = BuiltIn().get_variable_value('${Common.DeviceList}')
        self.devicedetails=BuiltIn().get_variable_value('${Devices}')

    def test(self):
        self.failed_steps_count=0
        duts = self.dutall
        obj = Tip_N3k_Basic_Config()
	obj1=cmn_parserLib(self.devicedetails)
########################################## Configuring Ospf Between two Nodes ##################
	cmn_genericLib().robolog("\n<b><font face=\"verdana\" color=\"blue\">Section-50.01: Verifying Ospf neighborship between %s and %s</b>"%(duts[0],duts[1]),html=1)
	for dut in duts:
	    if dut == duts[0]: nbrip = self.ip_2;intf = self.intf_1
	    if dut == duts[1]: nbrip = self.ip_1;intf = self.intf_1	   
	    cmn_genericLib().robolog("\n<b><font face=\"verdana\" color=\"SaddleBrown\">Verifying for Ospf neighborship to be \'Full\'on device %s</b>" % dut, html = 1)
            show_ospf_nbrs = self.dh.dut_command([dut],self.shospfnbrs)
            parseresult1 = obj1.parse_cmd(dut,'show ip ospf neighbors',show_ospf_nbrs)                
            if parseresult1[0]:
	        ospfnbrs = parseresult1[1].keys()
	        count = 0
	        for nbr in ospfnbrs:
		    if nbr == nbrip:
		        count = 1
		        if parseresult1[1][nbr]['Neibhor_State'].find("FULL") != -1: 
			    cmn_genericLib().robolog("\n<b><font face=\"verdana\" color=\"green\">Command %s output verification passed Ospf neighborship is 'Full' on interface %s</b>" % (self.shospfnbrs,intf),html = 1)
		        else:
		            cmn_genericLib().robolog("\n<b><font face=\"verdana\" color=\"red\">FAIL: Command %s output verification failed: Ospf neighborship is not 'Full' on interface %s</b>" % (self.shospfnbrs,intf),html = 1)
			    self.failed_steps_count+=1
                if count != 1:
		    cmn_genericLib().robolog("\n<b><font face=\"verdana\" color=\"red\">FAIL: ospf neighbor entry not formed on interface interface %s</b>" % intf, html = 1)  
                    self.failed_steps_count+=1
            else:
                cmn_genericLib().robolog("\n<b><font face=\"verdana\" color=\"red\">FAIL: Parsing %s output failed </b>" % self.shospfnbrs, html = 1)
                self.failed_steps_count+=1                    
            if self.failed_steps_count:
                BuiltIn().run_keyword_and_continue_on_failure("fail",(str(self.failed_steps_count))+" test steps failed")
################################ Ixia Configuration ###################################
	neighbors,prefixes,routes = [],[],[]
	route_range = {}
        fields = (re.split('\.',self.ixintfip))
        firstthree = '.'.join((fields[0],fields[1],fields[2]))
	fourth = int(fields[3])
	bytes = (re.split('\.',self.ospfintfrrexternalprefixstart))
	firsttwo = '.'.join((bytes[0],bytes[1]))
	third = int(bytes[2])
	lastbyte = int(bytes[3])
	for count in range(self.neighbor_count):
	    nbrid = '.'.join((firstthree,str(fourth)))
	    neighbors.append(nbrid)
	    fourth += 1
            nbrprfx = '.'.join((firsttwo,str(third),bytes[3]))
	    prefixes.append(nbrprfx)
	    lastbyte = int(bytes[3])
	    rrange = []
	    for route in range(self.routespernbr):
	        newroute = '.'.join((firsttwo,str(third),str(lastbyte)))
		routes.append(newroute)
		rrange.append(newroute)
		lastbyte += 1
	    third += 1
	    route_range[nbrid] =  rrange
	router_ids = neighbors   
	for area in self.areas:	
	    if area == self.areas[0]:
                cmn_genericLib().robolog("\n<b><font face=\"verdana\"color=\"blue\">Section-50.02: Configuring Ospf neighbors on Ixia side for area %s</b>"%area,html=1)
            if area == self.areas[1]:
                cmn_genericLib().robolog("\n<b><font face=\"verdana\"color=\"blue\">Section-50.05: Configuring Ospf neighbors on Ixia side for area %s</b>"%area,html=1)
	    cmn_genericLib().robolog("\n<font face=\"verdana\" color=\"DarkMagenta\">configuring ospf protocol interfaces with area-id %s both on device and  ixia" % area, html = 1)
	    configospf = '\nconfig\ninterface vintf\nip router ospf pid area arid\nip ospf authentication message-digest\nip ospf  message-digest-key md5keyid md5 md5key\nend'
	    configospf = configospf.replace('vintf',self.intf_2).replace('arid', area).replace('pid', self.pid).replace('md5keyid',self.md5keyid).replace('md5key',self.md5key)
            config_ospf = self.dh.dut_command([duts[0]],configospf)
	    ospfintfbrf = self.dh.dut_command([duts[0]],'show ip ospf interface brief')
            shipospf = self.dh.dut_command([duts[0]],'show ip ospf')
	    cmn_genericLib().robolog("\nConnecting to traffic generator" )
	    self.portlist = self.ixintf
	    a = Ixia(self.chassisip,self.tclsrvrip,self.ixtclsrvr,self.portlist)
	    res = a.TGN_Connect_python()
	    cmn_genericLib().robolog("\nconnected to ixia chassis %s" % self.chassisip)
            lst = re.split('\.',self.chassisip)
            num = len(lst)
            strg = "res['port_handle']"
            for i in range(0, num):
	        strg += "['"+lst[i]+"']"
	    var1 = strg+"['"+self.ixintf+"']"
	    port_handle = res.get('vport_list')
	    var = 0
	    for nbrip in neighbors:
		cmn_genericLib().robolog("\nCreating ospf protocol interface with ip address %s" % nbrip)
	        res1 = a.Interface_Config(port_handle,nbrip,self.ixintfmsk,self.ixintfgw,self.ixintfvlantyp,"protocol_interface")
	        res_ospf = a.Ospf_Config (port_handle,nbrip,self.dutip,self.ospfconfmode,nbrip,self.ospfconfvlan,self.ospfconfsessiontype,self.ospfintfprefixlen,self.ospfconfareatype,self.ospfconfnetworktype,area,'md5',self.md5key,self.md5keyid)
		ospf_handle = res_ospf['handle']
		cmn_genericLib().robolog("\nadding %s routes on ospf neighbor %s on ixia side" %(route_range[nbrip],nbrip))
		res_topology_routerange = a.Ospf_Topology_Routerange_Summary_prefix(self.ospfintfrrangemode,ospf_handle,'1',self.ospfintfrrexternalprefixlength,self.ospfintfrrexternalprefixmetric,prefixes[var],self.ospfintfrrexternalnumberofprefix,self.ospfintfrrtype,self.ospfsummaryroutestype)
		var += 1
            cmn_genericLib().robolog("\n<font face=\"verdana\" color=\"DarkMagenta\">starting ospf protocol on ixia interface %s" % self.ixintf, html = 1)
	    a.Tgn_Start_Protocol()
	    cmn_genericLib().robolog("\n<b><font face=\"verdana\" color=\"SaddleBrown\">Verifying for Ospf neighborship with ixia interfaces to be \'Full\'on device %s</b>" % duts[0], html = 1)
	    #time.sleep(20)
    	    timer=0
	    while (timer <= 20):
	        flag = 0
		time.sleep(5)
	        shipospfnbrs  = self.dh.dut_command([duts[0]],'show ip ospf neighbors')
                parseresult2 = obj1.parse_cmd(duts[0],'show ip ospf neighbors',shipospfnbrs)
                if parseresult2[0]:
                    nbrs = parseresult2[1].keys()
		    if set(router_ids)<=set(nbrs):
		        for rid in router_ids:
		            if parseresult2[1][rid]['Neibhor_State'].find("FULL") != -1:
                                continue
		            else:
			        flag += 1
				break
		    else:
			flag += 1
		else:
                    cmn_genericLib().robolog("\n<b><font face=\"verdana\" color=\"red\">FAIL: Parsing %s output failed </b>" % self.shospfnbrs, html = 1)
                    self.failed_steps_count+=1
		if flag != 0:
		    timer += 5
		else:
		    cmn_genericLib().robolog("\n<b><font face=\"verdana\" color=\"green\">All the ospf neighbors on Ixia formed neighborship with on %s</b>" % duts[0],html = 1)
		    break
			       
            if flag != 0:
		cmn_genericLib().robolog("\n<b><font face=\"verdana\" color=\"red\">FAIL: All or some of ospf neighbors on Ixia not formed neighborship with on %s</b>" % duts[0],html = 1)
	        self.failed_steps_count+=1
            if self.failed_steps_count:
                BuiltIn().run_keyword_and_continue_on_failure("fail",(str(self.failed_steps_count))+" test steps failed")
#######################################################################################################################
	    if area == self.areas[0]:
		cmn_genericLib().robolog("\n<b><font face=\"verdana\" color=\"blue\">Section-50.03: Injecting routes from Ixia for ospf area id %s" % area,html = 1 )
	    if area == self.areas[1]:
                cmn_genericLib().robolog("\n<b><font face=\"verdana\" color=\"blue\">Section-50.07: Injecting routes from Ixia for ospf area id %s" % area,html = 1 )
	    time.sleep(5)
	    for dut in duts:
		cmn_genericLib().robolog("\n<font face=\"verdana\" color=\"DarkMagenta\">Verifying routes injected from ixia on %s routing table" % dut,html = 1)
  	        show_ip_route_ospf = 'show ip route ospf-pid'
	        show_ip_route_ospf = show_ip_route_ospf.replace('pid',self.pid)
                showiprouteospf = self.dh.dut_command([dut],show_ip_route_ospf,timeout = 30)
                parseresult3 = obj1.parse_cmd(dut,'show ip route',showiprouteospf)
                if parseresult3[0]:
                    injected_routes = parseresult3[1].keys()
                    if len(routes)<=len(injected_routes):
		        cmn_genericLib().robolog("\n<b><font face=\"verdana\"color=\"green\">All the routes injected from ixia neighbors are learnt on %s</b>" % dut,html=1)
	            else:
                        cmn_genericLib().robolog("\n<b><font face=\"verdana\"color=\"red\">FAIL: All or some of routes injected from ixia are not learned on %s</b>" % dut,html = 1)
                        self.failed_steps_count+=1
                else:
                    cmn_genericLib().robolog("\n<b><font face=\"verdana\" color=\"red\">FAIL: Parsing %s output failed </b>" % show_ip_route_ospf, html = 1)
                    self.failed_steps_count+=1
                if self.failed_steps_count:
                    BuiltIn().run_keyword_and_continue_on_failure("fail",(str(self.failed_steps_count))+" test steps failed")
#########################################################################################################################
            if area == self.areas[0]:
	        cmn_genericLib().robolog("\n<b><font face=\"verdana\"color=\"blue\">Section-50.04: Removing Ospf neighbors on Ixia for ospf area id %s" %area,html = 1 )
	        cleanupport=a.Cleanup_ports(port_handle)
                timer=0
		cmn_genericLib().robolog("\n<font face=\"verdana\"color=\"DarkMagenta\">Verifying ospf neighbors on device %s after removing neighbors on ixia side"%duts[0],html=1)
                while (timer <= 50):
                    flag = 0
                    time.sleep(10)
                    shipospfnbrs  = self.dh.dut_command([duts[0]],'show ip ospf neighbors')
                    parseresult4 = obj1.parse_cmd(duts[0],'show ip ospf neighbors',shipospfnbrs)
                    if parseresult4[0]:
                        nbrs = parseresult4[1].keys()
                        for rid in router_ids:
                            if rid in nbrs:
				flag += 1
                                break
			    else:
				continue
		    else:
                        cmn_genericLib().robolog("\n<b><font face=\"verdana\" color=\"red\">FAIL: Parsing %s output failed </b>" % show_ip_route_ospf, html = 1)
			self.failed_steps_count+=1
		    if flag != 0:
			timer += 10
		    else:
			cmn_genericLib().robolog("\n<b><font face=\"verdana\"color=\"green\">All the neighbors removed on device %s as expected after entries removed on ixia side</b>" % duts[0],html = 1)
			break
		if flag != 0:
		    cmn_genericLib().robolog("\n<font face=\"verdana\"color=\"red\">FAIL: All or some of neighbors not removed on device %s even after entries removed on ixia side" % duts[0],html = 1)
		    self.failed_steps_count+=1
		if self.failed_steps_count:
                    BuiltIn().run_keyword_and_continue_on_failure("fail",(str(self.failed_steps_count))+" test steps failed")
####################################i####################################################################################
	cmn_genericLib().robolog("\n<b><font face=\"verdana\" color=\"blue\">Section-50.08: Creating,Applying and Removing route-maps</b>", html = 1)
	ipprfxlist = []
	for nbrid in neighbors:
	    ipprfxlist.append(route_range[nbrid][0])
	    ipprfxlist.append(route_range[nbrid][-1])
	cmn_genericLib().robolog("\n<b><font face=\"verdana\" color=\"SaddleBrown\">Creating ip prefix list on device %s</b>" % duts[0], html = 1)
	for prfx in ipprfxlist:
	    ippfrxcmnd = '\nconfig\nip prefix-list filter-ospf seq seqnbr deny prfxid/32 mask 255.255.255.255\nend'
	    seqnbr = ipprfxlist.index(prfx)+10
	    ippfrxcmnd = ippfrxcmnd.replace('prfxid', prfx).replace('seqnbr',str(seqnbr))
	    cmnd  = self.dh.dut_command([duts[0]],ippfrxcmnd)
	ippfrxcmnd = '\nconfig\nip prefix-list filter-ospf seq 100 permit 0.0.0.0/0 le 32\nend'
	cmnd  = self.dh.dut_command([duts[0]],ippfrxcmnd)
	cmn_genericLib().robolog("\n<b><font face=\"verdana\" color=\"SaddleBrown\">Creating route-map on device %s to filter below routes \n%s</b>" % (duts[0],ipprfxlist), html = 1)
	cnfgrmp = '\nconfig\nroute-map filter-ospf permit 10\nmatch  ip address prefix-list filter-ospf\nend'
	cnfgrmp = self.dh.dut_command([duts[0]],cnfgrmp)
	cmn_genericLib().robolog("\n<b><font face=\"verdana\" color=\"SaddleBrown\">Applying route-map on device %s</b>" % duts[0], html = 1)
	applyroutemap = '\nconfig\nrouter ospf pid\narea areaid filter-list route-map filter-ospf in\narea areaid filter-list route-map filter-ospf out\nend'
	applyroutemap = applyroutemap.replace('areaid', self.areas[0]).replace('pid', self.pid)
	rmcmnd = self.dh.dut_command([duts[0]],applyroutemap)
	shrm = self.dh.dut_command([duts[0]],'show route-map')
	shipprfxlist = self.dh.dut_command([duts[0]],'show ip prefix-list')
        shipospf = self.dh.dut_command([duts[0]],'show ip ospf')
	cmn_genericLib().robolog("\n<b><font face=\"verdana\" color=\"SaddleBrown\">Verifying routes on %s after applying route-map on %s</b>" % (duts[1],duts[0]), html = 1)
	time.sleep(10)
        showiprouteospf = self.dh.dut_command([duts[1]],show_ip_route_ospf,timeout = 30)
	parseresult5 = obj1.parse_cmd(duts[1],'show ip route',showiprouteospf)
	if parseresult5[0]:
	    learned_routes = parseresult5[1].keys()
	    for route in ipprfxlist:
		if route in learned_routes:
		    cmn_genericLib().robolog("\n<b><font face=\"verdana\" color=\"red\">FAIL: route %s not filtered on %s even after applying route-map on %s</b>" % (route,duts[1],duts[0]), html = 1)
		    self.failed_steps_count+=1			    		       
	else:
            cmn_genericLib().robolog("\n<b><font face=\"verdana\" color=\"red\">FAIL: Parsing %s output failed </b>" % show_ip_route_ospf, html = 1)
            self.failed_steps_count+=1		
        if self.failed_steps_count:
            BuiltIn().run_keyword_and_continue_on_failure("fail",(str(self.failed_steps_count))+" test steps failed")
	else:
	    cmn_genericLib().robolog("\n<b><font face=\"verdana\"color=\"green\">routes properly filtered on device %s as per route-map configuration</b>" % duts[1],html=1)
#########################################################################################################################################################
	cmn_genericLib().robolog("\n<b><font face=\"verdana\" color=\"blue\">Section-50.09: Removing Applied route-maps</b>", html = 1)
	removeroutemap = '\nconfig\nrouter ospf pid\nno area areaid filter-list route-map filter-ospf in\nno area areaid filter-list route-map filter-ospf out\nend'
        removeroutemap = removeroutemap.replace('areaid', self.areas[0]).replace('pid', self.pid)
        removeroutemap = self.dh.dut_command([duts[0]],removeroutemap)
	time.sleep(1)
	shipospf = self.dh.dut_command([duts[0]],'show ip ospf')
	cmn_genericLib().robolog("\n<b><font face=\"verdana\" color=\"SaddleBrown\">Verifying routes on %s after removing route-map on %s</b>" % (duts[1],duts[0]), html = 1)
	time.sleep(10)
	showiprouteospf = self.dh.dut_command([duts[1]],show_ip_route_ospf,timeout = 30)
        parseresult6 = obj1.parse_cmd(duts[1],'show ip route',showiprouteospf)
        if parseresult6[0]:
            learned_routes = parseresult6[1].keys()
            for route in routes:
                if route not in learned_routes:
                    cmn_genericLib().robolog("\n<b><font face=\"verdana\"color=\"red\">FAIL: All the routes not re-learned on device %s after route-map removed on %s</b>" % (duts[1],duts[0]),html=1)
                    self.failed_steps_count+=1                    
        else:
            cmn_genericLib().robolog("\n<b><font face=\"verdana\" color=\"red\">FAIL: Parsing %s output failed </b>" % show_ip_route_ospf, html = 1)
            self.failed_steps_count+=1
	if self.failed_steps_count:
            BuiltIn().run_keyword_and_continue_on_failure("fail",(str(self.failed_steps_count))+" test steps failed")
        else:
            cmn_genericLib().robolog("\n<b><font face=\"verdana\"color=\"green\">All the routes re-learned on device %s after route-map removed on %s</b>" % (duts[1],duts[0]),html=1)

##****************************************************************************************

    def cleanup(self):
	duts=self.dutall
        cmn_genericLib().robolog("\n<b><font face=\"verdana\" color=\"blue\">Section-50.10: Restoring configuration to original on %s</b>" % self.dutall[0], html = 1)
	cmn_genericLib().robolog("\n<font face=\"verdana\" color=\"DarkMagenta\">configuring ospf protocol interface with area-id %s on device" %self.areas[0],html=1)
        configospf = '\nconfig\ninterface vintf\nip router ospf pid area arid\nip ospf authentication null\nno ip ospf  message-digest-key md5keyid md5 md5key\nend'
        configospf = configospf.replace('vintf',self.intf_2).replace('arid', self.areas[0]).replace('pid', self.pid).replace('md5keyid',self.md5keyid).replace('md5key',self.md5key)
        config_ospf = self.dh.dut_command([duts[0]],configospf)
	cmn_genericLib().robolog("\n<font face=\"verdana\"color=\"DarkMagenta\">removing ip prefix list and route-map configuration on device %s"%self.dutall[0],html=1)
	cmnds = '\nconfig\nno ip prefix-list filter-ospf\nno route-map filter-ospf\nend'
	cmnds = self.dh.dut_command([duts[0]],cmnds)
	shrm = self.dh.dut_command([duts[0]],'show route-map')
        shipprfxlist = self.dh.dut_command([duts[0]],'show ip prefix-list')
	shipospf = self.dh.dut_command([duts[0]],'show ip ospf')
	ospfintfbrf = self.dh.dut_command([duts[0]],'show ip ospf interface brief')

#############################################################################################################


class Testcases(object):

    def testcase7_initialize(self):
        tcobject = Tip_N3k_Ospf_00001()
        tcobject.id = BuiltIn().get_variable_value('${Testcases.Testcase7.id}')
	tcobject.shospfnbrs = BuiltIn().get_variable_value('${Testcases.Testcase7.shospfnbrs}')
	tcobject.shospfdb = BuiltIn().get_variable_value('${Testcases.Testcase7.shospfdb}')
        tcobject.ip_1 = BuiltIn().get_variable_value('${Testcases.Testcase7.ip_1}')
        tcobject.ip_2 = BuiltIn().get_variable_value('${Testcases.Testcase7.ip_2}')
	tcobject.dutip = BuiltIn().get_variable_value('${Testcases.Testcase7.ixportip}')
        tcobject.mask = BuiltIn().get_variable_value('${Testcases.Testcase7.mask}')
	tcobject.intf_1 = BuiltIn().get_variable_value('${Testcases.Testcase7.intf_1}')
	tcobject.intf_2 = BuiltIn().get_variable_value('${Testcases.Testcase7.intf_2}')
	tcobject.pid = BuiltIn().get_variable_value('${Testcases.Testcase7.pid}')
	tcobject.areas = BuiltIn().get_variable_value('${Testcases.Testcase7.areas}')
	tcobject.neighbor_count = BuiltIn().get_variable_value('${Testcases.Testcase7.neighbor_count}')
	tcobject.routespernbr = BuiltIn().get_variable_value('${Testcases.Testcase7.routespernbr}')
	tcobject.md5key = BuiltIn().get_variable_value('${Testcases.Testcase7.md5key}')
	tcobject.md5keyid = BuiltIn().get_variable_value('${Testcases.Testcase7.md5keyid}')
        tcobject.dutall = BuiltIn().get_variable_value('${Common.DeviceList}')
        tcobject.dh = BuiltIn().get_variable_value('${dutobj}')

	tcobject.chassisip = BuiltIn().get_variable_value('${Devices.Device_6.chassis.ip}')
	tcobject.tclsrvrip = BuiltIn().get_variable_value('${Devices.Device_6.tclserver.ip}')
	tcobject.ixtclsrvr = BuiltIn().get_variable_value('${Devices.Device_6.ixtclserver.ip}')

        tcobject.ixintf = BuiltIn().get_variable_value('${Traffic_streams.Strm0001.TGPORT}')
        tcobject.ixintfip = BuiltIn().get_variable_value('${Traffic_streams.Strm0001.TGIP}')	
        tcobject.ixintfmsk = BuiltIn().get_variable_value('${Traffic_streams.Strm0001.TGMSK}')
        tcobject.ixintfgw = BuiltIn().get_variable_value('${Traffic_streams.Strm0001.TGGW}')
        tcobject.ixintfvlantyp = BuiltIn().get_variable_value('${Traffic_streams.Strm0001.TGVLANTYP}')      
	tcobject.ospfconfmode  = BuiltIn().get_variable_value('${Traffic_streams.Strm0001.OSPFCONFMODE }')	
	tcobject.ospfconfvlan  = BuiltIn().get_variable_value('${Traffic_streams.Strm0001.OSPFCONFVLAN }')
	tcobject.ospfconfsessiontype  = BuiltIn().get_variable_value('${Traffic_streams.Strm0001.OSPFCONFSESSIONTYPE }')
	tcobject.ospfintfprefixlen  = BuiltIn().get_variable_value('${Traffic_streams.Strm0001.OSPFINTPREFIXLEN }')
	tcobject.ospfconfareatype  = BuiltIn().get_variable_value('${Traffic_streams.Strm0001.OSPFCONFAREATYPE }')
	tcobject.ospfconfnetworktype  = BuiltIn().get_variable_value('${Traffic_streams.Strm0001.OSPFCONFNETWORKTYPE }')
       	tcobject.ospfintfrrangemode  = BuiltIn().get_variable_value('${Traffic_streams.Strm0001.OSPFINTRRANGEMODE }')
	tcobject.ospfintfrrexternalprefixlength  = BuiltIn().get_variable_value('${Traffic_streams.Strm0001.OSPFINTRREXTERNALPREFIXLENGTH }')
	tcobject.ospfintfrrexternalprefixmetric  = BuiltIn().get_variable_value('${Traffic_streams.Strm0001.OSPFINTRREXTERNALPREFIXMETRIC }')
	tcobject.ospfintfrrexternalprefixstart  = BuiltIn().get_variable_value('${Traffic_streams.Strm0001.OSPFINTRREXTERNALPREFIXSTART }')	
	tcobject.ospfintfrrexternalnumberofprefix  = BuiltIn().get_variable_value('${Traffic_streams.Strm0001.OSPFINTRREXTERNALNUMBEROFPREFIX }')
	tcobject.ospfintfrrtype  = BuiltIn().get_variable_value('${Traffic_streams.Strm0001.OSPFINTRRTYPE }')
	tcobject.ospfsummaryroutestype  = BuiltIn().get_variable_value('${Traffic_streams.Strm0001.OSPFSUMMARYROUTESTYPE }')


	
	return tcobject

    def testcase_setup(self,tcobj):
	tcobj.setup()

    def testcase_test(self,tcobj):
 	tcobj.test()

    def testcase_cleanup(self,tcobj):
 	tcobj.cleanup()

