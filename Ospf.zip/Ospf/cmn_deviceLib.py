import re
import pdb
from cmn_genericLib import cmn_genericLib
from cmn_variableLib import cmn_variableLib
from robot.api import logger
from Exscript import protocols, Host, Account

class cmn_deviceLib():

    ROBOT_LIBRARY_SCOPE = 'TEST SUITE'

    def __init__(self,devicedict):
	self.devicedict=devicedict
	dutsall=self.dutsall=cmn_variableLib(self.devicedict)
	#self.dutsall=cmn_variableLib(devicedict).dutvariables()

    def __call__(self):
	dutsall=self.dutsall=cmn_variableLib(devicedict).dutvariables()

    def dut_connect(self,dutlist):
	results=[]
	for dut in dutlist:
		results += [self._dut_connect(dut)]
	_connect_status=reduce((lambda x,y: x*y), results)
	return _connect_status
	
    def _dut_connect(self,dut):
	_dut_connect_result=1
        lduts=self.dutsall

        _user=getattr(lduts,dut+"__tacacs__username")
        _pwd=getattr(lduts,dut+"__passwords__tacacs")
        _ip=getattr(lduts,dut+"__connectivity__terminal__ip")
        _loginprompt=getattr(lduts,dut+"__tacacs__login_prompt")
       	_pwdprompt=getattr(lduts,dut+"__tacacs__password_prompt")
	_protocol=getattr(lduts,dut+"__connectivity__terminal__protocol")

	account = Account(_user,_pwd)
        if _protocol == "ssh":
                _conn = protocols.SSH2()
                #_conn = protocols.SSH2(debug=5)
		#import logging
		#logging.basicConfig(level=logging.DEBUG)
        elif _protocol == "telnet":
                _conn = protocols.Telnet()
	else:
		print "DUT CONNECT FAILED - incorrect protocol value"
		_dut_connect_result=0

	_conn.set_username_prompt(_loginprompt)
	_conn.set_password_prompt(_pwdprompt)

	_prompt=getattr(lduts,dut+"__prompt")
        _conn.set_prompt(_prompt)

	_conn.connect(_ip)
	_conn.login(account)  
	setattr(lduts,dut+"__handle",_conn)

	return _dut_connect_result

    def dut_disconnect(self,dutlist):
	for dut in dutlist:
		self._dut_disconnect(dut)
	
    def _dut_disconnect(self,dut):
	lduts=self.dutsall
	_conn=getattr(lduts,dut+"__handle")
	_conn.send('exit\r')               
	_conn.close()  

    def dut_command(self,dutlist,cmd,prompt=None,timeout=30,operation="execute",error_prompt=None,splitlines=True):
	dutout={}
        for dut in dutlist:
                dutout[dut]=self._dut_command(dut,cmd,prompt,timeout,operation,error_prompt,splitlines)
	if len(dutlist)==1: return dutout[dutlist[0]]
	return dutout

    def _dut_command(self,dut,cmd,prompt=None,timeout=30,operation="execute",error_prompt=None,splitlines=True):
        lduts=self.dutsall

	_output=""
        _conn=getattr(lduts,dut+"__handle")
	_conn.set_timeout(timeout)
        _conn.set_prompt(prompt)
	_conn.set_error_prompt(error_prompt)
	if splitlines:
	    _cmds=[c.strip() for c in cmd.splitlines()]
	else:
	    _cmds=[cmd]
	for _cmd in _cmds:
	    if operation=="send":
		_conn.send(_cmd)
	    elif operation=="sendline":
		_conn.send(_cmd+"\r")
	    elif operation=="execute":
	 	_conn.execute(_cmd)
	    else:
		cmn_genericLib().robolog("Unknown operation. Must be one of send/sendline/execute or do not pass the argument",console=1)
	    _output+=_conn.response
	cmn_genericLib().robolog("Command response:\n"+_output,console=0)
	#print "Command response:\n"+_output
	setattr(lduts,dut+"__output",_output)
	setattr(cmn_deviceLib,dut+"__output",_output)
	_conn.response=""

	return _output

