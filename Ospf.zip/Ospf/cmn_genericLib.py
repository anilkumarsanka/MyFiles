import re
from robot.libraries.OperatingSystem import OperatingSystem
import yaml
from robot.libraries.BuiltIn import BuiltIn
from robot.api import logger

class cmn_genericLib():

    def get_dictionary_variable(self,dct, keys1):
        keys = re.split(r"\.",keys1)
        SENTRY = object()
        def getter(level, key):
            return 'NA' if level is SENTRY else level.get(key, SENTRY)
        return reduce(getter, keys, dct)

    def get_input_variables(self,file_name):
        yaml_out=OperatingSystem().get_file(file_name)
        obj=yaml.load(yaml_out)
	self.devicedict=obj
        return obj

    def clean(self,inp):
    	str1=""
	#print inp
	#print "*********"
    	inp1=inp.split("\n")
    	for i in inp1:
		#print i
        	i=i.lstrip().rstrip()
        	if i is not None:
            		i=i+str("\n")
            		str1+=i
    	str1=str1.lstrip().rstrip()
	#print str1
    	return str1

    # Log: True/1 or False/0	: To toggle printing the output on the screen
    def robolog(self,messages,gui=True,level="INFO",console=False,html=False,repr=False,log=True):
        if not(log): return
        if gui:
            BuiltIn().log(messages,level=level,console=console,html=html,repr=repr)
        elif console:
            for msg in messages.split(","): logger.console(msg)

