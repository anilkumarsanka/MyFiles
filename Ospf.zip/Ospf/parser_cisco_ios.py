import re
import string

class parser_cisco_ios(object):

    def __init__(self):
        pass   

    def show_bfd_neighbors(self,output="GETCMD",*args):
       # Setting Variables
       self.outputdict = {}
       self.status = 0
       values = []
       tmp_dic = {}

       # Reading command output, else EXECUTING
       if output=="GETCMD":
          # Get command output by running the get_cmd proc
          # self.status,command_out = self.get_cmd("show bfd neighbors")
          # Display error and exit incase of error in command execution
          pass
       else:
          command_out = output
          self.status = 1
       # Displaying the command output details (comment it, only for debugging)
       #print "Output:",command_out
       #print "Status:",self.status
       print "\n\nDUT command output:\n",command_out
             
       # Parsing the command output, getting the key-value pairs
       #print ("\nParsing command output")
       try:
          lines = command_out.split("\n")
	  r = re.compile(r'^([\d\.]+)\s+([\d\.]+)\s+([\d\/]+)\s+([a-z]+)\s+([\w\/\(\)]+)\s+([a-z]+)\s+([a-z\/\d\.]+)\s+([a-z]+)\s*',re.IGNORECASE)
          for line in lines:
	      if line == '': continue
	      for i in range(len(lines)):
                  result = re.search(r,lines[i])
                  if result !=None:
                      tmp_dic = {"OurAddr":result.group(1),"NeighAddr":result.group(2),"LD/RD":result.group(3), "RH/RS": result.group(4), "Holdown(mult)":result.group(5),"State":result.group(6),"Int":result.group(7),"Vrf": result.group(8)}
                      self.outputdict[result.group(1)] = tmp_dic
              self.status = 1

       except Exception, self.errors:
          print "Parsing 'show bfd neighbors' command failed:\n", self.errors
          self.status = 0

       #if self.outputdict == {}:
        #   print("*HTML*<font face=\"verdana\" color=\"red\">\n\nERROR:</font> Parsed dictionary is empty")

          # print ("*HTML*<font face=\"verdana\" color=\"red\">\n\nERROR:</font> Parsed dictionary is empty")
       #else:
          # print "\nPARSED OUTPUT:\n",self.outputdict
       return self.status,self.outputdict


    def show_port_channel_summary(self,output="GETCMD",*args):
        self.outputdict = {}
        self.status = 0
        
        if output=="GETCMD":
            # Get command output by running the get_cmd proc
            # commandStatus,commandOut = self.get_cmd("show version")
            # Display error and exit incase of error in command execution
            pass
        else:
            command_out = output
            self.status = 1
            print "Parsing command output"
        try:
            lines = command_out.split("\n")
            pattern = re.compile(r'([\d]+)\s+(Po.*?)\s+(\w+)\s+(\w+)\s+(.+)', re.IGNORECASE)
            for line in lines:
                if line == '': continue
                match = re.search(pattern, line)
                if match != None:
                    ports = match.group(5).split()
                    self.outputdict[match.group(2)] = {'Group':match.group(1), 'Port-Channel':match.group(2),'Type':match.group(3),'Protocol':match.group(4),'Member Ports':ports}
                    self.status = 1
                else:
                    pass
        except Exception, self.errors:
            print "\n ERROR in parsing show port-channel summary command", self.errors
            self.status = 0
            
        return self.status,self.outputdict

    def show_clock(self,output="GETCMD",*args):

        self.outputdict = {}
        self.outputdict['clock_out']={}
        self.status=0
        
        if output=="GETCMD":

            # Get command output by running the get_cmd proc
            # self.status,command_out = self.get_cmd("show logging")
            # Display error and exit incase of error in command execution
            pass
        else:
            command_out = output
            self.status = 1
            #~ DISPLAYING the command output details (comment it, only for debugging)
            # print "Output:",self.outputdict
            # print "Status:",self.status
            
            #~ PARSING command output, getting the key-value pairs
        try:
            lines = output.split('\n')	
            for line in lines:
                if line == '':continue
                match = re.search('([\d\:\.]+)\s+([\w]+)\s+([\w]+)\s+([\w]+)\s+([\d]+)\s+([\d]+)',line)
                if match != None:
                    self.outputdict['clock_out'] = {'time':match.group(1),'day':match.group(3),'month':match.group(4),'date':match.group(5),'year':match.group(6)}
                    self.status = 1
        except Exception, self.errors:
            print "ERROR in parsing \"show logging\":\n",self.errors
            self.status = 0

        return self.status,self.outputdict


    def show_logging_time_based(self,output="GETCMD",*args):

	self.outputdict={}
        self.status=0
	SysClock = ''
      
        clock_times = re.search('(\d+)\:(\d+)\:(\d+)\.(\d+)', SysClock).groups()
        count = 0

        if output=="GETCMD":

            # Get command output by running the get_cmd proc
            # self.status,command_out = self.get_cmd("show logging")
            # Display error and exit incase of error in command execution
            pass
        else:
            command_out = output
            self.status = 1
            #~ DISPLAYING the command output details (comment it, only for debugging)
            # print "Output:",self.outputdict
            # print "Status:",self.status
            #~ PARSING command output, getting the key-value pairs

        try:
            
            lines = output.split('\n')
            for line in lines:
                match = re.search('([\d]+)\s+([\w]+)\s+\d\s+([\d\:\.]+)\.*',line)
                if match!=None:
                    time = match.group(3)
                    match_times = re.search('(\d+)\:(\d+)\:(\d+)\.(\d+)', time)
                    if match_times != None:
                        if list(match_times.groups())[1] >= list(clock_times)[1]:
                            self.outputdict[count]= line
                            count += 1
	     
	    print "\ntotal number of log messages filtered are:", count                                                       
            self.status=1
                            
        except Exception, self.errors:
            print "ERROR in parsing \"show logging\":\n",self.errors
            self.status = 0

        return self.status,self.outputdict

    def show_hsrp_brief(self,output="GETCMD",*args):
        # Setting Variables
        self.outputdict = {}
        self.status = 0
        # Reading command output, else EXECUTING
        if output=="GETCMD":
           # Get command output by running the get_cmd proc
           # self.status,command_out = self.get_cmd("show bfd neighbors")
           # Display error and exit incase of error in command execution
           pass
        else:
            command_out = output
            self.status = 1
        flag=0
        try:
            lines = command_out.split("\n")
            for line in lines:
                if line !='':
		    words = line.split()
		    if len(words)>1:
                        key = words[0]
                        if key=='Interface':
                            flag=1
                            continue
                        if flag==1:
                            self.outputdict[key] = {"Interface":words[0],"Grp":words[1],"Prio":words[2],"P":words[3],"State":words[4],"Active":words[5],"StandBy":words[6],"Group":words[7]}
            self.status = 1

        except Exception, self.errors:
            print "Parsing 'show hsrp brief' command failed:\n", self.errors
            self.status = 0
        return self.status,self.outputdict

    def show_vrrp(self,output="GETCMD",*args):
        # Setting Variables
        self.outputdict = {}
        self.status = 0
        # Reading command output, else EXECUTING
        if output=="GETCMD":
           # Get command output by running the get_cmd proc
           # self.status,command_out = self.get_cmd("show bfd neighbors")
           # Display error and exit incase of error in command execution
           pass
        else:
            command_out = output
            self.status = 1
        try:
            lines = command_out.split("\n")
            for line in lines:
                if line !='':
                    match = re.search(r'([\w\/]+)\s+(\d+)\s+(\w+)\s+(\d+)\s+(\d+\s\w)\s+(\w)\s+(\w+)\s+([\d\.]+)',line)
                    if match != None:
                        self.outputdict[match.group(1)] = {"Interface":match.group(1),"VR":match.group(2),"IPVersion":match.group(3),"Priority":match.group(4),"Time":match.group(5),"Preempt":match.group(6),"State":match.group(7),"VRIP":match.group(8)}
            self.status = 1

        except Exception, self.errors:
            print "Parsing 'show vrrp' command failed:\n", self.errors
            self.status = 0
        return self.status,self.outputdict

    def show_logging(self,output="GETCMD",*args):
        self.outputdict={}
        self.status=0
        fail_count = 0
        flag = 0
        ip = ""
        lis = []
        if output=="GETCMD":
            # Get command output by running the get_cmd proc
            # self.status,command_out = self.get_cmd("show logging")
            # Display error and exit incase of error in command execution
            pass
        else:
            command_out = output
            #~ DISPLAYING the command output details (comment it, only for debugging)
            # print "Output:",self.outputdict
            # print "Status:",self.status
            #~ PARSING command output, getting the key-value pairs
        print "\n\nDUT command output is:\n", output
        print "\n\nParsing command output"
        try:
            inp = command_out.split('\n')
           

           
            flag=0
            
            l2=[]
            for i in inp:
                #print "i is ", i
                result1=re.search('^(Logging\s+[ \w\-]+)\s*:\s+([\w\(\)\:\s]+)',i.strip(),re.I)
                
                if result1!=None:
                    if result1.group(1).strip() == "Logging logfile":                      
                        self.outputdict[result1.group(1).strip()]= {}
                        self.outputdict[result1.group(1).strip()]['status']= result1.group(2)
                    elif result1.group(1).strip() == "Logging server":
                        self.outputdict[result1.group(1).strip()]= {}
                        self.outputdict[result1.group(1).strip()]['status']= result1.group(2)
                    else:                        
                        self.outputdict[result1.group(1).strip()]= result1.group(2)

                
                result2=re.search(r'(Name)\s*-\s*(\w+)\s*:\s*([a-z]+)\s*-\s*([a-z]+)\s+([a-z]+)\s*-\s*(\w+)',i.strip(),re.I)
                if result2!=None:
                   
                    self.outputdict['Logging logfile'][result2.group(1)]=result2.group(2)
                    self.outputdict['Logging logfile'][result2.group(3)]=result2.group(4)
                    self.outputdict['Logging logfile'][result2.group(5)]=result2.group(6)

                    

                res=re.search('(Facility)\s+(Default Severity)\s+(Current Session Severity)',i.strip())
                if res!=None:
                    name=res.group(1)
                    self.outputdict[name]={}
                result3=re.search(r'([\w\_\-\\]+)\s+(\d+)\s+(\d+)$',i.strip(),re.I)
                if result3!=None:       
                    self.outputdict['Facility'][result3.group(1).strip()] = {"Default severity" :result3.group(2).strip(), "Current Session Severity" : result3.group(3).strip()}


                

                '''result6=re.search('(\d+\(\w+\)).+',i)
                if result6!=None:
                    s =result6.group().strip()
                    l2.append(s)
                    self.outputdict['notifications']=l2'''

                result5=re.search(r'(\d{4}\s+\w{3}\s+\d+).+',i)
                if result5!=None:
                    k=result5.group()
                    lis.append(k)
                    self.outputdict['Log']= lis


                result4 = re.search(r'^{(\d+\.\d+\.\d+\.\d+)}$',i.strip())
                if result4 !=None:
                    ip = result4.group(1)
                    self.outputdict['Logging server'][ip] = {}
                    flag +=1
                    l =[]

                    continue

                if flag > 0:
                    if i.find("Logging logfile") != -1:
                        flag = 0                        
                        
                    else:
                        l.append(i.strip())                       
                     

                    if len(l) != 0:        
                        for j in range(len(l)):
                            if l[0].find("unreachable") != -1:
                                self.outputdict['Logging server'][ip]['Server status'] = l[0].strip()
                            self.outputdict['Logging server'][ip]['server ip'] = ip
                            if l[j].find(":") != -1:
                                self.outputdict['Logging server'][ip][(l[j].split(':')[0]).strip()] = (l[j].split(':')[1]).strip()


        except Exception, self.errors:
            print("*HTML*<font face=\"verdana\" color=\"red\">\n\nERROR:</font> Parsing 'show logging':\n", self.errors)
            fail_count += 1

        if self.outputdict == {}:
            print ("*HTML*<font face=\"verdana\" color=\"red\">\n\nERROR:</font> Parsed dictionary is empty")
            fail_count += 1
        else:
            print "\n\nThe parsed output is:\n",self.outputdict
        if fail_count == 0:
           self.status = 1
        return self.status,self.outputdict

    def show_ip_ospf_neighbors(self,output="GETCMD",*args):
        self.outputdict = {}
        self.status = 0
        fail_count = 0    
        if output=="GETCMD":
            # Get command output by running the get_cmd proc
            # self.status,command_out = self.get_cmd("show ip ospf neighbors")
            # Display error and exit incase of error in command execution
            pass
        else:
            command_out = output
        #print "\n\nDUT command output:\n",command_out
        #print "\n\nParsing command output"
        command_out = output.split("\n")
        parse_out = {}         
        try:            
            PID_VRF = re.search(r'OSPF Process ID\s+([\d]+)\s+VRF\s+([\w]+)', output)
            Total_Neibhors = re.search(r'Total.*\:\s+([\d]+)', output)
            if PID_VRF != None:
                parse_out['Process_ID'] = OspfDetails = PID_VRF.group(1)
                parse_out['VRF_ID'] = PID_VRF.group(2)
            if Total_Neibhors != None:
                parse_out['Total_Neibhors'] = Total_Neibhors.group(1)
                self.outputdict[OspfDetails] = parse_out
            parse_out = {}
            r = re.compile(r'([\d\.]+)\s+([\d]+)\s+([\w\/]+)\s+([\w\W]+)\s+([\d\.]+)\s+([\w\d\/\.]+)',re.IGNORECASE)
            for line in command_out:
                if line == '': continue                               
                result = re.search(r,line.strip())
                print 
                if result != None:
                    parse_out['Neibhor_ID'] = NeighborID = result.group(1)
                    parse_out['Neibhor_Priority'] = NeibhorPriority = result.group(2)
                    parse_out['Neibhor_State'] = NeibhorState = result.group(3)
                    parse_out['Neibhor_UpTime'] = NeibhorUpTime = result.group(4)
                    parse_out['Neibhor_IP'] = NeibhorIP = result.group(5)
                    parse_out['Neibhor_Intf'] = NeibhorIntf = result.group(6)
                    self.outputdict[NeibhorIP] = parse_out
                    parse_out = {}
                 
                    
        except Exception, self.errors:
            print("*HTML*<font face=\"verdana\" color=\"red\">\n\nERROR:</font> Parsing 'show ip ospf  neighbors' command failed:\n", self.errors)
            fail_count += 1
        
        #if self.outputdict == {}:
            #print ("*HTML*<font face=\"verdana\" color=\"red\">\n\nERROR:</font> Parsed dictionary is empty")
         #   fail_count += 1
       # else:
        #    print "\n\nThe parsed output is:\n",self.outputdict  

        if fail_count == 0:
           self.status = 1
        return self.status,self.outputdict

    def show_ip_bgp_summary(self,output="GETCMD",*args):
        self.outputdict={}
        self.status=0
        flag = 0
	if output=="GETCMD":
            # Get command output by running the get_cmd proc
            # self.status,command_out = self.get_cmd("show ip ospf neighbors")
            # Display error and exit incase of error in command execution
            pass
        else:
            command_out = output
	#print "input to the parser", output
        try:
            lines = command_out.split('\n')
	    #print "lines", lines
            for line in lines:
                if line != '' and line != '\r':
                    words = line.split()
		    if len(words) > 1:
		        #print "words", words
                        if words[0] == 'Neighbor':
			    #print "neighbpr line matched"
                            flag = 1
                            continue
                        if flag == 1:
                            self.outputdict[words[0]] = {'Neighbor':words[0],'AS':words[2],'State':words[-1]}
			    #print "self.outputdict", self.outputdict
	    self.status=1
        except Exception,self.errors:
            print("*HTML*<font face=\"verdana\" color=\"red\">\n\nERROR:</font> Parsing 'show ip bgp summary':\n", self.errors)
            self.status=0            
        return self.status,self.outputdict


    def show_ip_route(self,output="GETCMD",*args):
        self.outputdict={}
        self.status=0
        fail_count = 0
        try:
            lines = output.split('\n')
            for line in lines:
                if line == '': continue
                if re.search('([\d\.]+)', line) != None:
                     routes =  re.search('([\d\.]+)', line).group(0)
                     self.outputdict[routes] = {'route':routes}
        except Exception,self.errors:
            print("*HTML*<font face=\"verdana\" color=\"red\">\n\nERROR:</font> Parsing 'show ip bgp summary':\n", self.errors)
            fail_count += 1            
        if fail_count == 0:
           self.status = 1
        return self.status,self.outputdict
