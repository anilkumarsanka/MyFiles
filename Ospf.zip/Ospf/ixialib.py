import Tkinter
import time
import pdb  
import sys
import os
import yaml
sys.path.append(os.getcwd() + "/temp")

global tcl
global count
global num_calls
count = 1;
num_calls = 1;
tcl = Tkinter.Tcl()
res = tcl.eval('source ixialib.tcl')
#res1 = tcl.eval('source TGN_NewCreateStreams1.tcl')
#res = tcl.eval('source  remove_stream.tcl')
#res1 = tcl.eval('source TGN_collect_stats.tcl')

class Ixia(object):

        def __init__(self,device,tcl_server,ixnetwork_tcl_server,port_list):

                self.device = device
                self.tcl_server = tcl_server
                self.ixnetwork_tcl_server = ixnetwork_tcl_server
                self.port_list = port_list

	def TGN_Connect_python(self):

		global tcl
		global num_calls
		direct_name = os.getcwd()
		directory = direct_name + "/temp"
		if not os.path.exists(directory):
			os.makedirs(directory)
		result = tcl.eval('set result [TGN_Connect {'+self.device+'} {'+self.tcl_server+'} {'+self.ixnetwork_tcl_server+'} {'+self.port_list+'}]')
		import TGN_Connect 
		from TGN_Connect import func1
		c = func1()
		str = "From TGN Connect python method"
		num_calls += 1
		return c

	def Interface_Config(self,port,intf_ip_address,netmask,gateway,vlan='0',l23_config_type='protocol_interface'):

		global tcl
		global port_handlel
		global count
		global num_calls
		result = tcl.eval('set result [Int_Config {'+port+'} {'+intf_ip_address+'} {'+netmask+'} {'+gateway+'} {'+vlan+'} {'+l23_config_type+'} ]') 
		sys.path.append(os.getcwd() + "/temp")
		var = "Inter_Config_" + repr(count)
		i = __import__(var)
		mycode ='c = i.func' + repr(num_calls) + '()'
		exec(mycode)
		count += 1;
		num_calls += 1;
		str = "From Interface Config python method"
		return c

        def Interface_Config_Ipv6(self,port,ipv6_address, ipv6_prefix, ipv6_gateway, vlan='0', l23_config_type='protocol_interface'):

                global tcl
                global port_handlel
                global count
                global num_calls
                result = tcl.eval('set result [Int_Config_Ipv6 {'+port+'} {'+ipv6_address+'} {'+ipv6_prefix+'} {'+ipv6_gateway+'} {'+vlan+'} {'+l23_config_type+'} ]')
                sys.path.append(os.getcwd() + "/temp")
                var = "Inter_Config_Ipv6" + repr(count)
                i = __import__(var)
                mycode ='c = i.func' + repr(num_calls) + '()'
                exec(mycode)
                count += 1;
                num_calls += 1;
                str = "From Interface Config python method"
                return c


	def Emulation_Bgp_Config(self,int_handle,port_handle,ip, remoteip, localas, local_routerid, mode, neighbor_type,ipv4_unicast_nlri="true",ipv4_multicast_nlri="true",ipv4_mpls_vpn_nlri="true",ipv4_mpls_nlri="true", md5enabel ='0', md5_key='null'):

		global tcl
		global port1
		global count
		global num_calls
                pdb.set_trace()
		result = tcl.eval('set result [Bgp_Config {'+int_handle+'} {'+port_handle+'} {'+ip+'} {'+remoteip+'} {'+localas+'} {'+local_routerid+'} {'+mode+'} {'+neighbor_type+'} {'+ipv4_unicast_nlri+'} {'+ipv4_multicast_nlri +'} {'+ipv4_mpls_vpn_nlri+'} {'+ipv4_mpls_nlri +'} {'+md5enabel+'} {'+md5_key+'} ]')
                pdb.set_trace()
		sys.path.append(os.getcwd() + "/temp")
		var = "Bgp_Config_" + repr(count)
		i = __import__(var)
		mycode ='c = i.func' + repr(num_calls) + '()'
		exec(mycode)
		count += 1;
		num_calls += 1;
		str = "From Emulation Bgp Config"
		print str
		return c
   
	"""def Emulation_Bgp_Route_Config(self,handles, mode, ipversion, prefix, prefixfrom, prefixto, origin, as_path_set_mode, numroutes='1', enable_route_flap='1', flap_down_time='1', flap_up_time='1', enable_as_path):

		global tcl
		global handle2
		global count
		global num_calls
		result = tcl.eval('set result [Bgp_Router_Config {'+handles+'} {'+mode+'} {'+ipversion+'} {'+prefix+'} {'+prefixfrom+'} {'+prefixto+'} {'+origin+'} {'+as_path_set_mode+'} {'+numroutes+'} {'+enable_route_flap+'} {'+flap_down_time+'} {'+flap_up_time+'} {'+enable_as_path+'} ]')
		sys.path.append(os.getcwd() + "/temp")
		var = "Bgp_Emu_Router_Con_" + repr(count)
		i = __import__(var)
		mycode ='c = i.func' + repr(num_calls) + '()'
		exec(mycode)
		count += 1;
		num_calls += 1;
		str = "From Emulation Bgp Config router"
		print str
		return c"""

	def Traffic_Conf(self,mode, source, destination,circuit_type, mac_souc, mac_dest, name, l3protocol, ipsrc, ipdest, l2encap, trackby,rate_percent,rate_pps):

		global tcl
		global porthandle2
		global count
		global num_calls
		result = tcl.eval('set result [Traffic_Conf {'+mode+'} {'+source+'} {'+destination+'} {'+rate_percent+'} {'+circuit_type+'} {'+mac_souc+'} {'+mac_dest+'} {'+name+'} {'+l3protocol+'} {'+ipsrc+'} {'+ipdest+'} {'+l2encap+'} {'+rate_pps+'} ]')
		sys.path.append(os.getcwd() + "/temp")
		var = "TrafficConf_" + repr(count)
		i = __import__(var)
		mycode ='c = i.func' + repr(num_calls) + '()'
		exec(mycode)
		count += 1;
		num_calls += 1;

		str = "From Traffic Config "
		print str
		return c


        def Traffic_Conf_BGP(self,mode, emulation_src_handle, emulation_dst_handle, transmit_mode, circuit_endpoint_type,name, src_dest_mesh, route_mesh, circuit_type, stream_packing , rate_percent,  length_mode, l2_encap, mac_dst, mac_src, l3_protocol):

                global tcl
                global porthandle2
                global count
                global num_calls
                result = tcl.eval('set result [Traffic_Conf_BGP {'+mode+'} {'+emulation_src_handle+'} {'+emulation_dst_handle+'} {'+transmit_mode+'} {'+circuit_endpoint_type+'} {'+name+'} {'+src_dest_mesh+'} {'+route_mesh+'} {'+circuit_type+'} {'+stream_packing+'} {'+rate_percent+'} {'+length_mode+'} {'+l2_encap+'} {'+mac_dst+'} {'+mac_src+'} {'+l3_protocol+'}]')
                sys.path.append(os.getcwd() + "/temp")
                var = "TrafficConf_bgp" + repr(count)
                i = __import__(var)
                mycode ='c = i.func' + repr(num_calls) + '()'
                exec(mycode)
                count += 1;
                num_calls += 1;

                str = "From Traffic Config "
                print str
                return c

	def Cleanup_ports(self,port_handle):

		global tcl
		global count
		global num_calls
		result = tcl.eval('set result [ Cleanup_ports {'+port_handle+'}]')
		sys.path.append(os.getcwd() + "/temp")
		var = "TGN_Cleanup_Ports_" + repr(count)
		i = __import__(var)
		mycode ='c = i.func' + repr(num_calls) + '()'
		exec(mycode)
		count += 1;
		num_calls += 1;
		str = "From TGN Cleanup session"
		print str
		return c

	def TGN_Cleanup_Session():

		global tcl
		result = tcl.eval('set result [Cleanup_Session {}]')
		import t
		from t import func3
		c = func3()
		str = "From TGN Cleanup session python method"
		print str
		return c

	def BGP_Config(self,inthandle,remoteip,routerid):
		result = tcl.eval('set result [Emul_BGP_Config  result {'+inthandle+'} {'+remoteip+'} {'+routerid+'}]')
		return result

	def Traffic_Config_python(self,stream_id):
		result = tcl.eval('set result [Traffic_Config {'+stream_id+'}]')
		return result

	def Start_Stop_Traffic(self,action):
		result = tcl.eval('set result [Control_Traffic {'+action+'}]')
		return result

	def Tgn_Start(self,value,port_handle):

		global count
		global num_calls
		#result = tcl.eval('set result [Tgn_Start_Protocol {}]')
		result = tcl.eval('set result [Tgn_Start_Traffic {'+port_handle+'}]')
		time.sleep(float(value))
		var = "Tgn_Start_" + repr(count)
		i = __import__(var)
		mycode ='c = i.func' + repr(num_calls) + '()'
		exec(mycode)
		count += 1;
		num_calls += 1;
		return result

	def Tgn_Start_Protocol(self):
		global count
		global num_calls
		result = tcl.eval('set result [Tgn_Start_Protocol {}]')
                time.sleep(10)
		return result

	def Tgn_Stop_Protocol(self):
		global count
		global num_calls
		result = tcl.eval('set result [Tgn_Stop_Protocol {}]')
		return result

	def Tgn_Stop(self):

		global count
		global num_calls
		#result = tcl.eval('set result [Tgn_Stop_Protocol {}]')
		result = tcl.eval('set result [Tgn_Stop_Traffic {}]')
		#import sys
		#import os
		sys.path.append(os.getcwd() + "/temp")
		var = "Tgn_Stop_" + repr(count)
		i = __import__(var)
		#pdb.set_trace()
		mycode ='c = i.func' + repr(num_calls) + '()'
		exec(mycode)
		count += 1;
		num_calls += 1;
		return result


	def Tgn_Stats(self,mode,port):

		global count
		global num_calls
		result = tcl.eval('set result [Tgn_Stats {'+mode+'} {'+port+'}]')
		sys.path.append(os.getcwd() + "/temp")
		var = "TGN_Stats_" + repr(count)
		i = __import__(var)
		mycode ='c = i.func' + repr(num_calls) + '()'
		exec(mycode)
		count += 1;
		num_calls += 1;
		str = "From Tgn Stats"
		print str
                #f = open("/home/kkodanda/test1")
                #dataMap = yaml.safe_load(f)
                #f.close()
		return c 
                #return dataMap
        
        def Tgn_Stats_Collect(port_list):
        
        	global count
    		global num_calls
    		result = tcl.eval('set result [TGN_collect_stats {'+port_list+'} {'+mode+'}]')
    		sys.path.append(os.getcwd() + "/temp")
    		var = "TGN_Stats_" + repr(count)
    		i = __import__(var)
    		mycode ='c = i.func' + repr(num_calls) + '()'
    		exec(mycode)
    	        count += 1;
    		num_calls += 1;
    		str = "From Tgn Stats"
    		print str
    		return c

	def Traffic_Clear_Stats(self,porthandle):

		global count
		global num_calls
		result = tcl.eval('set result [Traffic_Clear_Stats {'+porthandle+'}]')
		sys.path.append(os.getcwd() + "/temp")
		var = "Traffic_Clear_Stats_" + repr(count)
		i = __import__(var)
		mycode ='c = i.func' + repr(num_calls) + '()'
		exec(mycode)
		count += 1;
		num_calls += 1;
		return result

	def Ospf_Config (self,port_handle,intf_ip_addr,neighbor_intf_ip_addr,mode,router_id,vlan,session_type,intf_prefix_length,area_type,network_type,areaid,authentication_mode='null',md5_key='null',md5_key_id='1',optionbits='000002'): 

		global tcl 
		global count 

		global num_calls 
		result = tcl.eval('set result [Ospf_Config  {'+port_handle+'} {'+intf_ip_addr+'} {'+neighbor_intf_ip_addr+'}   {'+mode+'}   {'+router_id+'}   {'+vlan+'}   {'+session_type+'}   {'+intf_prefix_length+'}   {'+area_type+'}   {'+network_type+'} {'+areaid+'} {'+optionbits+'} {'+authentication_mode+'}   {'+md5_key+'}   {'+md5_key_id+'}]') 
	
		sys.path.append(os.getcwd() + "//temp")
		var = "Ospf_Config_" + repr(count) 
		i = __import__(var) 
		mycode ='c = i.func' + repr(num_calls) + '()' 
		exec(mycode) 
		count += 1 
		num_calls += 1 
		return c

	def Ospf_Topology_Intf_Config (self,handle,interface_ip_address,interface_ip_mask,interface_mode2,mode,type,link_type,neighbor_router_id,grid_link_type,grid_col,grid_row,grid_router_id,grid_router_id_step,grid_prefix_start,grid_prefix_length,grid_prefix_step,areaid ): 

		global tcl 
		global count 
		global num_calls 
		result = tcl.eval('set result [Ospf_Topology_Intf_Config  {'+handle+'}  {'+interface_ip_address+'}  {'+interface_ip_mask+'}  {'+interface_mode2+'}  {'+mode+'}  {'+type+'}  {'+link_type+'}  {'+neighbor_router_id+'}  {'+grid_link_type+'}  {'+grid_col+'}  {'+grid_row+'}  {'+grid_router_id+'}  {'+grid_router_id_step+'}  {'+grid_prefix_start+'}  {'+grid_prefix_length+'}  {'+grid_prefix_step+'} {'+areaid+'}]') 
		sys.path.append(os.getcwd() + "//temp")
		var = "Ospf_Topology_Intf_Config_" + repr(count) 
		i = __import__(var) 
		mycode ='c = i.func' + repr(num_calls) + '()' 
		exec(mycode) 
		count += 1 
		num_calls += 1 
		return c
 
 
	def Ospf_Topology_Routerange_Config (self,mode,handle,count1,external_prefix_length,external_prefix_metric,external_prefix_start,external_number_of_prefix,type,external_prefix_type ): 

		global tcl 
		global count 
		global num_calls 
		result = tcl.eval('set result [Ospf_Topology_Routerange_Config  {'+mode+'}  {'+handle+'}  {'+count1+'}  {'+external_prefix_length+'}  {'+external_prefix_metric+'}  {'+external_prefix_start+'}  {'+external_number_of_prefix+'}  {'+type+'}  {'+external_prefix_type+'} ]') 
		sys.path.append(os.getcwd() + "//temp")
		var = "Ospf_Topology_Routerange_Config_" + repr(count) 
		i = __import__(var) 
		mycode ='c = i.func' + repr(num_calls) + '()' 
		exec(mycode) 
		count += 1 
		num_calls += 1 
		return c
 
 
	def Ospf_Topology_Routerange_Summary_prefix (self,mode,handle,count1,summary_prefix_length,summary_prefix_metric,summary_prefix_start,summary_number_of_prefix,type, summary_route_type ):

		global tcl 
		global count 
		global num_calls 
		result = tcl.eval('set result [Ospf_Topology_Routerange_Summary_prefix  {'+mode+'}  {'+handle+'}  {'+count1+'}  {'+summary_prefix_metric+'}  {'+summary_prefix_start+'}  {'+type+'}  {'+summary_route_type+'}  {'+summary_prefix_length+'}  {'+summary_number_of_prefix+'} ]') 
		sys.path.append(os.getcwd() + "//temp")
		var = "Ospf_Topology_Routerange_Config_" + repr(count) 
		i = __import__(var) 
		mycode ='c = i.func' + repr(num_calls) + '()' 
		exec(mycode) 
		count += 1 
		num_calls += 1 
		return c

	def Emulation_Ospf_Lsa_Config(self,mode,port_handle,type,areaid,sessiontype,lsagroupmode):

		global tcl
		global port1
		global count
		global num_calls
		result = tcl.eval('set result [Ospf_Lsa_Config {'+mode+'} {'+port_handle+'} {'+type+'} {'+areaid+'} {'+sessiontype+'} {'+lsagroupmode+'}]')
		var = "Ospf_lsa_config_" + repr(count)
		i = __import__(var)
		mycode ='c = i.func' + repr(num_calls) + '()'
		exec(mycode)
		count += 1;
		num_calls += 1;
		str = "From Emulation Ospf Lsa Config"
		print str
		return c

        def TGN_removeStreams(self,streams,port_handle):

                global tcl
                global port_handlel
                global count
                global num_calls
                print "IN TGN remove streams "
               #print "in JJJJJJJJJJJJHHHHHHHHHHHHEEEEEEEEEEELLLLLLLLLLOOOOOOOOOOOO"
                result = tcl.eval('set result [TGN_removeStreams {'+streams+'} {'+port_handle+'} {"ixia"}]')
                sys.path.append(os.getcwd() + "/temp")
                #var = "TGN_nfig_" + repr(count)
                #i = __import__(var)
                #mycode ='c = i.func' + repr(num_calls) + '()'
                #exec(mycode)
                #count += 1;
                #num_calls += 1;
                str = "From TGN_removeStreams"
                print str
                return result
         
        def TGN_createStreams(self,txPort,emulation_src_handle,emulation_dst_handle):
            
        	global tcl
                global port1
                global count
                global num_calls
                result = tcl.eval('set result [TGN_createStreams {'+txPort+'} {'+emulation_src_handle+'} {'+emulation_dst_handle+'}]')
                sys.path.append(os.getcwd() + "/temp")
                var = "TGN_createStreams_" + repr(count)
                i = __import__(var)
                mycode ='c = i.func' + repr(num_calls) + '()'
                exec(mycode)
                count += 1;
                num_calls += 1;
                str = "From TGN createStreams python method"
                return c 







