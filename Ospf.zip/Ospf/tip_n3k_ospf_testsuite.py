from cmn_genericLib import cmn_genericLib
from cmn_deviceLib import cmn_deviceLib
from robot.libraries.Collections import Collections
from robot.libraries.BuiltIn import BuiltIn
class TestSuite:
    def suite_setup(self):
	print("Establising connection to the test devices")
	#print(BuiltIn().get_variable_value('${Devices}')) 
	dh = cmn_deviceLib(BuiltIn().get_variable_value('${Devices}'))
	dh.dut_connect(BuiltIn().get_variable_value('${Common.DeviceList}'))
  	BuiltIn().set_global_variable('${dutobj}',dh)
	print(dh.dut_command(BuiltIn().get_variable_value('${Common.DeviceList}'),"term len 0"))
    def suite_cleanup(self):
	print("Releasing the connection established to the test devices")
        #print(BuiltIn().get_variable_value('${Devices}'))
        dh = BuiltIn().get_variable_value('${dutobj}')
        dh.dut_disconnect(BuiltIn().get_variable_value('${Common.DeviceList}'))
