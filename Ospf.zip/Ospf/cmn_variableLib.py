class cmn_variableLib():
        def __init__(self,dutsdetails):
                self.dutsdetails=dutsdetails
                self.dutslist=[]
                self.dutvariables()

        def dutvariables(self):
		keys=self.dutsdetails.keys()
                for dut in keys:
       	                self.dutslist+=[dut]
               	        setattr(self,dut,self._dutvariables(dut,self.dutsdetails[dut],dut))

	def _dutvariables(self,dut,dutdetails,parentattr=""):
              self.dut=dut
              for attr in dutdetails.keys():
			newattr=attr if parentattr=="" else parentattr+"__"+attr
			if isinstance(dutdetails[attr],dict)!=True:
                       		setattr(self,newattr,dutdetails[attr])
			else:
				self._dutvariables(dut,dutdetails[attr],newattr)
                
