import re
from robot.libraries.OperatingSystem import OperatingSystem
import yaml
from robot.libraries.BuiltIn import BuiltIn
from robot.api import logger

class genericLib():

    def get_dictionary_variable(self,dct, keys1):
        keys = re.split(r"\.",keys1)
        SENTRY = object()
        def getter(level, key):
            return 'NA' if level is SENTRY else level.get(key, SENTRY)
        return reduce(getter, keys, dct)

    def get_input_variables(self,file_name):
        yaml_out=OperatingSystem().get_file(file_name)
        obj=yaml.load(yaml_out)
	self.devicedict=obj
        return obj

    # Log: True/1 or False/0	: To toggle printing the output on the screen
    def robolog(self,messages,gui=True,level="INFO",console=False,html=False,repr=False,log=True):
        if not(log): return
        if gui:
	    if type(messages) is list: messages=",".join(map(str,messages))
            BuiltIn().log(messages,level=level,console=console,html=html,repr=repr)
        elif console:
	    for message in messages:
                for msg in message.split(","): logger.console(msg)

