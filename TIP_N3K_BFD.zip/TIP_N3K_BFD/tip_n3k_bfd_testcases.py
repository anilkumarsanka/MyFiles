from robot.libraries.Collections import Collections
from robot.libraries.BuiltIn import BuiltIn
from tip_n3k_bfd_verify_commands  import Verifications
from parserLib import parserLib
from tip_n3k_config import Tip_N3k_Basic_Config
from tip_n3k_config import Tip_N3k_Basic_Unconfig
import time
import re
from genericLib import genericLib 
        
class Tip_N3k_Bfd_Svi_00001:

    def setup(self):
        self.dutall = BuiltIn().get_variable_value('${Common.DeviceList}')
        self.devicedetails=BuiltIn().get_variable_value('${Devices}')

    def test(self):
        self.failed_steps_count=0
        duts = self.dutall
        obj = Tip_N3k_Basic_Config()
	obj1=parserLib(self.devicedetails)

####################  Executing Configuration commands on Two Devices ##########################################

        genericLib().robolog("\n<b><font face=\"verdana\" color=\"blue\">Section-62.1: Configuring & verifying BFD over VLAN Routing Interface  between two Devices</b>",html = 1 ) 
        for dut in duts:
            if dut == duts[0]:
		(vlan,port,intf,ip,asn) = (self.vlan_1,self.port_1,self.intf_1,self.ip_1,self.as_1)
            else:
                (vlan,port,intf,ip,asn) = (self.vlan_2,self.port_2,self.intf_2,self.ip_2,self.as_2)
	    genericLib().robolog("\n<b><font face=\"verdana\" color=\"SaddleBrown\">Executing Configuration  commands on Device %s </b>" % dut, html = 1)
	    genericLib().robolog("\n<font face=\"verdana\" color=\"DarkMagenta\">Creating vlan %s " % vlan, html = 1 )        
            config_cmd=obj.create_vlan(vlan)
            keys = sorted(config_cmd)
            for vlan in keys:
                vlan_config  = self.dh.dut_command([dut],config_cmd[vlan])                      
            genericLib().robolog("\n<font face=\"verdana\" color=\"DarkMagenta\">Participating port %s in vlan %s " % (port,vlan), html = 1)
            config_cmd=obj.port_in_vlan(port, self.mode,vlan)
            keys = sorted(config_cmd)
            for port in keys:
                port_in_vlan = self.dh.dut_command([dut],config_cmd[port])
            genericLib().robolog("\n<font face=\"verdana\" color=\"DarkMagenta\">Configuring ip address %s on vlan interface %s " % (ip,intf), html = 1)
            config_cmd=obj.config_ip_address(ip, self.mask, intf)
            keys = sorted(config_cmd)
            for ip in keys:
                config_ip = self.dh.dut_command([dut],config_cmd[ip])
            genericLib().robolog("\n <font face=\"verdana\" color=\"DarkMagenta\">Configuring BGP as number %s " % self.as_1, html = 1)
            config_cmd=obj.config_bgp_router(self.as_1)
            keys = sorted(config_cmd)
            for pid in keys:
                config_bgp = self.dh.dut_command([dut],config_cmd[pid])     
	    genericLib().robolog("\n<font face=\"verdana\" color=\"DarkMagenta\">Configuring Logging TimeStamp to Milli Seconds",html = 1)
            config_cmd=obj.config_logging_timestamp('milliseconds')
            keys = sorted(config_cmd)
            for log in keys:
                config_logging_timestamp = self.dh.dut_command([dut],config_cmd[log])
        genericLib().robolog("\n<font face=\"verdana\" color=\"DarkMagenta\">Configuring BGP neighbor %s on Device %s " % (self.ip_2, duts[0]), html = 1)
        config_cmd1=obj.config_bgp_neighbor(self.as_1,self.as_2,self.ip_2,self.desc_2,self.intf_1)
        keys = sorted(config_cmd1)
        for ngbhr in keys:
            config_bgp_Nghbr = self.dh.dut_command([duts[0]],config_cmd1[ngbhr])
        genericLib().robolog("\n<font face=\"verdana\" color=\"DarkMagenta\">Configuring BGP neighbor %s on Device %s " % (self.ip_1, duts[1]), html = 1)
        config_cmd2=obj.config_bgp_neighbor(self.as_2,self.as_1,self.ip_1,self.desc_1,self.intf_2)
        keys = sorted(config_cmd2)
        for ngbhr in keys:
            config_bgp_Nghbr = self.dh.dut_command([duts[1]],config_cmd2[ngbhr])
	
#################### verification of bfd status on both devices ############################

	genericLib().robolog ("\nwaiting for 40 seconds to  form BFD neighbors between the Devices")
	time.sleep(40)       	
        for dut in self.dutall:
            if dut == duts[0]:
                intf = self.intf_1
            else:
                intf = self.intf_2
            genericLib().robolog("\n<b><font face=\"verdana\" color=\"SaddleBrown\">Verifying Configuration in %s command output on Device %s </b>" % (self.shbfd,dut), html = 1)
	    shipintf = self.dh.dut_command([dut],'show ip interface brief')
	    bgp_summary = self.dh.dut_command([dut],'show ip bgp summary')
            genericLib().robolog("\n<font face=\"verdana\" color=\"DarkMagenta\">Parsing and Verifying %s output" % self.shbfd, html = 1)
            show_bfd_nghbrs = self.dh.dut_command([dut],self.shbfd)
            self.parseresult = obj1.parse_cmd(dut,'show bfd neighbors',show_bfd_nghbrs)                
            if self.parseresult[0]:
                genericLib().robolog("\n<font face=\"verdana\" color=\"green\">Command %s output  parsing successful " % self.shbfd, html = 1)
                genericLib().robolog("\n<font face=\"verdana\" color=\"DarkMagenta\">Verifying %s output  for BFD neighborship status Up on interface %s " % (self.shbfd, intf), html = 1)
                self.verifyresult = Verifications().verify_show_bfd_neighbors(self.parseresult,intf,'Up')
                if self.verifyresult:
                    genericLib().robolog("\n<font face=\"verdana\" color=\"green\">Command %s output verification success: BFD status is 'UP' on interface %s as expected" % (self.shbfd,intf), html = 1)
                else:
                    genericLib().robolog("\n<b><font face=\"verdana\" color=\"red\">FAIL: Command %s output verification failed: BFD neighborship is not 'UP' on interface %s </b>" % (self.shbfd,intf), html = 1)
                    self.failed_steps_count+=1
            else:
                genericLib().robolog("\n<b><font face=\"verdana\" color=\"red\">FAIL: Parsing %s output failed </b>" % self.shbfd, html = 1)
                self.failed_steps_count+=1                    
            if self.failed_steps_count:
                BuiltIn().run_keyword_and_continue_on_failure("fail",(str(self.failed_steps_count))+" test steps failed")

####################### Shutting Donw vlan interface  on Device_1 and expecting bfd neighborship to go  down ############
                    
        genericLib().robolog("\n<b><font face=\"verdana\" color=\"blue\">Section-62.2: Performing vlan Interface %s shutdown  on Device %s and Expecting BFD neighborship to go Down</b>" % (self.intf_1,duts[0]), html = 1)
        genericLib().robolog("\n<font face=\"verdana\" color=\"DarkMagenta\">Shutting down the Vlan interface on device %s" % duts[0], html = 1)
	clear_logging = '\nconfig\nclear logging logfile\nend'
	clear_logging_out = self.dh.dut_command([duts[0]],clear_logging)
	time_diff = 0
        diff_time = 0
        show_clock_out = self.dh.dut_command([duts[0]],self.shclk)
        sys_clock_parser = obj1.parse_cmd(duts[0],'show clock',show_clock_out)
        sys_time = sys_clock_parser[1]['clock_out']['time']
        systime = re.search(r'([\d]+)\:([\d]+)\:([\d]+)\.([\d]+)',sys_time).groups()
        sys_hrs,sys_min,sys_sec,sys_msec = int(systime[0]),int(systime[1]),int(systime[2]),int(systime[3])
        sys_clock_total_milli_seconds = (sys_hrs*3600000)+(sys_min*60000)+(sys_sec*1000)+(sys_msec)
        config_cmd1=obj.shutdown_interface(self.intf_1,'shut')
        keys = sorted(config_cmd1)
        for intf in keys:
            interface_Shutdown = self.dh.dut_command([duts[0]],config_cmd1[intf])
        time.sleep(5)
	shipintf = self.dh.dut_command([duts[0]],'show ip interface brief')
        show_logging_out = self.dh.dut_command([duts[0]],self.shlgng,timeout = 60)
        show_loggign_out_parser = obj1.parse_cmd(dut,'show logging',show_logging_out)
        logs = show_loggign_out_parser[1]['Log']
        for log in logs:
            if re.search(r'BFD-(\d+)-SESSION_STATE_DOWN',log) != None:
                if self.ip_2 in log:
                    if re.search(r'([\d]+)\:([\d]+)\:([\d]+)\.([\d]+)',log) != None:
                        bfd_down_time = re.search(r'([\d]+)\:([\d]+)\:([\d]+)\.([\d]+)',log).groups()
                        bfd_hrs,bfd_min,bfd_sec,bfd_msec = int(bfd_down_time[0]), int(bfd_down_time[1]),int(bfd_down_time[2]), int(bfd_down_time[3])
                        bfd_down_total_milli_seconds = (bfd_hrs*3600000)+(bfd_min*60000)+(bfd_sec*1000)+(bfd_msec)
                        time_diff = (bfd_down_total_milli_seconds - sys_clock_total_milli_seconds)
            if re.search(r'BFD-(\d+)-SESSION_REMOVED',log) != None:
                if self.ip_2 in log:
                    if re.search(r'([\d]+)\:([\d]+)\:([\d]+)\.([\d]+)',log) != None:
                        bfd_removed_time = re.search(r'([\d]+)\:([\d]+)\:([\d]+)\.([\d]+)',log).groups()
                        bfd_hrs,bfd_min,bfd_sec,bfd_msec = int(bfd_removed_time[0]), int(bfd_removed_time[1]),int(bfd_removed_time[2]), int(bfd_removed_time[3])
                        bfd_removed_total_milli_seconds = (bfd_hrs*3600000)+(bfd_min*60000)+(bfd_sec*1000)+(bfd_msec)
                        diff_time = (bfd_removed_total_milli_seconds - sys_clock_total_milli_seconds)
        genericLib().robolog("\ntime taken by bfd to detect physical link down is %s milli seconds " % time_diff, html = 1)
        if (time_diff > 1000 or time_diff <= 0):
            genericLib().robolog("\n<b><font face=\"verdana\" color=\"red\">FAIL: BFD not detected vlan link %s down  within 1 sec<\b>" % self.intf_1,html = 1 )
        else:
            genericLib().robolog("\n<b><font face=\"verdana\" color=\"green\">BFD-SESSION Down event generated within 1 sec of vlan link %s down as expected" % self.intf_1, html = 1)
        for dut in  self.dutall:
            if dut == duts[0]:
                intf = self.intf_1
            else:
                intf = self.intf_2
            genericLib().robolog("\n<b><font face=\"verdana\" color=\"SaddleBrown\">Parsing and Verifying  %s command output on Device %s after vlan Interface shutdown on Device %s </b>" % (self.shbfd,dut, duts[0]), html = 1)            
            genericLib().robolog("\n<font face=\"verdana\" color=\"DarkMagenta\">Parsing %s output " % self.shbfd, html = 1)
            show_bfd_nghbrs = self.dh.dut_command([dut],self.shbfd)
            self.parseresult = obj1.parse_cmd(dut,'show bfd neighbors',show_bfd_nghbrs)            
            if self.parseresult[0]:
                genericLib().robolog("\n<font face=\"verdana\" color=\"green\">Command %s output parsing successful " % self.shbfd, html = 1)
                genericLib().robolog("\n<font face=\"verdana\" color=\"DarkMagenta\">Verifying %s output to check for bfd entry on the vlan interface %s should not exists " % (self.shbfd,intf), html = 1)
                self.verifyresult = Verifications().verify_show_bfd_neighbors(self.parseresult,intf,'Down')
                if self.verifyresult:
                    genericLib().robolog("\n<font face=\"verdana\" color=\"green\">Command %s output verification passed: BFD entry on vlan interface %s is flushed out as expected " % (self.shbfd,intf), html = 1)
		    if dut == duts[0]:
                        genericLib().robolog("\nTime taken to remove bfd entry on vlan interface %s after it shutdown is %s Milli Seconds" % (intf,diff_time),html = 1 )
                else:
                    genericLib().robolog("\n<font face=\"verdana\" color=\"red\">FAIL: Command %s output verification failed:  BFD entry on vlan interface %s is not flushed out as expected " % (self.shbfd,intf), html = 1)
                    self.failed_steps_count+=1
            else:
                genericLib().robolog("\n<font face=\"verdana\" color=\"red\">FAIL: Parsing %s output failed " % self.shbfd, html = 1)
                self.failed_steps_count+=1               
            if self.failed_steps_count:
                BuiltIn().run_keyword_and_continue_on_failure("fail",(str(self.failed_steps_count))+" test steps failed")

########################## Bringing back the vlan interface by no shutdown ################
        
        genericLib().robolog("\n<b><font face=\"verdana\" color=\"blue\">Section-62.3: Bringing Back the Vlan Interface %s on device %s with No Shutdown and Expecting BFD neighborship to Retain</b>" % (self.intf_1,duts[0]), html = 1)
        genericLib().robolog("\n<font face=\"verdana\" color=\"DarkMagenta\">No Shutdown the Vlan Interface %s on Device %s" % (self.intf_1, duts[0]), html = 1)
        config_cmd1=obj.shutdown_interface(self.intf_1,'no shut')
        keys = sorted(config_cmd1)
        for intf in keys:
            no_shutdown_intf = self.dh.dut_command([duts[0]],config_cmd1[intf])
	shintf = self.dh.dut_command([duts[0]],'show ip interface brief')
        genericLib().robolog("\nwaiting for 60 sec to retain  bfd neighborship after vlan interface no shutdown")    
        time.sleep(60)
	shipintf = self.dh.dut_command([duts[0]],'show ip interface brief')
        for dut in self.dutall:            
            if dut == duts[0]:
                intf = self.intf_1
            else:
                intf = self.intf_2	    
            genericLib().robolog("\n<b><font face=\"verdana\" color=\"SaddleBrown \"> Parsing and Verifying %s output on Device %s after vlan interface of Device %s is 'No Shutdown'</b>" % (self.shbfd, dut, duts[0]), html = 1)
            genericLib().robolog("\n<font face=\"verdana\" color=\"DarkMagenta\">Parsing %s output " % self.shbfd, html = 1)
            show_bfd_nghbrs = self.dh.dut_command([dut],self.shbfd)
            self.parseresult = obj1.parse_cmd(dut,'show bfd neighbors',show_bfd_nghbrs)                
            if self.parseresult[0]:
                genericLib().robolog("\n<font face=\"verdana\" color=\"green\">Command %s output parsing successful" % self.shbfd, html = 1)
                genericLib().robolog("\n<font face=\"verdana\" color=\"DarkMagenta\">Verifying %s output for BFD neighborship to retain on Interface %s " % (self.shbfd, intf), html = 1)
                self.verifyresult = Verifications().verify_show_bfd_neighbors(self.parseresult,intf,'Up')
                if self.verifyresult:
                    genericLib().robolog("\n<font face=\"verdana\" color=\"green\">Command %s output verification success: BFD neighborship retained on interface %s after no shutdown " % (self.shbfd,intf), html = 1)
                else:
                    genericLib().robolog("\n<font face=\"verdana\" color=\"DarkMagenta\"><font face=\"verdana\" color=\"red\"> FAIL : Command %s output verification failed: BFD neighborship not retained on interface %s after no shutdown " % (self.shbfd,intf), html = 1)
                    self.failed_steps_count+=1
            else:
                genericLib().robolog("\n<font face=\"verdana\" color=\"red\">FAIL: Parsing %s output failed " % self.shbfd, html = 1)
                self.failed_steps_count+=1                    
            if self.failed_steps_count:
                BuiltIn().run_keyword_and_continue_on_failure("fail",(str(self.failed_steps_count))+" test steps failed")                    

###############################  Configuring Fake ip on vlan interface on Deive_1 and  expecting Bfd neighbor entry to go  down ##############

        genericLib().robolog("\n<b><font face=\"verdana\" color=\"blue\">Section-62.4: Configuring fake ip address  on vlan Interface %s on device %s and expecting the BFD neighborship  to go down</b>" % (self.intf_1,duts[0]), html = 1)
        genericLib().robolog("\n<font face=\"verdana\" color=\"DarkMagenta\">Configuring fake ip %s address on vlan interface %s " % (self.fake_ip,self.intf_1), html = 1)
	clear_logging_out = self.dh.dut_command([duts[0]],clear_logging)
	time_diff = 0
        diff_time = 0
        show_clock_out = self.dh.dut_command([duts[0]],self.shclk)
        sys_clock_parser = obj1.parse_cmd(duts[0],'show clock',show_clock_out)
        sys_time = sys_clock_parser[1]['clock_out']['time']
        systime = re.search(r'([\d]+)\:([\d]+)\:([\d]+)\.([\d]+)',sys_time).groups()
        sys_hrs,sys_min,sys_sec,sys_msec = int(systime[0]),int(systime[1]),int(systime[2]),int(systime[3])
        sys_clock_total_milli_seconds = (sys_hrs*3600000)+(sys_min*60000)+(sys_sec*1000)+(sys_msec)
	config_cmd1=obj.config_ip_address(self.fake_ip, self.mask, self.intf_1)
        keys = sorted(config_cmd1)
        for ip in keys:
            config_ip = self.dh.dut_command([duts[0]],config_cmd1[ip])
        time.sleep(5)
	shipintf = self.dh.dut_command([duts[0]],'show ip interface brief')
        show_logging_out = self.dh.dut_command([duts[0]],self.shlgng,timeout = 60)
        show_loggign_out_parser = obj1.parse_cmd(dut,'show logging',show_logging_out)
        logs = show_loggign_out_parser[1]['Log']
        for log in logs:
            if re.search(r'BFD-(\d+)-SESSION_STATE_DOWN',log) != None:
                if self.ip_2 in log:
                    if re.search(r'([\d]+)\:([\d]+)\:([\d]+)\.([\d]+)',log) != None:
                        bfd_down_time = re.search(r'([\d]+)\:([\d]+)\:([\d]+)\.([\d]+)',log).groups()
                        bfd_hrs,bfd_min,bfd_sec,bfd_msec = int(bfd_down_time[0]), int(bfd_down_time[1]),int(bfd_down_time[2]), int(bfd_down_time[3])
                        bfd_down_total_milli_seconds = (bfd_hrs*3600000)+(bfd_min*60000)+(bfd_sec*1000)+(bfd_msec)
                        time_diff = (bfd_down_total_milli_seconds - sys_clock_total_milli_seconds)
            if re.search(r'BFD-(\d+)-SESSION_REMOVED',log) != None:
                if self.ip_2 in log:
                    if re.search(r'([\d]+)\:([\d]+)\:([\d]+)\.([\d]+)',log) != None:
                        bfd_removed_time = re.search(r'([\d]+)\:([\d]+)\:([\d]+)\.([\d]+)',log).groups()
                        bfd_hrs,bfd_min,bfd_sec,bfd_msec = int(bfd_removed_time[0]), int(bfd_removed_time[1]),int(bfd_removed_time[2]), int(bfd_removed_time[3])
                        bfd_removed_total_milli_seconds = (bfd_hrs*3600000)+(bfd_min*60000)+(bfd_sec*1000)+(bfd_msec)
                        diff_time = (bfd_removed_total_milli_seconds - sys_clock_total_milli_seconds)
        genericLib().robolog("\ntime taken by bfd to detect physical link down is %s milli seconds " % time_diff, html = 1)
        #if (time_diff > 1000 or time_diff <= 0):
         #   genericLib().robolog("\n<b><font face=\"verdana\" color=\"red\">FAIL: BFD not detected vlan link %s down  within 1 sec </b>" % self.intf_1,html = 1 )
        #else:
         #   genericLib().robolog("\n<b><font face=\"verdana\" color=\"green\">BFD-SESSION Down event generated within 1 sec of vlan link %s down, as expected" % self.intf_1, html = 1)
        for dut in self.dutall:
            if dut == duts[0]:
                intf = self.intf_1
            else:
                intf = self.intf_2
            genericLib().robolog("\n<b><font face=\"verdana\" color=\"SaddleBrown\">Parsing and Verifying %s output on Device %s after configuring Fake ip on vlan interface of Device %s </b>" % (self.shbfd, dut, duts[0]), html = 1)
            genericLib().robolog("\n<font face=\"verdana\" color=\"DarkMagenta\">Parsing %s output " % self.shbfd, html = 1)
            show_bfd_nghbrs = self.dh.dut_command([dut],self.shbfd)
            self.parseresult = obj1.parse_cmd(dut,'show bfd neighbors',show_bfd_nghbrs)
            if self.parseresult[0]:
                genericLib().robolog("\n<font face=\"verdana\" color=\"green\">Command %s output parsing successful " % self.shbfd , html = 1)
                genericLib().robolog("\n<font face=\"verdana\" color=\"DarkMagenta\">Verifying %s output for BFD neighborship to go Down on interface %s" % (self.shbfd, intf), html = 1)
                self.verifyresult = Verifications().verify_show_bfd_neighbors(self.parseresult,intf,'Down')
                if self.verifyresult:
                    genericLib().robolog("\n<font face=\"verdana\" color=\"green\">Command %s output verification success: BFD neighborship goes Down  on interface %s after configuring fake_ip" % (self.shbfd,intf), html = 1)
		    if dut == duts[0]:
                        genericLib().robolog("\nTime taken to remove bfd entry on vlan interface %s after Fake Ip configured on it is %s Milli Seconds" % (intf,diff_time),html=1)
                else:
                    genericLib().robolog("\n<font face=\"verdana\" color=\"red\">FAIL: Command %s output verification failed: BFD neighborship not goes Down on interface %s even after configuring Fakeip" % (self.shbfd, intf), html = 1)
                    self.failed_steps_count+=1
            else:
                genericLib().robolog("*\n<font face=\"verdana\" color=\"red\">FAIL: Parsing %s output failed" % self.shbfd, html = 1)
                self.failed_steps_count+=1
            if self.failed_steps_count:
                BuiltIn().run_keyword_and_continue_on_failure("fail",(str(self.failed_steps_count))+" test steps failed")

############################### Re-configruing original  ip and expecting bfd neighborship to  retain on vlan Interface ######################

        genericLib().robolog("\n<b><font face=\"verdana\" color=\"blue\">Section-62.5: Re-Configuring Original ip address on Interface %s  on device %s  and Expecting BFD neighborship Retains on Both Devices</b>" % (self.intf_1,duts[0]), html = 1)
        genericLib().robolog("\n<font face=\"verdana\" color=\"DarkMagenta\">Configuring Origonal ip address %s on vlan interface %s on device %s " % (self.ip_1,self.vlan_1,duts[0]), html = 1)
        config_cmd1=obj.config_ip_address(self.ip_1, self.mask, self.intf_1)
        keys = sorted(config_cmd1)
        for ip in keys:
            config_ip = self.dh.dut_command([duts[0]],config_cmd1[ip])
        genericLib().robolog ("\nwaiting for 40 seconds to retian BFD neighborship after original ip configured")
        time.sleep(40)
	shipintf = self.dh.dut_command([duts[0]],'show ip interface brief')
        for dut in self.dutall:
            if dut == duts[0]:
                intf = self.intf_1
            else:
                intf = self.intf_2            
            genericLib().robolog("\n<b><font face=\"verdana\" color=\"SaddleBrown\">Parsing and Verifying %s output on device %s after Re-Configuring Original ip on vlan interface of Device %s </b>" % (self.shbfd, dut, duts[0]), html = 1)
            genericLib().robolog("\n<font face=\"verdana\" color=\"DarkMagenta\">Parsing %s output </b>" % (self.shbfd),html=1) 
            show_bfd_nghbrs = self.dh.dut_command([dut],self.shbfd)
            self.parseresult = obj1.parse_cmd(dut,'show bfd neighbors',show_bfd_nghbrs)                
            if self.parseresult[0]:
                genericLib().robolog("\n<font face=\"verdana\" color=\"green\">Command %s output parsing successful on device %s " % (self.shbfd, dut), html = 1)
                genericLib().robolog("\n<font face=\"verdana\" color=\"DarkMagenta\">Verifying %s output for BFD neighborship to retain on interface %s after configuring original ip address" % (self.shbfd,intf), html = 1)
                self.verifyresult = Verifications().verify_show_bfd_neighbors(self.parseresult,intf,'Up')
                if self.verifyresult:
                    genericLib().robolog("\n<font face=\"verdana\" color=\"green\">Command %s output verification success: BFD neighborship retained on interface %s after configuring original ip address " % (self.shbfd, intf), html = 1)
                else:
                    genericLib().robolog("\n<font face=\"verdana\" color=\"red\">FAIL: Command %s output verification failed: BFD neighborship not retained on interface %s even after configuring original ip address " % (self.shbfd, dut), html = 1)
                    self.failed_steps_count+=1
            else:
                genericLib().robolog("\n<font face=\"verdana\" color=\"red\">FAIL: Parsing %s output failed " % self.shbfd, html = 1)
                self.failed_steps_count+=1                    
            if self.failed_steps_count:
            	BuiltIn().run_keyword_and_continue_on_failure("fail",(str(self.failed_steps_count))+" test steps failed")

###################################  UNCONFIGURING PART  ###########################################

    def cleanup(self):

	duts = self.dutall
	genericLib().robolog("\n<b><font face=\"verdana\" color=\"blue\">Section-62.6: UnConfiguring the configuration done as part of this test case on both Devices  </b>", html = 1)
        obj=Tip_N3k_Basic_Unconfig()
	obj1=Tip_N3k_Basic_Config()

	genericLib().robolog("\n<font face=\"verdana\" color=\"DarkMagenta\">Removing BGP neighbor %s and router bgp on Device %s" % (self.ip_2, duts[0]), html = 1)
        config_cmd1=obj.remove_bgp_neighbor(self.as_1,self.as_2,self.ip_2)
        keys = sorted(config_cmd1)
        for ngbhr in keys:
            remove_bgp_nghbr = self.dh.dut_command([duts[0]],config_cmd1[ngbhr])
	nobgp = 'config\nno router bgp id\nend'
	nobgp1 = nobgp.replace('id',self.as_1)
	nobgp_out = self.dh.dut_command([duts[0]],nobgp1)
        genericLib().robolog("\n<font face=\"verdana\" color=\"DarkMagenta\">Removing BGP neighbor %s and router bgp on Device %s" % (self.ip_1, duts[1]), html = 1)
        config_cmd2=obj.remove_bgp_neighbor(self.as_2,self.as_1,self.ip_1)
        keys = sorted(config_cmd2)
        for ngbhr in keys:
            remove_bgp_nghbr = self.dh.dut_command([duts[1]],config_cmd2[ngbhr])
        nobgp2 = nobgp.replace('id',self.as_1)
        nobgp_out = self.dh.dut_command([duts[1]],nobgp2)

        for dut in self.dutall:
            if dut == self.dutall[0]:
                (vlan,port,intf,ip) = (self.vlan_1,self.port_1,self.intf_1,self.ip_1)
            else:
                (vlan,port,intf,ip) = (self.vlan_2,self.port_2,self.intf_2,self.ip_2)		

            genericLib().robolog("\n<b><font face=\"verdana\" color=\"SaddleBrown\">Removing Configuration on Device %s </b>" % dut, html = 1 )
            genericLib().robolog("\n<font face=\"verdana\" color=\"DarkMagenta\">Deleting  vlan %s " % vlan, html = 1)       
            config_cmd=obj.delete_vlan(vlan)
            keys = sorted(config_cmd)
            for vlan in keys:
                delete_vlan = self.dh.dut_command([dut],config_cmd[vlan])
            genericLib().robolog("\n<font face=\"verdana\" color=\"DarkMagenta\">Removing port %s from vlan %s" % (port,vlan), html = 1)
            config_cmd=obj.remove_port_from_vlan(port,self.mode,vlan)
            keys = sorted(config_cmd)
            for prt in keys:
                remove_port_from_vlan = self.dh.dut_command([dut],config_cmd[prt])
            genericLib().robolog("\n<font face=\"verdana\" color=\"DarkMagenta\">Removing ip address %s on vlan interface %s " % (ip,intf), html = 1)
            config_cmd=obj.delete_ip_address(intf)
            keys = sorted(config_cmd)
            for ip in keys:
                delete_ip = self.dh.dut_command([dut],config_cmd[ip])
	    genericLib().robolog("\n<font face=\"verdana\" color=\"DarkMagenta\">Setting logging timestamp config to default seconds ", html = 1)
            config_cmd=obj1.config_logging_timestamp('seconds')
            keys = sorted(config_cmd)
            for log in keys:
                cionfig_timestamp = self.dh.dut_command([dut],config_cmd[log])
	    time.sleep(5)
	    show_bfd_nghbrs = self.dh.dut_command([dut],self.shbfd)
	genericLib().robolog("\nSuccesfully Executed \'62.0 BFD - SVI / VLAN' test case",html=1,console=1)

##*******************************************************************************************************

class Bfd_Port_Channel_61_0:
    def setup(self):
        self.dutall = BuiltIn().get_variable_value('${Common.DeviceList}')
        self.devicedetails=BuiltIn().get_variable_value('${Devices}')
    def test(self):
        self.parseresult = {}
        self.failed_steps_count=0
        duts = self.dutall
        obj = Tip_N3k_Basic_Config()
	obj1=parserLib(self.devicedetails)

####################  Perfomring Configuration part on two devices ##########################################
	
        genericLib().robolog("\n<b><font face=\"verdana\" color=\"blue\">Section-61.01: Configuring & verifying BFD over port-channel Routing Interface  between two Devices</b>", html =1 ) 
        for dut in self.dutall:
            if dut == self.dutall[0]:
                (port,PCID, ip, asn) = (self.port_1,self.pcid_1, self.ip_1, self.as_1)
            else:
                (port,PCID,ip, asn) = (self.port_1,self.pcid_1, self.ip_2, self.as_2)
	    genericLib().robolog("\n<b><font face=\"verdana\" color=\"SaddleBrown\">Executing Configuration  commands on Device %s </b>" % dut, html = 1)
            genericLib().robolog("\n<font face=\"verdana\" color=\"DarkMagenta\">Participating two physical ports %s in port-channel %s " % (port,PCID),html = 1)    
            config_cmd=obj.add_port_in_portchannel(port,PCID)
            keys = sorted(config_cmd)
            for port in keys:
                config_port_in_lag = self.dh.dut_command([dut],config_cmd[port]) 
            genericLib().robolog("\n<font face=\"verdana\" color=\"DarkMagenta\">Configuring ip address %s on port-channel interface %s " % (ip,PCID), html = 1)
            config_cmd=obj.config_ip_address(ip, self.mask, PCID)
            keys = sorted(config_cmd)
            for ip in keys:
                config_ip = self.dh.dut_command([dut],config_cmd[ip])
            genericLib().robolog("\n<font face=\"verdana\" color=\"DarkMagenta\">Configuring BGP router ID %s " % asn, html = 1)
            config_cmd=obj.config_bgp_router(asn)
            keys = sorted(config_cmd)
            for pid in keys:
                config_bgp_router_id = self.dh.dut_command([dut],config_cmd[pid])     
	    genericLib().robolog("\n<font face=\"verdana\" color=\"DarkMagenta\">Configuring Logging TimeStamp to Milli Seconds",html = 1)
            config_cmd=obj.config_logging_timestamp('milliseconds')
            keys = sorted(config_cmd)
            for log in keys:
                config_logging_timestamp = self.dh.dut_command([dut],config_cmd[log])
        genericLib().robolog("\n<font face=\"verdana\" color=\"DarkMagenta\">Configuring BGP neighbor %s on Device %s " % (self.ip_2, duts[0]), html = 1)
        config_cmd1=obj.config_bgp_neighbor(self.as_1,self.as_2,self.ip_2,self.desc_2,self.pcid_1)
        keys = sorted(config_cmd1)
        for ngbhr in keys:
            config_bgp_nghbr = self.dh.dut_command([duts[0]],config_cmd1[ngbhr])
        genericLib().robolog("\n<font face=\"verdana\" color=\"DarkMagenta\">Configuring BGP neighbor %s on Device %s " % (self.ip_1, duts[1]), html = 1)
        config_cmd2=obj.config_bgp_neighbor(self.as_2,self.as_1,self.ip_1,self.desc_1,self.pcid_2)
        keys = sorted(config_cmd2)
        for ngbhr in keys:
            config_bgp_nghbr = self.dh.dut_command([duts[1]],config_cmd2[ngbhr])                 

#################### verification of bfd status on both devices ############################

	genericLib().robolog("\n<font face=\"verdana\" color=\"SaddleBrown\">Executing below show commands just for debugging purpose. Not verifying anyhting in the command output", html = 1)       
	for dut in self.dutall:
	    port_channel_summary = self.dh.dut_command([dut],"show port-channel summary")
	    Bgp_Summary  = self.dh.dut_command([dut],"show ip bgp summary")   
	obj1=parserLib(self.devicedetails)
	genericLib().robolog ("waiting for %s seconds to  form BFD neighbors between the Devices" % self.sleep)
	time.sleep(self.sleep)       
        for dut in self.dutall:
            if dut == duts[0]:
                intf = self.pcid_1
            else:
                intf = self.pcid_2
            genericLib().robolog("\n<b><font face=\"verdana\" color=\"SaddleBrown\">Verifying Configuration in %s command output on Device %s </b>" % (self.shbfd,dut), html = 1)
            genericLib().robolog("\n<font face=\"verdana\" color=\"DarkMagenta\">Parsing %s output" % self.shbfd, html = 1)
            bfd_nghbrs_out = self.dh.dut_command([dut],self.shbfd)
            self.parseresult = obj1.parse_cmd(dut,'show bfd neighbors',bfd_nghbrs_out)                
            if self.parseresult[0]:
                genericLib().robolog("\n<font face=\"verdana\" color=\"green\">Command %s output  parsing successful " % self.shbfd, html = 1)
                genericLib().robolog("\n<font face=\"verdana\" color=\"DarkMagenta\">Verifying %s output  for BFD neighborship status UP on interface %s " % (self.shbfd, intf), html = 1)
                self.verifyresult = Verifications().verify_show_bfd_neighbors(self.parseresult,intf,'Up')
                if self.verifyresult:
                    genericLib().robolog("\n<font face=\"verdana\" color=\"green\">PasS: Command %s output verification success: BFD status is 'UP' on interface %s as expected" % (self.shbfd,intf), html = 1)
                else:
                    genericLib().robolog("\n<b><font face=\"verdana\" color=\"red\">FAIL: Command %s output verification failed: BFD neighborship is not 'UP' on interface %s </b>" % (self.shbfd,intf), html = 1)
                    self.failed_steps_count+=1
            else:
                genericLib().robolog("\n<b><font face=\"verdana\" color=\"red\">FAIL: Parsing %s output failed </b>" % self.shbfd, html = 1)
                self.failed_steps_count+=1                    
            if self.failed_steps_count:
                BuiltIn().run_keyword_and_continue_on_failure("fail",(str(self.failed_steps_count))+" test steps failed")    

####################### Shutting Donw physical interfaces in port-Channel on Device_1 and expecting bfd neighborship to go  down ############
                    
        genericLib().robolog("\n<b><font face=\"verdana\" color=\"blue\">Sections-61.02,61.03: Performing physical interfaces in port-Channel shutdown  on Device %s and Expecting BFD neighborship to flush out</b>" % duts[0], html = 1)
	for port in self.port_1: 
	    if port == self.port_1[1]:
		genericLib().robolog("\n<font face=\"verdana\" color=\"DarkMagenta\">Shutting down Physical Interface %s in port-Channel %s" % (port,self.pcid_1), html = 1)
		time_diff = 0
		diff_time = 0
		show_clock_out = self.dh.dut_command([duts[0]],self.shclk)
		sys_clock_parser = obj1.parse_cmd(duts[0],'show clock',show_clock_out)
		sys_time = sys_clock_parser[1]['clock_out']['time']		
		systime = re.search(r'([\d]+)\:([\d]+)\:([\d]+)\.([\d]+)',sys_time).groups()
		sys_hrs,sys_min,sys_sec,sys_msec = int(systime[0]),int(systime[1]),int(systime[2]),int(systime[3])
		sys_clock_total_milli_seconds = (sys_hrs*3600000)+(sys_min*60000)+(sys_sec*1000)+(sys_msec)			
                config_cmd1=obj.shutdown_interface(port,'shut')
                keys = sorted(config_cmd1)
                for intf in keys:
                    interface_shutdown = self.dh.dut_command([duts[0]],config_cmd1[intf])
		time.sleep(5)
	        show_logging_out = self.dh.dut_command([duts[0]],self.shlgng,timeout = 60) 	
		show_loggign_out_parser = obj1.parse_cmd(dut,'show logging',show_logging_out)
		logs = show_loggign_out_parser[1]['Log']
		for log in logs:
		    if re.search(r'([\d]+)\:([\d]+)\:([\d]+)\.([\d]+)',log) == '': continue
	            if re.search(r'BFD-(\d+)-SESSION_STATE_DOWN',log) != None:
			if self.ip_2 in log: 
		            if re.search(r'([\d]+)\:([\d]+)\:([\d]+)\.([\d]+)',log) != None:
			        bfd_down_time = re.search(r'([\d]+)\:([\d]+)\:([\d]+)\.([\d]+)',log).groups()
			        bfd_hrs,bfd_min,bfd_sec,bfd_msec = int(bfd_down_time[0]), int(bfd_down_time[1]),int(bfd_down_time[2]), int(bfd_down_time[3])
			        bfd_down_total_milli_seconds = (bfd_hrs*3600000)+(bfd_min*60000)+(bfd_sec*1000)+(bfd_msec)
	                        time_diff = (bfd_down_total_milli_seconds - sys_clock_total_milli_seconds)
		    if re.search(r'BFD-(\d+)-SESSION_REMOVED',log) != None:
			if self.ip_2 in log:
			    if re.search(r'([\d]+)\:([\d]+)\:([\d]+)\.([\d]+)',log) != None:
			        bfd_removed_time = re.search(r'([\d]+)\:([\d]+)\:([\d]+)\.([\d]+)',log).groups()
			        bfd_hrs,bfd_min,bfd_sec,bfd_msec = int(bfd_removed_time[0]), int(bfd_removed_time[1]),int(bfd_removed_time[2]), int(bfd_removed_time[3])
			        bfd_removed_total_milli_seconds = (bfd_hrs*3600000)+(bfd_min*60000)+(bfd_sec*1000)+(bfd_msec)
			        diff_time = (bfd_removed_total_milli_seconds - sys_clock_total_milli_seconds) 
		genericLib().robolog("\ntime taken by bfd to detect physical link down is %s milli seconds " % time_diff, html = 1)
	        if (time_diff > 1000 or time_diff <= 0):
		    genericLib().robolog("\n<b><font face=\"verdana\" color=\"red\">FAIL: BFD not detected physical link %s down  within 1 sec</b>" % port, html = 1 )  
	        else:
		    genericLib().robolog("\n<b><font face=\"verdana\" color=\"green\">BFD-SESSION Down event generated within 1 sec of physical link %s down, as expected" % port, html = 1)	
	    else:
		genericLib().robolog("\n<font face=\"verdana\" color=\"DarkMagenta\">Shutting down Physical Interface %s in port-Channel %s" % (port,self.pcid_1), html = 1)
                config_cmd1=obj.shutdown_interface(port,'shut')
                keys = sorted(config_cmd1)
                for intf in keys:
                    Interface_ShutDown = self.dh.dut_command([duts[0]],config_cmd1[intf])
		time.sleep(5)	
	    for dut in self.dutall:
                if dut == duts[0]:
                    intf = self.pcid_1
                else:
                    intf = self.pcid_2
                genericLib().robolog("\n<b><font face=\"verdana\" color=\"SaddleBrown\">Parsing and Verifying %s command output on Device %s for BFD entry status on Interface %s </b>" % (self.shbfd,dut, intf), html = 1)
		port_channel_summary = self.dh.dut_command([dut],"show port-channel summary")
                genericLib().robolog("\n<font face=\"verdana\" color=\"DarkMagenta\">Parsing %s output" % self.shbfd, html = 1)
                bfd_nghbrs_out = self.dh.dut_command([dut],self.shbfd)
                self.parseresult = obj1.parse_cmd(dut,'show bfd neighbors',bfd_nghbrs_out)                
                if self.parseresult[0]:
                    genericLib().robolog("\n<font face=\"verdana\" color=\"green\">Command %s output  parsing successful " % self.shbfd, html = 1)                  
		    if port == self.port_1[0]:
			genericLib().robolog("\n<font face=\"verdana\" color=\"DarkMagenta\">Verifying %s output  for BFD neighborship status UP on interface %s " % (self.shbfd, intf), html = 1)
                        self.verifyresult = Verifications().verify_show_bfd_neighbors(self.parseresult,intf,'Up')		
                        if self.verifyresult:
                            genericLib().robolog("\n<font face=\"verdana\" color=\"green\">Command %s output verification success: BFD status is 'UP' on interface %s as expected after shutting Down First port in the port-channel" % (self.shbfd,intf), html = 1)
                        else:
                            genericLib().robolog("\n<b><font face=\"verdana\" color=\"red\">FAIL : Command %s output verification failed: BFD neighborship is not 'UP' on interface %s after shutting Down First port in the port-channel </b>" % (self.shbfd,intf), html = 1)
                            self.failed_steps_count+=1
		    else:
			genericLib().robolog("\n<font face=\"verdana\" color=\"DarkMagenta\">Verifying %s output  for BFD neighborship status Down on interface %s " % (self.shbfd, intf), html = 1)
		        self.verifyresult = Verifications().verify_show_bfd_neighbors(self.parseresult,intf,'Down')
		        if self.verifyresult:
                            genericLib().robolog("\n<font face=\"verdana\" color=\"green\">Command %s output verification success: BFD status is 'Down' on interface %s as expected after shutting Down Second  port in the port-channel" % (self.shbfd,intf), html = 1)
			    if dut == duts[0]:
		                genericLib().robolog("\nTime taken to remove bfd entry on port-channel %s  interface after second port shutdown is %s Milli Seconds" % (intf,diff_time),html = 1 )  
                        else:
                            genericLib().robolog("\n<b><font face=\"verdana\" color=\"red\">FAIL: Command %s output verification failed: BFD neighborship is not 'Down' on interface %s even after shutting Down Second  port in the port-channel </b>" % (self.shbfd,intf), html = 1)
                            self.failed_steps_count+=1

                else:
                    genericLib().robolog("\n<b><font face=\"verdana\" color=\"red\">FAIL: Parsing %s output failed </b>" % self.shbfd, html = 1)
                    self.failed_steps_count+=1
                    
            if self.failed_steps_count:
                BuiltIn().run_keyword_and_continue_on_failure("fail",(str(self.failed_steps_count))+" test steps failed") 


####################### No Shutting Donw physical interfaces in port-Channel on Device_1 and expecting bfd neighborship to Retain ############
                    
        genericLib().robolog("\n<b><font face=\"verdana\" color=\"blue\">Sections-61.04,61.05: Performing physical interfaces in port-Channel No shutdown  on Device %s and Expecting BFD neighborship to retain</b>" % duts[0], html = 1)
	for port in self.port_1:
	    genericLib().robolog("\n<font face=\"verdana\" color=\"DarkMagenta\">No Shutting down Physical Interface %s in port-Channel %s" % (port,self.pcid_1), html = 1)
            config_cmd1=obj.shutdown_interface(port,'no shut')
            keys = sorted(config_cmd1)
            for intf in keys:
                ShutDown_intf = self.dh.dut_command([duts[0]],config_cmd1[intf])
            genericLib().robolog("\nwaiting for 60 sec to verify bfd neighborship after the port in port-channel is no shutdown") 
            time.sleep(60)
	    for dut in self.dutall:
                if dut == duts[0]:
                    intf = self.pcid_1
                else:
                    intf = self.pcid_2
                genericLib().robolog("\n<b><font face=\"verdana\" color=\"SaddleBrown\">Parsing and Verifying %s command output on Device %s for BFD entry status on Interface %s </b>" % (self.shbfd,dut, intf), html = 1)
		port_channel_summary = self.dh.dut_command([dut],"show port-channel summary")
                genericLib().robolog("\n<font face=\"verdana\" color=\"DarkMagenta\">Parsing %s output" % self.shbfd, html = 1)
                bfd_nghbrs_out = self.dh.dut_command([dut],self.shbfd)
                self.parseresult = obj1.parse_cmd(dut,'show bfd neighbors',bfd_nghbrs_out)                
                if self.parseresult[0]:
                    genericLib().robolog("\n<font face=\"verdana\" color=\"green\">Command %s output  parsing successful " % self.shbfd, html = 1)
		    if port == self.port_1[0]:
			genericLib().robolog("\n<font face=\"verdana\" color=\"DarkMagenta\">Verifying %s output  for BFD neighborship status Up on interface %s " % (self.shbfd, intf), html = 1)
                        self.verifyresult = Verifications().verify_show_bfd_neighbors(self.parseresult,intf,'Up')		
                        if self.verifyresult:
                            genericLib().robolog("\n<font face=\"verdana\" color=\"green\">Command %s output verification success: BFD status is 'Up' on interface %s as expected when First port in the port-channel is No Shutdown" % (self.shbfd,intf), html = 1)
                        else:
                            genericLib().robolog("\n<b><font face=\"verdana\" color=\"red\">FAIL: Command %s output verification failed: BFD neighborship is not 'Up' on interface %s after No shutting Down First port in the port-channel </b>" % (self.shbfd,intf), html = 1)
                            self.failed_steps_count+=1
		    else:
			genericLib().robolog("\n<font face=\"verdana\" color=\"DarkMagenta\">Verifying %s output  for BFD neighborship status Up  on interface %s " % (self.shbfd, intf), html = 1)
		        self.verifyresult = Verifications().verify_show_bfd_neighbors(self.parseresult,intf,'Up')
		        if self.verifyresult:
                            genericLib().robolog("\n<font face=\"verdana\" color=\"green\">Command %s output verification success: BFD status is 'Up' on interface %s as expected after No shutting Down Second  port in the port-channel" % (self.shbfd,intf), html = 1)
                        else:
                            genericLib().robolog("\n<b><font face=\"verdana\" color=\"red\">FAIL: Command %s output verification failed: BFD neighborship is not 'Up' on interface %s even after No shutting Down Second  port in the port-channel </b>" % (self.shbfd,intf), html = 1)
                            self.failed_steps_count+=1
                else:
                    genericLib().robolog("\n<b><font face=\"verdana\" color=\"red\">FAIL : Parsing %s output failed </b>" % self.shbfd, html = 1)
                    self.failed_steps_count+=1                    
            if self.failed_steps_count:
                BuiltIn().run_keyword_and_continue_on_failure("fail",(str(self.failed_steps_count))+" test steps failed")

###############################  Configuring Fake ip on port-Channel interface on Deive_1 and  expecting Bfd neighbor entry to go  down ##############

	genericLib().robolog("\n<b><font face=\"verdana\" color=\"blue\">Section-61.06: Configuring fake ip address  on port-Channel Interface %s on device %s and expecting the BFD neighborship  to go down</b>" % (self.pcid_1,duts[0]), html = 1)
        genericLib().robolog("\n<font face=\"verdana\" color=\"DarkMagenta\">configuring fake ip %s address on port-Channel interface %s " % (self.fake_ip,self.pcid_1),html = 1)
	time_diff = 0
	diff_time = 0
	show_clock_out = self.dh.dut_command([duts[0]],self.shclk)
        sys_clock_parser = obj1.parse_cmd(duts[0],'show clock',show_clock_out)
        sys_time = sys_clock_parser[1]['clock_out']['time']
        systime = re.search(r'([\d]+)\:([\d]+)\:([\d]+)\.([\d]+)',sys_time).groups()
        sys_hrs,sys_min,sys_sec,sys_msec = int(systime[0]),int(systime[1]),int(systime[2]),int(systime[3])
        sys_clock_total_milli_seconds = (sys_hrs*3600000)+(sys_min*60000)+(sys_sec*1000)+(sys_msec)
	config_cmd1=obj.config_ip_address(self.fake_ip, self.mask, self.pcid_1)
        keys = sorted(config_cmd1)
        for ip in keys:
            config_ip = self.dh.dut_command([duts[0]],config_cmd1[ip])
	time.sleep(5)
        show_logging_out = self.dh.dut_command([duts[0]],self.shlgng,timeout =60)
	show_loggign_out_parser = obj1.parse_cmd(duts[0],'show logging',show_logging_out)
        logs = show_loggign_out_parser[1]['Log']
        for log in logs:
	    if re.search(r'([\d]+)\:([\d]+)\:([\d]+)\.([\d]+)',log) == '': continue
            if re.search(r'.*BFD-(\d+)-SESSION_STATE_DOWN*.',log) != None:
                if self.ip_2 in log:
		    if re.search(r'([\d]+)\:([\d]+)\:([\d]+)\.([\d]+)',log) != None:
                    	bfd_down_time = re.search(r'.*\s+([\d]+)\:([\d]+)\:([\d]+)\.([\d]+).*', log).groups()
                    	bfd_hrs,bfd_min,bfd_sec,bfd_msec = int(bfd_down_time[0]), int(bfd_down_time[1]),int(bfd_down_time[2]), int(bfd_down_time[3])
                    	bfd_down_total_milli_seconds = (bfd_hrs*3600000)+(bfd_min*60000)+(bfd_sec*1000)+(bfd_msec)
                    	time_diff = (bfd_down_total_milli_seconds - sys_clock_total_milli_seconds)
	    if re.search(r'.*BFD-(\d+)-SESSION_REMOVED*.',log) != None:
		if self.ip_2 in log:
		    if re.search(r'([\d]+)\:([\d]+)\:([\d]+)\.([\d]+)',log) != None:
                    	bfd_removed_time = re.search(r'.*\s+([\d]+)\:([\d]+)\:([\d]+)\.([\d]+).*', log).groups()
                    	bfd_hrs,bfd_min,bfd_sec,bfd_msec = int(bfd_removed_time[0]), int(bfd_removed_time[1]),int(bfd_removed_time[2]), int(bfd_removed_time[3])
                    	bfd_removed_total_milli_seconds = (bfd_hrs*3600000)+(bfd_min*60000)+(bfd_sec*1000)+(bfd_msec)
                    	diff_time = (bfd_removed_total_milli_seconds - sys_clock_total_milli_seconds)
        genericLib().robolog("\ntime taken by bfd to detect link down is %s milli seconds " % time_diff, html = 1)
        #if (time_diff > 1000 or  time_diff <= 0):
         #   genericLib().robolog("\n<b><font face=\"verdana\" color=\"red\">FAIL: BFD Session Down event not logged within 1  sec when fake ip configured on port-channel<\b>", html = 1 )
	  #  self.failed_steps_count+=1
        #else:
         #   genericLib().robolog("\n<b><font face=\"verdana\" color=\"green\">BFD-SESSION Down event generated within 1 sec when fake ip configured on port-channel,as expected" , html = 1)
        for dut in self.dutall:
            if dut == duts[0]:
                intf = self.pcid_1
            else:
                intf = self.pcid_2
            genericLib().robolog("\n<b><font face=\"verdana\" color=\"SaddleBrown\">Parsing and Verifying %s output on Device %s after configuring Fake ip on port-Channel interface of Device %s </b>" % (self.shbfd, dut, duts[0]), html = 1)
	    show_ip_interface_brief = self.dh.dut_command([dut],"show ip interface brief")
            genericLib().robolog("\n<font face=\"verdana\" color=\"DarkMagenta\">Parsing %s output " % self.shbfd, html = 1)
            bfd_nghbrs_out = self.dh.dut_command([dut],self.shbfd)
            self.parseresult = obj1.parse_cmd(dut,'show bfd neighbors',bfd_nghbrs_out)
            if self.parseresult[0]:
                genericLib().robolog("\n<font face=\"verdana\" color=\"green\">Command %s output parsing successful " % self.shbfd , html = 1)
                genericLib().robolog("\n<font face=\"verdana\" color=\"DarkMagenta\">Verifying %s output for BFD neighborship to go Down on interface %s" % (self.shbfd, intf), html = 1)
                self.verifyresult = Verifications().verify_show_bfd_neighbors(self.parseresult,intf,'Down')
                if self.verifyresult:
                    genericLib().robolog("\n<font face=\"verdana\" color=\"green\">Command %s output verification success: BFD neighborship goes Down  on interface %s after configuring Fake Ip on it" % (self.shbfd,intf), html = 1)
		    if dut == duts[0]:
		        genericLib().robolog("\nTime taken to remove bfd entry on port-channel %s  interface after Configuring Fake ip on it is %s Milli Seconds" % (intf,diff_time),html = 1 )
                else:
                    genericLib().robolog("\n<font face=\"verdana\" color=\"red\">FAIL: Command %s output verification failed: BFD neighborship not goes Down on interface %s even after configuring Fake ip on it" % (self.shbfd, intf), html = 1)
                    self.failed_steps_count+=1
            else:
                genericLib().robolog("\n<font face=\"verdana\" color=\"red\">FAIL: Parsing %s output failed" % self.shbfd, html = 1)
                self.failed_steps_count+=1
            if self.failed_steps_count:
                BuiltIn().run_keyword_and_continue_on_failure("fail",(str(self.failed_steps_count))+" test steps failed")

############################### Re-configruing original  ip and expecting bfd neighborship to  retain on vlan Interface ######################

        genericLib().robolog("\n<b><font face=\"verdana\" color=\"blue\">Section-61.07: Re-Configuring Original ip address on Interface %s  on device %s  and Expecting BFD neighborship Retains on Both Devices</b>" % (self.pcid_1,duts[0]), html = 1)
        genericLib().robolog("\n<font face=\"verdana\" color=\"DarkMagenta\">Configuring Origonal ip address %s on port-Channel interface %s on device %s " % (self.ip_1,self.pcid_1,duts[0]), html = 1)
        config_cmd1=obj.config_ip_address(self.ip_1, self.mask, self.pcid_1)
        keys = sorted(config_cmd1)
        for ip in keys:
            config_ip = self.dh.dut_command([duts[0]],config_cmd1[ip])
        genericLib().robolog ("\nwaiting for 60 seconds to retian BFD neighborship after original ip configured")
        time.sleep(60)
        for dut in self.dutall:
            if dut == duts[0]:
                intf = self.pcid_1
            else:
                intf = self.pcid_2          
            genericLib().robolog("\n<b><font face=\"verdana\" color=\"SaddleBrown\">Parsing and Verifying %s output on device %s after Re-Configuring Original ip on port-Channel interface of Device %s </b>" % (self.shbfd, dut, duts[0]), html = 1)
	    show_ip_interface_brief = self.dh.dut_command([dut],"show ip interface brief")
            genericLib().robolog("\n<font face=\"verdana\" color=\"DarkMagenta\">Parsing %s output" % (self.shbfd), html=1) 
            bfd_nghbrs_out = self.dh.dut_command([dut],self.shbfd)
            self.parseresult = obj1.parse_cmd(dut,'show bfd neighbors',bfd_nghbrs_out)               
            if self.parseresult[0]:
                genericLib().robolog("\n<font face=\"verdana\" color=\"green\">Command %s output parsing successful on device %s " % (self.shbfd, dut), html = 1)
                genericLib().robolog("\n<font face=\"verdana\" color=\"DarkMagenta\">Verifying %s output for BFD neighborship to retain on interface %s after configuring original ip address" % (self.shbfd,intf), html = 1)
                self.verifyresult = Verifications().verify_show_bfd_neighbors(self.parseresult,intf, 'Up')
                if self.verifyresult:
                    genericLib().robolog("\n<font face=\"verdana\" color=\"green\">Command %s output verification success: BFD neighborship retained on interface %s after configuring original ip address " % (self.shbfd, intf), html = 1)
                else:
                    genericLib().robolog("\n<font face=\"verdana\" color=\"red\">FAIL: Command %s output verification failed: BFD neighborship not retained on interface %s even after configuring original ip address " % (self.shbfd, dut), html = 1)
                    self.failed_steps_count+=1
            else:
                genericLib().robolog("\n<font face=\"verdana\" color=\"red\">FAIL: Parsing %s output failed " % self.shbfd, html = 1)
                self.failed_steps_count+=1                    
            if self.failed_steps_count:
            	BuiltIn().run_keyword_and_continue_on_failure("fail",(str(self.failed_steps_count))+" test steps failed")

######################### Disconnecting Physical links ###########################################

	genericLib().robolog("\n<b><font face=\"verdana\" color=\"blue\">Sections-61.08,61.09: Performing physical links disconnect in port-Channel on Device %s and Expecting BFD neighborship to go Down</b>" % duts[0], html = 1)
	for port in self.port_1: 
	    if port == self.port_1[1]:
		diff_time  = 0
		genericLib().robolog("\nplease Disconnect the Physical link connected to interface %s on device %s in %s seconds" % (port,duts[0],self.sleep),console=1)
		time.sleep(self.sleep)
		shint = "\nshow interface id"
		shint = shint.replace('id',port)
		show_intf = self.dh.dut_command([duts[0]],shint,timeout = 10)
		show_logging_out = self.dh.dut_command([duts[0]],self.shlgng,timeout = 60)
        	show_loggign_out_parser = obj1.parse_cmd(dut,'show logging',show_logging_out)
        	logs = show_loggign_out_parser[1]['Log']
		#portid = re.sub(r'([a-zA-Z])','',self.pcid_1)
        	for log in logs:
            	    if re.search(r'BFD-(\d+)-SESSION_STATE_DOWN',log) != None:
                	if self.ip_2 in log:
                            if re.search(r'([\d]+)\:([\d]+)\:([\d]+)\.([\d]+)',log) != None:
                        	bfd_down_time = re.search(r'([\d]+)\:([\d]+)\:([\d]+)\.([\d]+)', log).groups()
                                bfd_hrs,bfd_min,bfd_sec,bfd_msec = int(bfd_down_time[0]), int(bfd_down_time[1]),int(bfd_down_time[2]), int(bfd_down_time[3])
                                bfd_down_total_milli_seconds = (bfd_hrs*3600000)+(bfd_min*60000)+(bfd_sec*1000)+(bfd_msec)
            	    if re.search(r'DOWN_PORT_CHANNEL_MEMBERS_DOWN',log) != None:
                            if re.search(r'([\d]+)\:([\d]+)\:([\d]+)\.([\d]+)',log) != None:
                                admin_down_time = re.search(r'([\d]+)\:([\d]+)\:([\d]+)\.([\d]+)',log).groups()
                                admin_hrs,admin_min,admin_sec,admin_msec = int(admin_down_time[0]), int(admin_down_time[1]),int(admin_down_time[2]), int(admin_down_time[3])
                                admin_down_total_milli_seconds = (admin_hrs*3600000)+(admin_min*60000)+(admin_sec*1000)+(admin_msec)
		diff_time = abs(admin_down_total_milli_seconds - bfd_down_total_milli_seconds)
		genericLib().robolog("\nBFD session down event logged %s milli-seconds before the link failure event logged when physical link disconnected" % (diff_time))
        	if diff_time >= 0:
            	    genericLib().robolog("\n<b><font face=\"verdana\" color=\"green\">BFD properly logged Session Down event before the link Failure event logged when physical link is disconnected manually </b>", html = 1 )
                else:
                    genericLib().robolog("\n<b><font face=\"verdana\" color=\"red\">FAIL: BFD-SESSION Down event not logged before link Failure event logged when physical link disconnected" , html = 1)
	            self.failed_steps_count+=1
	    else:
		genericLib().robolog("\nplease Disconnect the Physical link connected to interface %s on device %s in %s seconds" % (port,duts[0],self.sleep),console=1)
		time.sleep(self.sleep)                	
		shint = "\nshow interface id"
		shint = shint.replace('id',port)
		show_intf = self.dh.dut_command([duts[0]],shint,timeout = 10)
	    for dut in self.dutall:
                if dut == duts[0]:
                    intf = self.pcid_1
                else:
                    intf = self.pcid_2
                genericLib().robolog("\n<b><font face=\"verdana\" color=\"SaddleBrown\">Parsing and Verifying %s command output on Device %s for BFD entry status on Interface %s </b>" % (self.shbfd,dut, intf), html = 1)
                genericLib().robolog("\n<font face=\"verdana\" color=\"DarkMagenta\">Parsing %s output" % self.shbfd, html = 1)
                bfd_nghbrs_out = self.dh.dut_command([dut],self.shbfd)
                self.parseresult = obj1.parse_cmd(dut,'show bfd neighbors',bfd_nghbrs_out)                
                if self.parseresult[0]:
                    genericLib().robolog("\n<font face=\"verdana\" color=\"green\">Command %s output  parsing successful " % self.shbfd, html = 1)                  
		    if port == self.port_1[0]:
			genericLib().robolog("\n<font face=\"verdana\" color=\"DarkMagenta\">Verifying %s output  for BFD neighborship status Up on interface %s " % (self.shbfd, intf), html = 1)
                        self.verifyresult = Verifications().verify_show_bfd_neighbors(self.parseresult,intf,'Up')		
                        if self.verifyresult:
                            genericLib().robolog("\n<font face=\"verdana\" color=\"green\">Command %s output verification success: BFD status is 'Up' on interface %s as expected when pysical link connected to port %s is disconnected" % (self.shbfd,intf,self.port_1[0]), html = 1)
                        else:
                            genericLib().robolog("\n<b><font face=\"verdana\" color=\"red\">FAIL: Command %s output verification failed: BFD neighborship gone Down on Interface %s when physical link connected to port %s is disconnected </b>" % (self.shbfd,intf,self.port_1[0]), html = 1)
                            self.failed_steps_count+=1
		    else:
			genericLib().robolog("\n<font face=\"verdana\" color=\"DarkMagenta\">Verifying %s output  for BFD neighborship status Down on interface %s " % (self.shbfd, intf), html = 1)
		        self.verifyresult = Verifications().verify_show_bfd_neighbors(self.parseresult,intf,'Down')
		        if self.verifyresult:
                            genericLib().robolog("\n<font face=\"verdana\" color=\"green\">Command %s output verification success: BFD status is 'Down' on interface %s as expected after physical link connected to port %s is disconnected" % (self.shbfd,intf,self.port_1[1]), html = 1)  
                        else:
                            genericLib().robolog("\n<b><font face=\"verdana\" color=\"red\">FAIL: Command %s output verification failed: BFD neighborship is not goes 'Down' on interface %s even after the physical link connected to port %s is disconnected </b>" % (self.shbfd,intf,self.port_1[1]), html = 1)
                            self.failed_steps_count+=1
                else:
                    genericLib().robolog("\n<b><font face=\"verdana\" color=\"red\">FAIL: Parsing %s output failed </b>" % self.shbfd, html = 1)
                    self.failed_steps_count+=1                    
            if self.failed_steps_count:
                BuiltIn().run_keyword_and_continue_on_failure("fail",(str(self.failed_steps_count))+" test steps failed")

############################## Reconnecting Physical Links ######################################

        genericLib().robolog("\n<b><font face=\"verdana\" color=\"blue\">Sections-61.10,61.11: Reconnecting the Disconnected physical links and Expecting BFD to come Up</b>",html=1)
	for port in self.port_1:
	    genericLib().robolog("\nPlease Re-connect the disconnected  physical link  to port %s on Device %s in %s seconds" % (port,duts[0],self.sleep),console=1)
            time.sleep(self.sleep)
	    shint = "\nshow interface id"
            shint = shint.replace('id',port)
            show_intf = self.dh.dut_command([duts[0]],shint,timeout = 10)
            for dut in self.dutall:
            	if dut == duts[0]:
                    intf = self.pcid_1
                else:
                    intf = self.pcid_2
                genericLib().robolog("\n<b><font face=\"verdana\" color=\"SaddleBrown\">Parsing and Verifying %s output on device %s after Re-Connecting the physical link</b>" % (self.shbfd, dut), html = 1)
                genericLib().robolog("\n<font face=\"verdana\" color=\"DarkMagenta\">Parsing %s output" % (self.shbfd), html=1)
                bfd_nghbrs_out = self.dh.dut_command([dut],self.shbfd)
                self.parseresult = obj1.parse_cmd(dut,'show bfd neighbors',bfd_nghbrs_out)
                if self.parseresult[0]:
                    genericLib().robolog("\n<font face=\"verdana\" color=\"green\">Command %s output parsing successful on device %s " % (self.shbfd, dut), html = 1)
		    genericLib().robolog("\n<font face=\"verdana\" color=\"DarkMagenta\">Verifying %s output for BFD neighborship comes Up  on Interface %s" % (self.shbfd,intf), html = 1)
                    self.verifyresult = Verifications().verify_show_bfd_neighbors(self.parseresult,intf,'Up')
                    if self.verifyresult:
                        genericLib().robolog("\n<font face=\"verdana\" color=\"green\">Command %s output verification success: BFD neighborship comes Up on interface %s after the physical link re-connected to port %s " % (self.shbfd, intf, port), html = 1)
                    else:
                        genericLib().robolog("\n<font face=\"verdana\" color=\"red\">FAIL: Command %s output verification failed: BFD neighborship not comes Up on interface %s even after physical link re-connected to port" % (self.shbfd,intf,port), html = 1)
                        self.failed_steps_count+=1
                else:
                    genericLib().robolog("\n<font face=\"verdana\" color=\"red\">FAIL: Parsing %s output failed " % self.shbfd, html = 1)
                    self.failed_steps_count+=1
            if self.failed_steps_count:
                BuiltIn().run_keyword_and_continue_on_failure("fail",(str(self.failed_steps_count))+" test steps failed")

###################################  UNCONFIGURING PART  ###########################################

    def cleanup(self):
	duts=self.dutall
	obj1 = Tip_N3k_Basic_Config()
	obj=Tip_N3k_Basic_Unconfig()
        genericLib().robolog("\n<b><font face=\"verdana\" color=\"blue\">Section-61.12: UnConfiguring the configuration done as part of this test case on both Devices</b>", html = 1)
        for dut in self.dutall:
            if dut == self.dutall[0]:
                (port,intf,ip) = (self.port_1,self.pcid_1,self.ip_1)
            else:
                (port,intf,ip) = (self.port_2,self.pcid_2,self.ip_2)		
            genericLib().robolog("\n<b><font face=\"verdana\" color=\"SaddleBrown\">Removing Configuration on Device %s </b>" % dut, html = 1 )
            genericLib().robolog("\n<font face=\"verdana\" color=\"DarkMagenta\">Removing ip address %s on port-channel interface %s " % (ip,intf), html = 1)
            config_cmd=obj.delete_ip_address(intf)
            keys = sorted(config_cmd)
            for ip in keys:
                delete_ip = self.dh.dut_command([dut],config_cmd[ip])
            genericLib().robolog("\n<font face=\"verdana\" color=\"DarkMagenta\">Deleting port %s from port-Channel %s " % (port, intf), html = 1)       
            config_cmd=obj.remove_port_from_portchannel(port,intf)
            keys = sorted(config_cmd)
            for port in keys:
                remove_port_from_pc = self.dh.dut_command([dut],config_cmd[port])         
            genericLib().robolog("\n<font face=\"verdana\" color=\"DarkMagenta\">Configuring Logging TimeStamp to Seconds",html = 1)
            config_cmd=obj1.config_logging_timestamp('seconds')
            keys = sorted(config_cmd)
            for log in keys:
                 config_logging_timestamp = self.dh.dut_command([dut],config_cmd[log])
        genericLib().robolog("\n<font face=\"verdana\" color=\"DarkMagenta\">Removing BGP neighbor %s on Device %s" % (self.ip_2, duts[0]), html = 1)
        config_cmd1=obj.remove_bgp_neighbor(self.as_1,self.as_2,self.ip_2)
	keys = sorted(config_cmd1)
        for ngbhr in keys:
            remove_bgp_nghbr = self.dh.dut_command([duts[0]],config_cmd1[ngbhr])
        genericLib().robolog("\n<font face=\"verdana\" color=\"DarkMagenta\">Removing BGP neighbor %s on Device %s" % (self.ip_1, duts[1]), html = 1)
        config_cmd2=obj.remove_bgp_neighbor(self.as_2,self.as_1,self.ip_1)
	keys = sorted(config_cmd2)
        for ngbhr in keys:
            remove_bgp_nghbr = self.dh.dut_command([duts[1]],config_cmd2[ngbhr])
	genericLib().robolog("\n<font face=\"verdana\" color=\"DarkMagenta\">Removing BGP neighbor on Device %s" % duts[0],html = 1)
	nobgp = 'config\nno router bgp id\nend'
        nobgp = nobgp.replace('id',self.as_1)
        remove_bgp = self.dh.dut_command([duts[0]],nobgp)
	genericLib().robolog("\n<font face=\"verdana\" color=\"DarkMagenta\">Removing BGP neighbor on Device %s" % duts[1],html = 1)
        nobgp = nobgp.replace('id',self.as_2)
        remove_bgp = self.dh.dut_command([duts[1]],nobgp)
	genericLib().robolog("\nVerifying whether configuration deleted or not",html=1,console=1)
	bfd_nghbrs_out = self.dh.dut_command([duts[0]],self.shbfd)
	bfd_nghbrs_out = self.dh.dut_command([duts[1]],self.shbfd)
	genericLib().robolog("\n<b><font face=\"verdana\" color=\"RebeccaPurple\">Succesfully Executed \'61.0 BFD - Port Channel\' test case</b>",html=1,console=1) 

###******************************************************************************************************

class Bfd_Physical_Interface_60_0:

    def setup(self):
        self.dutall = BuiltIn().get_variable_value('${Common.DeviceList}')
        self.devicedetails=BuiltIn().get_variable_value('${Devices}')

    def test(self):
	self.parseresult = {}
        self.failed_steps_count=0
        duts = self.dutall
        obj = Tip_N3k_Basic_Config()
	obj1= parserLib(self.devicedetails)
	
####################  Perfomring Configuration part on two devices ##########################################

        genericLib().robolog("\n<b><font face=\"verdana\" color=\"blue\">Section-60.1: Configuring & verifying BFD over Physical Interface  between two Devices</b>", html =1 ) 
        for dut in self.dutall:            
            if dut == self.dutall[0]:
                (intf,ip,asn) = (self.intf_1,self.ip_1,self.as_1)
            else:
                (intf,ip,asn) = (self.intf_2,self.ip_2,self.as_2)
	    genericLib().robolog("\n<b><font face=\"verdana\" color=\"SaddleBrown\">Executing Configuration  commands on Device %s </b>" % dut, html = 1)
            genericLib().robolog("\n<font face=\"verdana\" color=\"DarkMagenta\">Configuring ip address %s on interface %s " % (ip,intf), html = 1)
            config_cmd=obj.config_ip_address(ip, self.mask, intf)
            keys = sorted(config_cmd)
            for ip in keys:
                config_ip = self.dh.dut_command([dut],config_cmd[ip])
            genericLib().robolog("\n<font face=\"verdana\" color=\"DarkMagenta\">Configuring BGP as number %s " % asn, html = 1)
            config_cmd=obj.config_bgp_router(asn)
            keys = sorted(config_cmd)
            for pid in keys:
                config_bgp_router_id = self.dh.dut_command([dut],config_cmd[pid])     
	    genericLib().robolog("\n<font face=\"verdana\" color=\"DarkMagenta\">Configuring Logging TimeStamp to Milli Seconds",html = 1)
            config_cmd=obj.config_logging_timestamp('milliseconds')
            keys = sorted(config_cmd)
            for log in keys:
                config_logging_timestamp = self.dh.dut_command([dut],config_cmd[log]) 
        genericLib().robolog("\n<font face=\"verdana\" color=\"DarkMagenta\">Configuring BGP neighbor %s on Device %s " % (self.ip_2, duts[0]), html = 1)
        config_cmd1=obj.config_bgp_neighbor(self.as_1,self.as_2,self.ip_2,self.desc_2,self.intf_1)
        keys = sorted(config_cmd1)
        for ngbhr in keys:
            config_bgp_nghbr = self.dh.dut_command([duts[0]],config_cmd1[ngbhr])
        genericLib().robolog("\n<font face=\"verdana\" color=\"DarkMagenta\">Configuring BGP neighbor %s on Device %s " % (self.ip_1, duts[1]), html = 1)
        config_cmd2=obj.config_bgp_neighbor(self.as_2,self.as_1,self.ip_1,self.desc_1,self.intf_2)
        keys = sorted(config_cmd2)
        for ngbhr in keys:
            config_bgp_nghbr = self.dh.dut_command([duts[1]],config_cmd2[ngbhr])                 

#################### verification of bfd status on both devices ############################

	genericLib().robolog ("\nwaiting for 40 seconds to form BFD neighbors between the Devices")
	time.sleep(40)       
	genericLib().robolog("\n<font face=\"verdana\" color=\"SaddleBrown\">Executing below show commands just for debugging purpose. Not verifying anyhting in the command output", html = 1)
        for dut in self.dutall:
            bgp_summary  = self.dh.dut_command([dut],"show ip bgp summary")
            interface_brief  = self.dh.dut_command([dut],"show ip interface brief")
        for dut in self.dutall:
            if dut == duts[0]:
                intf = self.intf_1
            else:
                intf = self.intf_2
            genericLib().robolog("\n<b><font face=\"verdana\" color=\"SaddleBrown\">Parsing and Verifying Configuration in %s command output on Device %s </b>" % (self.shbfd,dut), html = 1)
            genericLib().robolog("\n<font face=\"verdana\" color=\"DarkMagenta\">Parsing %s output" % self.shbfd, html = 1)
            bfd_nghbrs_out = self.dh.dut_command([dut],self.shbfd)
            self.parseresult = obj1.parse_cmd(dut,'show bfd neighbors',bfd_nghbrs_out)                
            if self.parseresult[0]:
                genericLib().robolog("\n<b><font face=\"verdana\" color=\"green\">Command %s output  parsing successful</b>" % self.shbfd, html = 1)
                genericLib().robolog("\n<font face=\"verdana\" color=\"DarkMagenta\">Verifying %s output  for BFD neighborship status UP on interface %s " % (self.shbfd, intf), html = 1)
                self.verifyresult = Verifications().verify_show_bfd_neighbors(self.parseresult,intf,'Up')
                if self.verifyresult:
                    genericLib().robolog("\n<b><font face=\"verdana\" color=\"green\">Command %s output verification success: BFD status is 'UP' on interface %s as expected </b>" % (self.shbfd,intf), html = 1)
                else:
                    genericLib().robolog("\n<b><font face=\"verdana\" color=\"red\">FAIL: Command %s output verification failed: BFD neighborship is not 'UP' on interface %s </b>" % (self.shbfd,intf), html = 1)
                    self.failed_steps_count+=1
            else:
                genericLib().robolog("\n<b><font face=\"verdana\" color=\"red\">FAIL: Parsing %s output failed </b>" % self.shbfd, html = 1)
                self.failed_steps_count+=1                    
            if self.failed_steps_count:
                BuiltIn().run_keyword_and_continue_on_failure("fail",(str(self.failed_steps_count))+" test steps failed")    

####################### Shutting Donw physical interface on Device_1 and expecting bfd neighborship to go  down ############
                    
        genericLib().robolog("\n<b><font face=\"verdana\" color=\"blue\">Section-60.2: Performing physical interfaces shutdown  on Device %s and Expecting BFD neighborship to go down</b>" % duts[0], html = 1)
	time_diff = 0
	diff_time = 0
	show_clock_out = self.dh.dut_command([duts[0]],self.shclk)
	sys_clock_parser = obj1.parse_cmd(duts[0],'show clock',show_clock_out)
	sys_time = sys_clock_parser[1]['clock_out']['time']		
	systime = re.search(r'([\d]+)\:([\d]+)\:([\d]+)\.([\d]+)',sys_time).groups()
	sys_hrs,sys_min,sys_sec,sys_msec = int(systime[0]),int(systime[1]),int(systime[2]),int(systime[3])
	sys_clock_total_milli_seconds = (sys_hrs*3600000)+(sys_min*60000)+(sys_sec*1000)+(sys_msec)				
	genericLib().robolog("\n<font face=\"verdana\" color=\"DarkMagenta\">Shutting down Physical Interface %s" % (self.intf_1), html = 1)
        config_cmd1=obj.shutdown_interface(self.intf_1,'shut')
        keys = sorted(config_cmd1)
        for intf in keys:
            interface_shutdown = self.dh.dut_command([duts[0]],config_cmd1[intf])
        time.sleep(5)
	shintf = '\nshow interface id'
        shintf = shintf.replace('id',self.intf_1)
        shintf_out = self.dh.dut_command([duts[0]],shintf)
	show_logging_out = self.dh.dut_command([duts[0]],self.shlgng,timeout = 60) 	
	show_loggign_out_parser = obj1.parse_cmd(dut,'show logging',show_logging_out)
	logs = show_loggign_out_parser[1]['Log']
	for log in logs:
	    if re.search(r'BFD-(\d+)-SESSION_STATE_DOWN',log) != None:
		if self.ip_2 in log: 
		    if re.search(r'([\d]+)\:([\d]+)\:([\d]+)\.([\d]+)',log) != None:
	                bfd_down_time = re.search(r'([\d]+)\:([\d]+)\:([\d]+)\.([\d]+)', log).groups()
		        bfd_hrs,bfd_min,bfd_sec,bfd_msec = int(bfd_down_time[0]), int(bfd_down_time[1]),int(bfd_down_time[2]), int(bfd_down_time[3])
		        bfd_down_total_milli_seconds = (bfd_hrs*3600000)+(bfd_min*60000)+(bfd_sec*1000)+(bfd_msec)
	                time_diff = (bfd_down_total_milli_seconds - sys_clock_total_milli_seconds)
	    if re.search(r'BFD-(\d+)-SESSION_REMOVED',log) != None:
		if self.ip_2 in log: 
		    if re.search(r'([\d]+)\:([\d]+)\:([\d]+)\.([\d]+)',log) != None:
	                bfd_removed_time = re.search(r'([\d]+)\:([\d]+)\:([\d]+)\.([\d]+)',log).groups()
		        bfd_hrs,bfd_min,bfd_sec,bfd_msec = int(bfd_removed_time[0]), int(bfd_removed_time[1]),int(bfd_removed_time[2]), int(bfd_removed_time[3])
		        bfd_removed_total_milli_seconds = (bfd_hrs*3600000)+(bfd_min*60000)+(bfd_sec*1000)+(bfd_msec)
	                diff_time = (bfd_removed_total_milli_seconds - sys_clock_total_milli_seconds)
	genericLib().robolog("\ntime taken by  bfd to detect link  down  when physical link administratively shutdown is %s milli seconds " % time_diff, html = 1)
	if (time_diff > 1000 or time_diff <= 0):
	    genericLib().robolog("\n<b><font face=\"verdana\" color=\"red\">FAIL: BFD not detected link  down within 1 sec, when the physical interface %s administratively shutdown <\b>" % self.intf_1, html = 1 )
	    self.failed_steps_count+=1
        else:
	    genericLib().robolog("\n<b><font face=\"verdana\" color=\"green\">BFD-SESSION Down event Logged within 1 sec of physical link %s down, as expected </b>" % self.intf_1, html = 1)	
	for dut in self.dutall:
            if dut == duts[0]:
                intf = self.intf_1
            else:
                intf = self.intf_2
            genericLib().robolog("\n<b><font face=\"verdana\" color=\"SaddleBrown\">Parsing and Verifying %s command output on Device %s for BFD entry status on Interface %s </b>" % (self.shbfd,dut, intf), html = 1)
            genericLib().robolog("\n<font face=\"verdana\" color=\"DarkMagenta\">Parsing %s output" % self.shbfd, html = 1)
            bfd_nghbr_out = self.dh.dut_command([dut],self.shbfd)
            self.parseresult = obj1.parse_cmd(dut,'show bfd neighbors',bfd_nghbr_out)                
            if self.parseresult[0]:
                genericLib().robolog("\n<font face=\"verdana\" color=\"green\">Command %s output  parsing successful " % self.shbfd, html = 1)
                genericLib().robolog("\n<font face=\"verdana\" color=\"DarkMagenta\">Verifying %s output  for BFD neighborship status Down on interface %s " % (self.shbfd, intf), html = 1)
                self.verifyresult = Verifications().verify_show_bfd_neighbors(self.parseresult,intf,'Down')
                if self.verifyresult:
                    genericLib().robolog("\n<font face=\"verdana\" color=\"green\">Command %s output verification success: BFD status is 'Down' on interface %s as expected after shutting Down the Interface </b>" % (self.shbfd,intf), html = 1)
		    if dut == duts[0]:
			genericLib().robolog("\nTime taken to bfd entry go down after shutting down the interface is %s milli seconds" % diff_time, html = 1)
                else:
                    genericLib().robolog("\n<b><font face=\"verdana\" color=\"red\">FAIL: Command %s output verification failed: BFD neighborship is not 'Down' even after shutting Down the Interafce %s </b>" % (self.shbfd,intf), html = 1)
                    self.failed_steps_count+=1
            else:
                genericLib().robolog("\n<b><font face=\"verdana\" color=\"red\">FAIL: Parsing %s output failed </b>" % self.shbfd, html = 1)
                self.failed_steps_count+=1                    
            if self.failed_steps_count:
                BuiltIn().run_keyword_and_continue_on_failure("fail",(str(self.failed_steps_count))+" test steps failed") 

####################### No Shutting Donw physical interface on Device_1 and expecting bfd neighborship to Retain ############                    

        genericLib().robolog("\n<b><font face=\"verdana\" color=\"blue\">Section-60.3: Performing physical interfaces No shutdown  on Device %s and Expecting BFD neighborship to Retain</b>" % duts[0], html = 1)
        genericLib().robolog("\n<font face=\"verdana\" color=\"DarkMagenta\">No Shutting down Physical Interface %s" % self.intf_1,html = 1)
        config_cmd1=obj.shutdown_interface(self.intf_1,'no shut')
        keys = sorted(config_cmd1)
        for intf in keys:
            no_shutdown_intf = self.dh.dut_command([duts[0]],config_cmd1[intf])
        genericLib().robolog("\nwaiting for 60 sec to verify bfd neighborship after the Interface no shutdown") 
        time.sleep(60)
        shintf_out = self.dh.dut_command([duts[0]],shintf)
        for dut in self.dutall:
            if dut == duts[0]:
                intf = self.intf_1
            else:
                intf = self.intf_2
            genericLib().robolog("\n<b><font face=\"verdana\" color=\"SaddleBrown\">Parsing and Verifying %s command output on Device %s for BFD entry status on Interface %s </b>" % (self.shbfd,dut, intf), html = 1)
            genericLib().robolog("\n<font face=\"verdana\" color=\"DarkMagenta\">Parsing %s output" % self.shbfd, html = 1)
            bfd_nghbrs_out = self.dh.dut_command([dut],self.shbfd)
            self.parseresult = obj1.parse_cmd(dut,'show bfd neighbors',bfd_nghbrs_out)                
            if self.parseresult[0]:
                genericLib().robolog("\n<font face=\"verdana\" color=\"green\">Command %s output  parsing successful " % self.shbfd, html = 1)
	        genericLib().robolog("\n<font face=\"verdana\" color=\"DarkMagenta\">Verifying %s output  for BFD neighborship status Up on interface %s " % (self.shbfd, intf), html = 1)
                self.verifyresult = Verifications().verify_show_bfd_neighbors(self.parseresult,intf,'Up')
	        if self.verifyresult:
                    genericLib().robolog("\n<font face=\"verdana\" color=\"green\">Command %s output verification success: BFD status is 'Up' on interface %s as expected when the Interface is No Shutdown" % (self.shbfd,intf), html = 1)
                else:
                    genericLib().robolog("\n<b><font face=\"verdana\" color=\"red\">FAIL: Command %s output verification failed: BFD neighborship is not 'Up' on interface %s after No shutdown it </b>" % (self.shbfd,intf), html = 1)
                    self.failed_steps_count+=1
            else:
                genericLib().robolog("\n<b><font face=\"verdana\" color=\"red\">FAIL: Parsing %s output failed </b>" % self.shbfd, html = 1)
                self.failed_steps_count+=1                    
            if self.failed_steps_count:
                BuiltIn().run_keyword_and_continue_on_failure("fail",(str(self.failed_steps_count))+" test steps failed") 

############################### Configuring Fake ip on interface on Deive_1 and  expecting Bfd neighbor entry to go  down ##############

        genericLib().robolog("\n<b><font face=\"verdana\" color=\"blue\">Section-60.4: Configuring fake ip address on Interface %s on device %s and expecting the BFD neighborship  to go down</b>" % (self.intf_1,duts[0]), html = 1)
        genericLib().robolog("\n<font face=\"verdana\" color=\"DarkMagenta\">configuring fake ip %s address on interface %s " % (self.fake_ip,self.intf_1), html = 1)
	time_diff = 0
	diff_time = 0
	show_clock_out = self.dh.dut_command([duts[0]],self.shclk)
        sys_clock_parser = obj1.parse_cmd(duts[0],'show clock',show_clock_out)
        sys_time = sys_clock_parser[1]['clock_out']['time']
        systime = re.search(r'([\d]+)\:([\d]+)\:([\d]+)\.([\d]+)',sys_time).groups()
        sys_hrs,sys_min,sys_sec,sys_msec = int(systime[0]),int(systime[1]),int(systime[2]),int(systime[3])
        sys_clock_total_milli_seconds = (sys_hrs*3600000)+(sys_min*60000)+(sys_sec*1000)+(sys_msec)
	config_cmd1=obj.config_ip_address(self.fake_ip, self.mask, self.intf_1)
        keys = sorted(config_cmd1)
        for ip in keys:
            config_fake_ip = self.dh.dut_command([duts[0]],config_cmd1[ip])
	time.sleep(5)
	shipintfbrf = self.dh.dut_command([duts[0]],'show ip interface brief')
        show_logging_out = self.dh.dut_command([duts[0]],self.shlgng,timeout = 60)
        show_loggign_out_parser = obj1.parse_cmd(dut,'show logging',show_logging_out)
        logs = show_loggign_out_parser[1]['Log']
        for log in logs:
            if re.search(r'BFD-(\d+)-SESSION_STATE_DOWN',log) != None:
                if self.ip_2 in log: 
		    if re.search(r'([\d]+)\:([\d]+)\:([\d]+)\.([\d]+)',log) != None:
	                bfd_down_time = re.search(r'([\d]+)\:([\d]+)\:([\d]+)\.([\d]+)', log).groups()
		        bfd_hrs,bfd_min,bfd_sec,bfd_msec = int(bfd_down_time[0]), int(bfd_down_time[1]),int(bfd_down_time[2]), int(bfd_down_time[3])
		        bfd_down_total_milli_seconds = (bfd_hrs*3600000)+(bfd_min*60000)+(bfd_sec*1000)+(bfd_msec)
	                time_diff = (bfd_down_total_milli_seconds - sys_clock_total_milli_seconds)
	    if re.search(r'BFD-(\d+)-SESSION_REMOVED',log) != None:
		if self.ip_2 in log: 
		    if re.search(r'([\d]+)\:([\d]+)\:([\d]+)\.([\d]+)',log) != None:
	                bfd_removed_time = re.search(r'([\d]+)\:([\d]+)\:([\d]+)\.([\d]+)',log).groups()
		        bfd_hrs,bfd_min,bfd_sec,bfd_msec = int(bfd_removed_time[0]), int(bfd_removed_time[1]),int(bfd_removed_time[2]), int(bfd_removed_time[3])
		        bfd_removed_total_milli_seconds = (bfd_hrs*3600000)+(bfd_min*60000)+(bfd_sec*1000)+(bfd_msec)
	                diff_time = (bfd_removed_total_milli_seconds - sys_clock_total_milli_seconds)
        genericLib().robolog("\ntime taken to  bfd to go down when fake ip configured is %s milli seconds " % time_diff, html = 1)
        #if (time_diff > 1000 or time_diff <= 0):
         #   genericLib().robolog("\n<b><font face=\"verdana\" color=\"red\">FAIL: BFD Session Down event not logged within 1 sec when fake ip configured on Interafce\n  </b>", html = 1 )
          #  self.failed_steps_count+=1
       # else:
        #    genericLib().robolog("\n<b><font face=\"verdana\" color=\"green\">BFD-SESSION Down event logged within 1 sec when fake ip configured on ,as expected \n" , html = 1)
        for dut in self.dutall:
            if dut == duts[0]:
                intf = self.intf_1
            else:
                intf = self.intf_2
            genericLib().robolog("\n<b><font face=\"verdana\" color=\"SaddleBrown\">Parsing and Verifying %s output on Device %s after configuring Fake ip on Interface </b>" % (self.shbfd, dut), html = 1)
            genericLib().robolog("\n<font face=\"verdana\" color=\"DarkMagenta\">Parsing %s output " % self.shbfd, html = 1)
            bfd_nghbrs_out = self.dh.dut_command([dut],self.shbfd)
            self.parseresult = obj1.parse_cmd(dut,'show bfd neighbors',bfd_nghbrs_out)
            if self.parseresult[0]:
                genericLib().robolog("\n<font face=\"verdana\" color=\"green\">Command %s output parsing successful " % self.shbfd , html = 1)
                genericLib().robolog("\n<font face=\"verdana\" color=\"DarkMagenta\">Verifying %s output for BFD neighborship to go Down on interface %s" % (self.shbfd, intf), html = 1)
                self.verifyresult = Verifications().verify_show_bfd_neighbors(self.parseresult,intf,'Down')
                if self.verifyresult:
                    genericLib().robolog("\n<font face=\"verdana\" color=\"green\">Command %s output verification success: BFD neighborship goes Down  on interface %s after configuring Fake Ip on it" % (self.shbfd,intf), html = 1)
		    if dut == duts[0]:
			genericLib().robolog("\nTime taken to remove bfd entry after configuring fake ip is %s milli seconds" % diff_time, html = 1)
                else:
                    genericLib().robolog("\n<font face=\"verdana\" color=\"red\">FAIL: Command %s output verification failed: BFD neighborship not goes Down on interface %s even after configuring Fake ip on it" % (self.shbfd, intf), html = 1)
                    self.failed_steps_count+=1
            else:
                genericLib().robolog("*\n<font face=\"verdana\" color=\"red\">FAIL: Parsing %s output failed" % self.shbfd, html = 1)
                self.failed_steps_count+=1
            if self.failed_steps_count:
                BuiltIn().run_keyword_and_continue_on_failure("fail",(str(self.failed_steps_count))+" test steps failed")

############################### Re-configruing original  ip and expecting bfd neighborship to  retain on Interface ######################

        genericLib().robolog("\n<b><font face=\"verdana\" color=\"blue\">Section-60.5: Re-Configuring Original ip address on Interface %s  on device %s  and Expecting BFD neighborship Retains on Both Devices</b>" % (self.intf_1,duts[0]), html = 1)
        genericLib().robolog("\n<font face=\"verdana\" color=\"DarkMagenta\">Configuring Origonal ip address %s on interface %s on device %s " % (self.ip_1,self.intf_1,duts[0]), html = 1)
        config_cmd1=obj.config_ip_address(self.ip_1, self.mask, self.intf_1)
        keys = sorted(config_cmd1)
        for ip in keys:
            config_ip = self.dh.dut_command([duts[0]],config_cmd1[ip])
        genericLib().robolog ("\nwaiting for 40 seconds to retian BFD neighborship after original ip configured")
        time.sleep(40)
	shipintfbrf = self.dh.dut_command([duts[0]],'show ip interface brief')
        for dut in self.dutall:
            if dut == duts[0]:
                intf = self.intf_1
            else:
                intf = self.intf_2            
            genericLib().robolog("\n<b><font face=\"verdana\" color=\"SaddleBrown\">Parsing and Verifying %s output on device %s after Re-Configuring Original ip on interface of Device %s </b>" % (self.shbfd, dut, duts[0]), html = 1)
            genericLib().robolog("\n<font face=\"verdana\" color=\"DarkMagenta\">Parsing %s output" % (self.shbfd), html=1) 
            bfd_nghbrs_out = self.dh.dut_command([dut],self.shbfd)
            self.parseresult = obj1.parse_cmd(dut,'show bfd neighbors',bfd_nghbrs_out)                
            if self.parseresult[0]:
                genericLib().robolog("\n<font face=\"verdana\" color=\"green\">Command %s output parsing successful on device %s " % (self.shbfd, dut), html = 1)
                genericLib().robolog("\n<font face=\"verdana\" color=\"DarkMagenta\">Verifying %s output for BFD neighborship to retain on interface %s after configuring original ip address" % (self.shbfd,intf), html = 1)
                self.verifyresult = Verifications().verify_show_bfd_neighbors(self.parseresult,intf, 'Up')
                if self.verifyresult:
                    genericLib().robolog("\n<font face=\"verdana\" color=\"green\">Command %s output verification success: BFD neighborship retained on interface %s after configuring original ip address " % (self.shbfd, intf), html = 1)
                else:
                    genericLib().robolog("\n<font face=\"verdana\" color=\"red\">FAIL: Command %s output verification failed: BFD neighborship not retained on interface %s even after configuring original ip address " % (self.shbfd,intf), html = 1)
                    self.failed_steps_count+=1
            else:
                genericLib().robolog("\n<font face=\"verdana\" color=\"red\">FAIL: Parsing %s output failed " % self.shbfd, html = 1)
                self.failed_steps_count+=1                    
            if self.failed_steps_count:
            	BuiltIn().run_keyword_and_continue_on_failure("fail",(str(self.failed_steps_count))+" test steps failed")

################################### Disconnecting Physical Link  ###################################

	genericLib().robolog("\n<b><font face=\"verdana\" color=\"blue\">Section-60.6: Disconnecting Physical Link and expecting BFD neibhorship to go Down </b>", html = 1)
	genericLib().robolog("\nPlease Disconnecting physical link connected to port %s on Device %s in %s seconds" % (self.intf_1,duts[0],self.sleep),console=1)
	time.sleep(self.sleep)
	shintf_out = self.dh.dut_command([duts[0]],shintf)
	diff_time = 0
	show_logging_out = self.dh.dut_command([duts[0]],self.shlgng,timeout = 60)
        show_loggign_out_parser = obj1.parse_cmd(dut,'show logging',show_logging_out)
        logs = show_loggign_out_parser[1]['Log']
	port = re.sub(r'([a-zA-Z])','',self.intf_1)
        for log in logs:
            if re.search(r'BFD-(\d+)-SESSION_STATE_DOWN',log) != None:
                if self.ip_2 in log:
                    if re.search(r'([\d]+)\:([\d]+)\:([\d]+)\.([\d]+)',log) != None:
                        bfd_down_time = re.search(r'([\d]+)\:([\d]+)\:([\d]+)\.([\d]+)', log).groups()
                        bfd_hrs,bfd_min,bfd_sec,bfd_msec = int(bfd_down_time[0]), int(bfd_down_time[1]),int(bfd_down_time[2]), int(bfd_down_time[3])
                        bfd_down_total_milli_seconds = (bfd_hrs*3600000)+(bfd_min*60000)+(bfd_sec*1000)+(bfd_msec)
            if re.search(r'DOWN_LINK_FAILURE',log) != None:
                if port in log:
                    if re.search(r'([\d]+)\:([\d]+)\:([\d]+)\.([\d]+)',log) != None:
                        admin_down_time = re.search(r'([\d]+)\:([\d]+)\:([\d]+)\.([\d]+)',log).groups()
                        admin_hrs,admin_min,admin_sec,admin_msec = int(admin_down_time[0]), int(admin_down_time[1]),int(admin_down_time[2]), int(admin_down_time[3])
                        admin_down_total_milli_seconds = (admin_hrs*3600000)+(admin_min*60000)+(admin_sec*1000)+(admin_msec)                        
	diff_time = abs(admin_down_total_milli_seconds - bfd_down_total_milli_seconds)
	genericLib().robolog("\nBFD session down event logged %s milli seconds before the link failure event logged when physical link disconnected" % (diff_time))
        if diff_time >= 0:
            genericLib().robolog("\n<b><font face=\"verdana\" color=\"green\">BFD properly logged Session Down event before the link down administratively event logged when physical link is disconnected manually<\b>", html = 1 )
        else:
            genericLib().robolog("\n<b><font face=\"verdana\" color=\"red\">FAIL: BFD-SESSION Down event not logged before link down administrativey event logged when physical link disconnected \n" , html = 1)
	    self.failed_steps_count+=1
	for dut in self.dutall:
            if dut == duts[0]:
                intf = self.intf_1
            else:
                intf = self.intf_2
            genericLib().robolog("\n<b><font face=\"verdana\" color=\"SaddleBrown\">Parsing and Verifying %s output on device %s after Disconnecting the physical link connected to interface of Device %s </b>" % (self.shbfd, dut, duts[0]), html = 1)
            genericLib().robolog("\n<font face=\"verdana\" color=\"DarkMagenta\">Parsing %s output" % (self.shbfd), html=1)
            bfd_nghbrs_out = self.dh.dut_command([dut],self.shbfd)
            self.parseresult = obj1.parse_cmd(dut,'show bfd neighbors',bfd_nghbrs_out)
            if self.parseresult[0]:
                genericLib().robolog("\n<font face=\"verdana\" color=\"green\">Command %s output parsing successful on device %s " % (self.shbfd, dut), html = 1)
                genericLib().robolog("\n<font face=\"verdana\" color=\"DarkMagenta\">Verifying %s output for BFD neighborship to go down  on interface %s after disconnecting physical link  connected to it" % (self.shbfd,intf), html = 1)
                self.verifyresult = Verifications().verify_show_bfd_neighbors(self.parseresult,intf,'Down')
                if self.verifyresult:
                    genericLib().robolog("\n<font face=\"verdana\" color=\"green\">Command %s output verification success: BFD neighborship goes down on interface %s after the physical link disconnected " % (self.shbfd, intf), html = 1)
                else:
                    genericLib().robolog("\n<font face=\"verdana\" color=\"red\">FAIL: Command %s output verification failed: BFD neighborship not goes down on interface %s even after physical link disconnected" % (self.shbfd,intf), html = 1)
                    self.failed_steps_count+=1
            else:
                genericLib().robolog("\n<font face=\"verdana\" color=\"red\">FAIL: Parsing %s output failed " % self.shbfd, html = 1)
                self.failed_steps_count+=1
            if self.failed_steps_count:
                BuiltIn().run_keyword_and_continue_on_failure("fail",(str(self.failed_steps_count))+" test steps failed")

################################### Re-Connecting the disconnected Physical link #######################################

	genericLib().robolog("\n<b><font face=\"verdana\" color=\"blue\">Step-7: Re-connecting the disconnected Physical Link and expecting BFD neibhorship to comes Up</b>", html = 1)
        genericLib().robolog("\nPlease Re-connect the disconnected  physical link connected to port %s on Device %s in %s seconds" % (self.intf_1,duts[0],self.sleep),console=1)
        time.sleep(self.sleep)
        shintf_out = self.dh.dut_command([duts[0]],shintf)
	for dut in self.dutall:
            if dut == duts[0]:
                intf = self.intf_1
            else:
                intf = self.intf_2
            genericLib().robolog("\n<b><font face=\"verdana\" color=\"SaddleBrown\">Parsing and Verifying %s output on device %s after Re-Connecting the physical link</b>" % (self.shbfd, dut), html = 1)
            genericLib().robolog("\n<font face=\"verdana\" color=\"DarkMagenta\">Parsing %s output" % (self.shbfd), html=1)
            bfd_nghbrs_out = self.dh.dut_command([dut],self.shbfd)
            self.parseresult = obj1.parse_cmd(dut,'show bfd neighbors',bfd_nghbrs_out)
            if self.parseresult[0]:
                genericLib().robolog("\n<font face=\"verdana\" color=\"green\">Command %s output parsing successful on device %s " % (self.shbfd, dut), html = 1)
                genericLib().robolog("\n<font face=\"verdana\" color=\"DarkMagenta\">Verifying %s output for BFD neighborship to comes Up on interface %s after re-connecting disconnected physical link" % (self.shbfd,intf), html = 1)
                self.verifyresult = Verifications().verify_show_bfd_neighbors(self.parseresult,intf,'Up')
                if self.verifyresult:
                    genericLib().robolog("\n<font face=\"verdana\" color=\"green\">Command %s output verification success: BFD neighborship comes Up on interface %s after the physical link re-connected " % (self.shbfd, intf), html = 1)
                else:
                    genericLib().robolog("\n<font face=\"verdana\" color=\"red\">FAIL: Command %s output verification failed: BFD neighborship not comes Up on interface %s even after physical link re-connected" % (self.shbfd,intf), html = 1)
                    self.failed_steps_count+=1
            else:
                genericLib().robolog("\n<font face=\"verdana\" color=\"red\">FAIL: Parsing %s output failed " % self.shbfd, html = 1)
                self.failed_steps_count+=1
            if self.failed_steps_count:
                BuiltIn().run_keyword_and_continue_on_failure("fail",(str(self.failed_steps_count))+" test steps failed")

###################################  UNCONFIGURING PART  ###########################################

    def cleanup(self):
	duts = self.dutall
	genericLib().robolog("\n<b><font face=\"verdana\" color=\"blue\">Section-60.8: UnConfiguring the configuration done as part of this test case on both Devices</b>",html = 1)
	obj=Tip_N3k_Basic_Unconfig()
	obj1=Tip_N3k_Basic_Config()
	nobgp = 'config\nno router bgp id\nend'
        genericLib().robolog("\n<font face=\"verdana\" color=\"DarkMagenta\">Removing BGP neighbor %s on Device %s" % (self.ip_2, duts[0]), html = 1)
        config_cmd1=obj.remove_bgp_neighbor(self.as_1,self.as_2,self.ip_2)
        keys = sorted(config_cmd1)
        for ngbhr in keys:
            remove_bgp_nghbr = self.dh.dut_command([duts[0]],config_cmd1[ngbhr])
	nobgp1 = nobgp.replace('id',self.as_1)
        remove_bgp = self.dh.dut_command([duts[0]],nobgp1)
        genericLib().robolog("\n<font face=\"verdana\" color=\"DarkMagenta\">Removing BGP neighbor %s on Device %s" % (self.ip_1, duts[1]), html = 1)
        config_cmd2=obj.remove_bgp_neighbor(self.as_2,self.as_1,self.ip_1)
        keys = sorted(config_cmd2)
        for ngbhr in keys:
            remove_bgp_nghbr = self.dh.dut_command([duts[1]],config_cmd2[ngbhr])
        nobgp2 = nobgp.replace('id',self.as_2)
        remove_bgp = self.dh.dut_command([duts[1]],nobgp2)
        genericLib().robolog("\nSuccesfully executed \'60.0 BFD - Physical Interface \' test case",html=1, console=1)
        for dut in self.dutall:
            if dut == self.dutall[0]:
                (intf,ip) = (self.intf_1,self.ip_1)
            else:
                (intf,ip) = (self.intf_2,self.ip_2)		
            genericLib().robolog("\n<b><font face=\"verdana\" color=\"SaddleBrown\">Removing Configuration on Device %s </b>" % dut, html = 1 )
	    genericLib().robolog("\n<font face=\"verdana\" color=\"DarkMagenta\">Removing ip address %s on interface %s " % (ip,intf), html = 1)
            config_cmd=obj.delete_ip_address(intf)
            keys = sorted(config_cmd)
            for ip in keys:
                delete_ip = self.dh.dut_command([dut],config_cmd[ip])      
	    genericLib().robolog("\n<font face=\"verdana\" color=\"DarkMagenta\">Setting logging timestamp config to default seconds ", html = 1)
            config_cmd=obj1.config_logging_timestamp('seconds')
            keys = sorted(config_cmd)
            for log in keys:
                config_timestamp = self.dh.dut_command([dut],config_cmd[log])
	    bfd_nghbrs_out = self.dh.dut_command([dut],self.shbfd)
	genericLib().robolog("\nSuccesfully executed \'60.0 BFD - Physical Interface \' test case",html=1, console=1)

##**************************************************************************************************************

class Bfd_Sub_Interface_63_0:

    def setup(self):
        self.dutall = BuiltIn().get_variable_value('${Common.DeviceList}')
        self.devicedetails=BuiltIn().get_variable_value('${Devices}')
	duts = self.dutall

    def test(self):
	self.parseresult = {}
        self.failed_steps_count=0
	duts = self.dutall
        obj = Tip_N3k_Basic_Config()
	obj1=parserLib(self.devicedetails)

####################  Perfomring Configuration part on two devices ##########################################

        genericLib().robolog("\n<b><font face=\"verdana\" color=\"blue\">Section-63.0: Configuring & verifying BFD over Sub Interface  between two Devices</b>", html =1 ) 
        for dut in self.dutall:            
            if dut == self.dutall[0]:
                (intf,dot1q,ip,asn) = (self.intf_1,self.dot1q_1,self.ip_1,self.as_1)
            else:
                (intf,dot1q,ip,asn) = (self.intf_2,self.dot1q_2,self.ip_2,self.as_2)
	    genericLib().robolog("\n<b><font face=\"verdana\" color=\"SaddleBrown\">Executing Configuration  commands on Device %s </b>" % dut, html = 1)
	    genericLib().robolog("\n<font face=\"verdana\" color=\"DarkMagenta\">Configuring Sub-Interface %s" % (intf), html = 1)
            config_cmd=obj.config_sub_interface(intf,dot1q)
            keys = sorted(config_cmd)
            for si in keys:
                config_si = self.dh.dut_command([dut],config_cmd[si])
            genericLib().robolog("\n<font face=\"verdana\" color=\"DarkMagenta\">Configuring ip address %s on sub-interface %s " % (ip,intf), html = 1)
            config_cmd=obj.config_ip_address(ip, self.mask, intf)
            keys = sorted(config_cmd)
            for ip in keys:
                config_ip = self.dh.dut_command([dut],config_cmd[ip])
            genericLib().robolog("\n<font face=\"verdana\" color=\"DarkMagenta\">Configuring BGP as number %s " % asn, html = 1)
            config_cmd=obj.config_bgp_router(asn)
            keys = sorted(config_cmd)
            for pid in keys:
                config_bgp_router_id = self.dh.dut_command([dut],config_cmd[pid])     
	    genericLib().robolog("\n<font face=\"verdana\" color=\"DarkMagenta\">Configuring Logging TimeStamp to Milli Seconds",html = 1)
            config_cmd=obj.config_logging_timestamp('milliseconds')
            keys = sorted(config_cmd)
            for log in keys:
                config_logging_timestamp = self.dh.dut_command([dut],config_cmd[log])	    
        genericLib().robolog("\n<font face=\"verdana\" color=\"DarkMagenta\">Configuring BGP neighbor %s on Device %s " % (self.ip_2, duts[0]), html = 1)
        config_cmd1=obj.config_bgp_neighbor(self.as_1,self.as_2,self.ip_2,self.desc_2,self.intf_1)
        keys = sorted(config_cmd1)
        for ngbhr in keys:
            config_bgp_nghbr = self.dh.dut_command([duts[0]],config_cmd1[ngbhr])
        genericLib().robolog("\n<font face=\"verdana\" color=\"DarkMagenta\">Configuring BGP neighbor %s on Device %s " % (self.ip_1, duts[1]), html = 1)
        config_cmd2=obj.config_bgp_neighbor(self.as_2,self.as_1,self.ip_1,self.desc_1,self.intf_2)
        keys = sorted(config_cmd2)
        for ngbhr in keys:
            config_bgp_nghbr = self.dh.dut_command([duts[1]],config_cmd2[ngbhr])                 

#################### verification of bfd status on both devices ############################

	genericLib().robolog("\nwaiting for 40 seconds to form BFD neighbors between the Devices")
	time.sleep(40)       
	genericLib().robolog("\n<font face=\"verdana\" color=\"SaddleBrown\">Executing below show commands just for debugging purpose. Not verifying anyhting in the command output", html = 1)
        for dut in self.dutall:
            bgp_summary  = self.dh.dut_command([dut],"show ip bgp summary")
            Interface_Brief  = self.dh.dut_command([dut],"show ip interface brief")
        for dut in self.dutall:
            if dut == duts[0]:
                intf = self.intf_1
            else:
                intf = self.intf_2
            genericLib().robolog("\n<b><font face=\"verdana\" color=\"SaddleBrown\">Parsing and Verifying Configuration in %s command output on Device %s </b>" % (self.shbfd,dut), html = 1)
            genericLib().robolog("\n<font face=\"verdana\" color=\"DarkMagenta\">Parsing %s output" % self.shbfd, html = 1)
            bfd_nghbrs_out = self.dh.dut_command([dut],self.shbfd)
            self.parseresult = obj1.parse_cmd(dut,'show bfd neighbors',bfd_nghbrs_out)                
            if self.parseresult[0]:
                genericLib().robolog("\n<b><font face=\"verdana\" color=\"green\">Command %s output  parsing successful \n </b>" % self.shbfd, html = 1)
                genericLib().robolog("\n<font face=\"verdana\" color=\"DarkMagenta\">Verifying %s output  for BFD neighborship status UP on sub-interface %s " % (self.shbfd, intf), html = 1)
                self.verifyresult = Verifications().verify_show_bfd_neighbors(self.parseresult,intf,'Up')
                if self.verifyresult:
                    genericLib().robolog("\n<b><font face=\"verdana\" color=\"green\">Command %s output verification success: BFD status is 'UP' on sub-interface %s as expected </b>" % (self.shbfd,intf), html = 1)
                else:
                    genericLib().robolog("\n<b><font face=\"verdana\" color=\"red\">FAIL: Command %s output verification failed: BFD neighborship is not 'UP' on sub-interface %s </b>" % (self.shbfd,intf), html = 1)
                    self.failed_steps_count+=1
            else:
                genericLib().robolog("\n<b><font face=\"verdana\" color=\"red\">FAIL: Parsing %s output failed </b>" % self.shbfd, html = 1)
                self.failed_steps_count+=1                    
            if self.failed_steps_count:
                BuiltIn().run_keyword_and_continue_on_failure("fail",(str(self.failed_steps_count))+" test steps failed")    

####################### Shutting Down sub-interface on Device_1 and expecting bfd neighborship to go  down ############
                    
        genericLib().robolog("\n<b><font face=\"verdana\" color=\"blue\">Section-63.1: Performing sub-interfaces shutdown  on Device %s and Expecting BFD neighborship to do Down</b>" % duts[0], html = 1)
	time_diff = 0
	diff_time = 0
	show_clock_out = self.dh.dut_command([duts[0]],self.shclk)
	sys_clock_parser = obj1.parse_cmd(duts[0],'show clock',show_clock_out)
	sys_time = sys_clock_parser[1]['clock_out']['time']		
	systime = re.search(r'([\d]+)\:([\d]+)\:([\d]+)\.([\d]+)',sys_time).groups()
	sys_hrs,sys_min,sys_sec,sys_msec = int(systime[0]),int(systime[1]),int(systime[2]),int(systime[3])
	sys_clock_total_milli_seconds = (sys_hrs*3600000)+(sys_min*60000)+(sys_sec*1000)+(sys_msec)				
	genericLib().robolog("\n<font face=\"verdana\" color=\"DarkMagenta\">Shutting down sub-interface %s" % (self.intf_1), html = 1)
        config_cmd1=obj.shutdown_interface(self.intf_1,'shut')
        keys = sorted(config_cmd1)
        for intf in keys:
            interface_shutdown = self.dh.dut_command([duts[0]],config_cmd1[intf])
            time.sleep(5)
	shintf = '\nshow interface id'
	shintf = shintf.replace('id',self.intf_1)
	shintf_out = self.dh.dut_command([duts[0]],shintf)
	show_logging_out = self.dh.dut_command([duts[0]],self.shlgng,timeout = 60) 	
	show_loggign_out_parser = obj1.parse_cmd(dut,'show logging',show_logging_out)
	logs = show_loggign_out_parser[1]['Log']
	for log in logs:
	    if re.search(r'BFD-(\d+)-SESSION_STATE_DOWN',log) != None:
		if self.ip_2 in log: 
		    if re.search(r'([\d]+)\:([\d]+)\:([\d]+)\.([\d]+)',log) != None:
	                bfd_down_time = re.search(r'([\d]+)\:([\d]+)\:([\d]+)\.([\d]+)', log).groups()
		        bfd_hrs,bfd_min,bfd_sec,bfd_msec = int(bfd_down_time[0]), int(bfd_down_time[1]),int(bfd_down_time[2]), int(bfd_down_time[3])
		        bfd_down_total_milli_seconds = (bfd_hrs*3600000)+(bfd_min*60000)+(bfd_sec*1000)+(bfd_msec)
	                time_diff = (bfd_down_total_milli_seconds - sys_clock_total_milli_seconds)
	    if re.search(r'BFD-(\d+)-SESSION_REMOVED',log) != None:
		if self.ip_2 in log: 
		    if re.search(r'([\d]+)\:([\d]+)\:([\d]+)\.([\d]+)',log) != None:
	                bfd_removed_time = re.search(r'([\d]+)\:([\d]+)\:([\d]+)\.([\d]+)',log).groups()
		        bfd_hrs,bfd_min,bfd_sec,bfd_msec = int(bfd_removed_time[0]), int(bfd_removed_time[1]),int(bfd_removed_time[2]), int(bfd_removed_time[3])
		        bfd_down_total_milli_seconds = (bfd_hrs*3600000)+(bfd_min*60000)+(bfd_sec*1000)+(bfd_msec)
	                diff_time = (bfd_down_total_milli_seconds - sys_clock_total_milli_seconds)
	genericLib().robolog("\ntime taken by  bfd to detect link  down  when physical link administratively shutdown is %s milli seconds " % time_diff, html = 1)
	if (time_diff > 1000 or time_diff <= 0):
	    genericLib().robolog("\n<b><font face=\"verdana\" color=\"red\">FAIL: BFD not detected link  down within 1 sec, when the sub-interface %s administratively shutdown <\b>" % self.intf_1, html = 1 )
	    self.failed_steps_count+=1
        else:
	    genericLib().robolog("\n<b><font face=\"verdana\" color=\"green\">BFD-SESSION Down event Logged within 1 sec of sub-interface link %s down, as expected </b>" % self.intf_1, html = 1)	
	for dut in self.dutall:
            if dut == duts[0]:
                intf = self.intf_1
            else:
                intf = self.intf_2
            genericLib().robolog("\n<b><font face=\"verdana\" color=\"SaddleBrown\">Parsing and Verifying %s command output on Device %s for BFD entry status on sub-interface %s </b>" % (self.shbfd,dut, intf), html = 1)
            genericLib().robolog("\n<font face=\"verdana\" color=\"DarkMagenta\">Parsing %s output" % self.shbfd, html = 1)
            bfd_nghbr_out = self.dh.dut_command([dut],self.shbfd)
            self.parseresult = obj1.parse_cmd(dut,'show bfd neighbors',bfd_nghbr_out)                
            if self.parseresult[0]:
                genericLib().robolog("\n<font face=\"verdana\" color=\"green\">Command %s output  parsing successful " % self.shbfd, html = 1)
                genericLib().robolog("\n<font face=\"verdana\" color=\"DarkMagenta\">Verifying %s output  for BFD neighborship status Down on sub-interface %s " % (self.shbfd, intf), html = 1)
                self.verifyresult = Verifications().verify_show_bfd_neighbors(self.parseresult,intf,'Down')
                if self.verifyresult:
                    genericLib().robolog("\n<font face=\"verdana\" color=\"green\">Command %s output verification success: BFD status is 'Down' on sub-interface %s as expected after shutting Down the Interface </b>" % (self.shbfd,intf), html = 1)
		    if dut == duts[0]:
			genericLib().robolog("\nTime taken to bfd entry go down after shutting down the sub-interface is %s milli seconds" % diff_time, html = 1)
                else:
                    genericLib().robolog("\n<b><font face=\"verdana\" color=\"red\">FAIL: Command %s output verification failed: BFD neighborship is not 'Down' even after shutting Down the sub-interafce %s </b>" % (self.shbfd,intf), html = 1)
                    self.failed_steps_count+=1
            else:
                genericLib().robolog("\n<b><font face=\"verdana\" color=\"red\">FAIL: Parsing %s output failed </b>" % self.shbfd, html = 1)
                self.failed_steps_count+=1                    
            if self.failed_steps_count:
                BuiltIn().run_keyword_and_continue_on_failure("fail",(str(self.failed_steps_count))+" test steps failed") 

####################### No Shutting Donw sub-interface on Device_1 and expecting bfd neighborship to Retain ############                    

        genericLib().robolog("\n<b><font face=\"verdana\" color=\"blue\">Section-63.3: Performing sub-interfaces No shutdown  on Device %s and Expecting BFD neighborship to Retain</b>" % duts[0], html = 1)
        genericLib().robolog("\n<font face=\"verdana\" color=\"DarkMagenta\">No Shutting down sub-interface %s " % (self.intf_1), html = 1)
        config_cmd1=obj.shutdown_interface(self.intf_1,'no shut')
        keys = sorted(config_cmd1)
        for intf in keys:
            no_shutdown_intf = self.dh.dut_command([duts[0]],config_cmd1[intf])
        genericLib().robolog("\nwaiting for 60 sec to verify bfd neighborship after the sub-interface no shutdown") 
        time.sleep(60)
	shintf_out = self.dh.dut_command([duts[0]],shintf)
        for dut in self.dutall:
            if dut == duts[0]:
                intf = self.intf_1
            else:
                intf = self.intf_2
            genericLib().robolog("\n<b><font face=\"verdana\" color=\"SaddleBrown\">Parsing and Verifying %s command output on Device %s for BFD entry status on sub-interface %s </b>" % (self.shbfd,dut, intf), html = 1)
            genericLib().robolog("\n<font face=\"verdana\" color=\"DarkMagenta\">Parsing %s output" % self.shbfd, html = 1)
            bfd_nghbrs_out = self.dh.dut_command([dut],self.shbfd)
            self.parseresult = obj1.parse_cmd(dut,'show bfd neighbors',bfd_nghbrs_out)                
            if self.parseresult[0]:
                genericLib().robolog("\n<font face=\"verdana\" color=\"green\">Command %s output  parsing successful " % self.shbfd, html = 1)
	        genericLib().robolog("\n<font face=\"verdana\" color=\"DarkMagenta\">Verifying %s output  for BFD neighborship status Up on sub-interface %s " % (self.shbfd, intf), html = 1)
                self.verifyresult = Verifications().verify_show_bfd_neighbors(self.parseresult,intf,'Up')
	        if self.verifyresult:
                    genericLib().robolog("\n<font face=\"verdana\" color=\"green\">Command %s output verification success: BFD status is 'Up' on sub-interface %s as expected when the Interface is No Shutdown" % (self.shbfd,intf), html = 1)
                else:
                    genericLib().robolog("\n<b><font face=\"verdana\" color=\"red\">FAIL: Command %s output verification failed: BFD neighborship is not 'Up' on sub-interface %s after No shutdown it </b>" % (self.shbfd,intf), html = 1)
                    self.failed_steps_count+=1
            else:
                genericLib().robolog("\n<b><font face=\"verdana\" color=\"red\">FAIL: Parsing %s output failed </b>" % self.shbfd, html = 1)
                self.failed_steps_count+=1                    
            if self.failed_steps_count:
                BuiltIn().run_keyword_and_continue_on_failure("fail",(str(self.failed_steps_count))+" test steps failed") 

############################### Configuring Fake ip on sub-interface on Deive_1 and  expecting Bfd neighbor entry to go  down ##############

        genericLib().robolog("\n<b><font face=\"verdana\" color=\"blue\">Section-63.4: Configuring fake ip address  on  sub-interface %s on device %s and expecting the BFD neighborship  to go down</b>" % (self.intf_1,duts[0]), html = 1)
        genericLib().robolog("\n<font face=\"verdana\" color=\"DarkMagenta\">configuring fake ip %s address on sub-interface %s " % (self.fake_ip,self.intf_1), html = 1)
	time_diff = 0
	diff_time = 0
	show_clock_out = self.dh.dut_command([duts[0]],self.shclk)
        sys_clock_parser = obj1.parse_cmd(duts[0],'show clock',show_clock_out)
        sys_time = sys_clock_parser[1]['clock_out']['time']
        systime = re.search(r'([\d]+)\:([\d]+)\:([\d]+)\.([\d]+)',sys_time).groups()
        sys_hrs,sys_min,sys_sec,sys_msec = int(systime[0]),int(systime[1]),int(systime[2]),int(systime[3])
        sys_clock_total_milli_seconds = (sys_hrs*3600000)+(sys_min*60000)+(sys_sec*1000)+(sys_msec)
	config_cmd1=obj.config_ip_address(self.fake_ip, self.mask, self.intf_1)
        keys = sorted(config_cmd1)
        for ip in keys:
            config_fake_ip = self.dh.dut_command([duts[0]],config_cmd1[ip])
	time.sleep(5)
	shipintfbrf = self.dh.dut_command([duts[0]],'show ip interface brief') 
        show_logging_out = self.dh.dut_command([duts[0]],self.shlgng,timeout = 60)
        show_loggign_out_parser = obj1.parse_cmd(dut,'show logging',show_logging_out)
        logs = show_loggign_out_parser[1]['Log']
        for log in logs:
            if re.search(r'BFD-(\d+)-SESSION_STATE_DOWN',log) != None:
                if self.ip_2 in log: 
		    if re.search(r'([\d]+)\:([\d]+)\:([\d]+)\.([\d]+)',log) != None:
	                bfd_down_time = re.search(r'([\d]+)\:([\d]+)\:([\d]+)\.([\d]+)', log).groups()
		        bfd_hrs,bfd_min,bfd_sec,bfd_msec = int(bfd_down_time[0]), int(bfd_down_time[1]),int(bfd_down_time[2]), int(bfd_down_time[3])
		        bfd_down_total_milli_seconds = (bfd_hrs*3600000)+(bfd_min*60000)+(bfd_sec*1000)+(bfd_msec)
	                time_diff = (bfd_down_total_milli_seconds - sys_clock_total_milli_seconds)
	    if re.search(r'BFD-(\d+)-SESSION_REMOVED',log) != None:
		if self.ip_2 in log: 
		    if re.search(r'([\d]+)\:([\d]+)\:([\d]+)\.([\d]+)',log) != None:
	                bfd_removed_time = re.search(r'([\d]+)\:([\d]+)\:([\d]+)\.([\d]+)',log).groups()
		        bfd_hrs,bfd_min,bfd_sec,bfd_msec = int(bfd_removed_time[0]), int(bfd_removed_time[1]),int(bfd_removed_time[2]), int(bfd_removed_time[3])
		        bfd_removed_total_milli_seconds = (bfd_hrs*3600000)+(bfd_min*60000)+(bfd_sec*1000)+(bfd_msec)
	                diff_time = (bfd_removed_total_milli_seconds - sys_clock_total_milli_seconds)
        #genericLib().robolog("\n <font face=\"verdana\" color=\"DarkMagenta\"> system time is %s and bfd-session down time is %s" % (systime,bfd_down_time), html = 1)
        genericLib().robolog("\ntime taken to  bfd to go down when fake ip configured on sub-interface is %s milli seconds " % time_diff, html = 1)
        #if (time_diff > 1000 or time_diff <= 0):
         #   genericLib().robolog("\n<b><font face=\"verdana\" color=\"red\">FAIL: BFD Session Down event not logged within 1 sec when fake ip configured on sub-interafce<\b>", html = 1 )
          #  self.failed_steps_count+=1
        #else:
        genericLib().robolog("\n<font face=\"verdana\" color=\"green\">BFD-SESSION Down event logged within 1 sec when fake ip configured on sub-interface ,as expected" , html = 1)
        for dut in self.dutall:
            if dut == duts[0]:
                intf = self.intf_1
            else:
                intf = self.intf_2
            genericLib().robolog("\n<b><font face=\"verdana\" color=\"SaddleBrown\">Parsing and Verifying %s output on Device %s after configuring Fake ip on sub-interface </b>" % (self.shbfd, dut), html = 1)
            genericLib().robolog("\n<font face=\"verdana\" color=\"DarkMagenta\">Parsing %s output " % self.shbfd, html = 1)
            bfd_nghbrs_out = self.dh.dut_command([dut],self.shbfd)
            self.parseresult = obj1.parse_cmd(dut,'show bfd neighbors',bfd_nghbrs_out)
            if self.parseresult[0]:
                genericLib().robolog("\n<font face=\"verdana\" color=\"green\">Command %s output parsing successful " % self.shbfd , html = 1)
                genericLib().robolog("\n<font face=\"verdana\" color=\"DarkMagenta\">Verifying %s output for BFD neighborship to go Down on sub-interface %s" % (self.shbfd, intf), html = 1)
                self.verifyresult = Verifications().verify_show_bfd_neighbors(self.parseresult,intf,'Down')
                if self.verifyresult:
                    genericLib().robolog("\n<font face=\"verdana\" color=\"green\">Command %s output verification success: BFD neighborship goes Down  on sub-interface %s after configuring Fake Ip on it" % (self.shbfd,intf), html = 1)
		    if dut == duts[0]:
			genericLib().robolog("\nTime taken to remove bfd entry after configuring fake ip is %s milli seconds" % diff_time, html = 1)
                else:
                    genericLib().robolog("\n<font face=\"verdana\" color=\"red\">FAIL: Command %s output verification failed: BFD neighborship not goes Down on sub-interface %s even after configuring Fake ip on it" % (self.shbfd, intf), html = 1)
                    self.failed_steps_count+=1
            else:
                genericLib().robolog("*\n<font face=\"verdana\" color=\"red\">FAIL: Parsing %s output failed" % self.shbfd, html = 1)
                self.failed_steps_count+=1
            if self.failed_steps_count:
                BuiltIn().run_keyword_and_continue_on_failure("fail",(str(self.failed_steps_count))+" test steps failed")

############################### Re-configruing original  ip and expecting bfd neighborship to  retain on sub-interface ######################

        genericLib().robolog("\n<b><font face=\"verdana\" color=\"blue\">Section-63.5: Re-Configuring Original ip address on sub-interface %s  on device %s  and Expecting BFD neighborship Retains on Both Devices</b>" % (self.intf_1,duts[0]), html = 1)
        genericLib().robolog("\n<font face=\"verdana\" color=\"DarkMagenta\">Configuring Origonal ip address %s on sub-interface %s on device %s " % (self.ip_1,self.intf_1,duts[0]), html = 1)
        config_cmd1=obj.config_ip_address(self.ip_1, self.mask, self.intf_1)
        keys = sorted(config_cmd1)
        for ip in keys:
            config_ip = self.dh.dut_command([duts[0]],config_cmd1[ip])
        genericLib().robolog ("\nwaiting for 40 seconds to retian BFD neighborship after original ip configured")
        time.sleep(40)
	shipintfbrf = self.dh.dut_command([duts[0]],'show ip interface brief')
        for dut in self.dutall:
            if dut == duts[0]:
                intf = self.intf_1
            else:
                intf = self.intf_2            
            genericLib().robolog("\n<b><font face=\"verdana\" color=\"SaddleBrown\">Parsing and Verifying %s output on device %s after Re-Configuring Original ip on sub-interface of Device %s </b>" % (self.shbfd, dut, duts[0]), html = 1)
            genericLib().robolog("\n<font face=\"verdana\" color=\"DarkMagenta\">Parsing %s output" % (self.shbfd), html=1) 
            bfd_nghbrs_out = self.dh.dut_command([dut],self.shbfd)
            self.parseresult = obj1.parse_cmd(dut,'show bfd neighbors',bfd_nghbrs_out)                
            if self.parseresult[0]:
                genericLib().robolog("\n<font face=\"verdana\" color=\"green\">Command %s output parsing successful on device %s " % (self.shbfd, dut), html = 1)
                genericLib().robolog("\n<font face=\"verdana\" color=\"DarkMagenta\">Verifying %s output for BFD neighborship to retain on sub-interface %s after configuring original ip address" % (self.shbfd,intf), html = 1)
                self.verifyresult = Verifications().verify_show_bfd_neighbors(self.parseresult,intf, 'Up')
                if self.verifyresult:
                    genericLib().robolog("\n<font face=\"verdana\" color=\"green\">Command %s output verification success: BFD neighborship retained on sub-interface %s after configuring original ip address " % (self.shbfd, intf), html = 1)
                else:
                    genericLib().robolog("\n<font face=\"verdana\" color=\"red\">FAIL: Command %s output verification failed: BFD neighborship not retained on sub-interface %s even after configuring original ip address " % (self.shbfd,intf), html = 1)
                    self.failed_steps_count+=1
            else:
                genericLib().robolog("\n<font face=\"verdana\" color=\"red\">FAIL: Parsing %s output failed " % self.shbfd, html = 1)
                self.failed_steps_count+=1                    
            if self.failed_steps_count:
            	BuiltIn().run_keyword_and_continue_on_failure("fail",(str(self.failed_steps_count))+" test steps failed")

###################################  UNCONFIGURING PART  ###########################################

    def cleanup(self):
	duts = self.dutall
        genericLib().robolog("\n<b><font face=\"verdana\" color=\"blue\">Step-6: UnConfiguring the configuration done as part of this test case on both Devices  </b>", html = 1)
	obj=Tip_N3k_Basic_Unconfig()
	obj1=Tip_N3k_Basic_Config()
	genericLib().robolog("\n<font face=\"verdana\" color=\"DarkMagenta\">Removing BGP neighbor %s on Device %s" % (self.ip_2, duts[0]), html = 1)
        config_cmd1=obj.remove_bgp_neighbor(self.as_1,self.as_2,self.ip_2)
        keys = sorted(config_cmd1)
        for ngbhr in keys:
            remove_bgp_nghbr = self.dh.dut_command([duts[0]],config_cmd1[ngbhr])
	nobgp = 'config\nno router bgp id\nend'
	nobgp1 = nobgp.replace('id',self.as_1)
	remove_bgp = self.dh.dut_command([duts[0]],nobgp1)
        genericLib().robolog("\n<font face=\"verdana\" color=\"DarkMagenta\">Removing BGP neighbor %s on Device %s" % (self.ip_1, duts[1]), html = 1)
        config_cmd2=obj.remove_bgp_neighbor(self.as_2,self.as_1,self.ip_1)
        keys = sorted(config_cmd2)
        for ngbhr in keys:
            remove_bgp_nghbr = self.dh.dut_command([duts[1]],config_cmd2[ngbhr])
        nobgp2 = nobgp.replace('id',self.as_2)
        remove_bgp = self.dh.dut_command([duts[1]],nobgp2)
        for dut in self.dutall:
            if dut == self.dutall[0]:
                (intf,ip) = (self.intf_1,self.ip_1)
            else:
                (intf,ip) = (self.intf_2,self.ip_2)		
            genericLib().robolog("\n<b><font face=\"verdana\" color=\"SaddleBrown\">Removing Configuration on Device %s </b>" % dut, html = 1 )
	    genericLib().robolog("\n<font face=\"verdana\" color=\"DarkMagenta\">Removing ip address %s on sub-interface %s " % (ip,intf), html = 1)
            config_cmd=obj.delete_ip_address(intf)
            keys = sorted(config_cmd)
            for ip in keys:
                delete_ip = self.dh.dut_command([dut],config_cmd[ip])      
	    genericLib().robolog("\n<font face=\"verdana\" color=\"DarkMagenta\">Setting logging timestamp config to default seconds ", html = 1)
            config_cmd=obj1.config_logging_timestamp('seconds')
            keys = sorted(config_cmd)
            for log in keys:
                config_timestamp = self.dh.dut_command([dut],config_cmd[log])
	    bfd_nghbrs_out = self.dh.dut_command([dut],self.shbfd)
        genericLib().robolog("\nSuccesfully executed \'63.0 BFD - SUB Interface\' test case",html=1, console=1)

##**************************************************************************************************
class Testcases(object):      

    def testcase1_initialize(self):
        tcobject = Tip_N3k_Bfd_Svi_00001()
        tcobject.id = BuiltIn().get_variable_value('${Testcases.Testcase1.id}')
	tcobject.shbfd = BuiltIn().get_variable_value('${Testcases.Testcase1.shbfd}')
	tcobject.shclk = BuiltIn().get_variable_value('${Testcases.Testcase1.shclk}')
        tcobject.shlgng = BuiltIn().get_variable_value('${Testcases.Testcase1.shlgng}')
        tcobject.vlan_1 = BuiltIn().get_variable_value('${Testcases.Testcase1.vlan_1}')
	tcobject.vlan_2 = BuiltIn().get_variable_value('${Testcases.Testcase1.vlan_2}')
	tcobject.mode = BuiltIn().get_variable_value('${Testcases.Testcase1.mode}')
        tcobject.ip_1 = BuiltIn().get_variable_value('${Testcases.Testcase1.ip_1}')
        tcobject.ip_2 = BuiltIn().get_variable_value('${Testcases.Testcase1.ip_2}')
        tcobject.mask = BuiltIn().get_variable_value('${Testcases.Testcase1.mask}')
	tcobject.port_1 = BuiltIn().get_variable_value('${Testcases.Testcase1.port_1}')
	tcobject.port_2 = BuiltIn().get_variable_value('${Testcases.Testcase1.port_2}')
	tcobject.intf_1 = BuiltIn().get_variable_value('${Testcases.Testcase1.intf_1}')
	tcobject.intf_2 = BuiltIn().get_variable_value('${Testcases.Testcase1.intf_2}')
	tcobject.as_1 = BuiltIn().get_variable_value('${Testcases.Testcase1.as_1}')
	tcobject.as_2 = BuiltIn().get_variable_value('${Testcases.Testcase1.as_2}')
	tcobject.desc_1 = BuiltIn().get_variable_value('${Testcases.Testcase1.desc_1}')
	tcobject.desc_2 = BuiltIn().get_variable_value('${Testcases.Testcase1.desc_2}')
	tcobject.fake_ip = BuiltIn().get_variable_value('${Testcases.Testcase1.fake_ip}')	
	tcobject.sleep = BuiltIn().get_variable_value('${Testcases.Testcase1.sleep}')
        tcobject.dutall = BuiltIn().get_variable_value('${Common.DeviceList}')
        tcobject.dh = BuiltIn().get_variable_value('${dutobj}')
        return tcobject
    
    def testcase2_initialize(self):
        tcobject = Bfd_Port_Channel_61_0()
        tcobject.id = BuiltIn().get_variable_value('${Testcases.Testcase2.id}')
	tcobject.shbfd = BuiltIn().get_variable_value('${Testcases.Testcase2.shbfd}')
	tcobject.shclk = BuiltIn().get_variable_value('${Testcases.Testcase2.shclk}')
	tcobject.shlgng = BuiltIn().get_variable_value('${Testcases.Testcase2.shlgng}')
        tcobject.ip_1 = BuiltIn().get_variable_value('${Testcases.Testcase2.ip_1}')
        tcobject.ip_2 = BuiltIn().get_variable_value('${Testcases.Testcase2.ip_2}')
        tcobject.mask = BuiltIn().get_variable_value('${Testcases.Testcase2.mask}')
	tcobject.port_1 = BuiltIn().get_variable_value('${Testcases.Testcase2.port_1}')
	tcobject.port_2 = BuiltIn().get_variable_value('${Testcases.Testcase2.port_2}')
	tcobject.pcid_1 = BuiltIn().get_variable_value('${Testcases.Testcase2.pcid_1}')
	tcobject.pcid_2 = BuiltIn().get_variable_value('${Testcases.Testcase2.pcid_2}')
	tcobject.as_1 = BuiltIn().get_variable_value('${Testcases.Testcase2.as_1}')
	tcobject.as_2 = BuiltIn().get_variable_value('${Testcases.Testcase2.as_2}')
	tcobject.desc_1 = BuiltIn().get_variable_value('${Testcases.Testcase2.desc_1}')
	tcobject.desc_2 = BuiltIn().get_variable_value('${Testcases.Testcase2.desc_2}')
	tcobject.fake_ip = BuiltIn().get_variable_value('${Testcases.Testcase2.fake_ip}')	
	tcobject.sleep = BuiltIn().get_variable_value('${Testcases.Testcase2.sleep}')
        tcobject.dutall = BuiltIn().get_variable_value('${Common.DeviceList}')
        tcobject.dh = BuiltIn().get_variable_value('${dutobj}')
        return tcobject
	
    def testcase3_initialize(self):
        tcobject = Bfd_Physical_Interface_60_0()
        tcobject.id = BuiltIn().get_variable_value('${Testcases.Testcase3.id}')
	tcobject.shbfd = BuiltIn().get_variable_value('${Testcases.Testcase3.shbfd}')
	tcobject.shclk = BuiltIn().get_variable_value('${Testcases.Testcase3.shclk}')
	tcobject.shlgng = BuiltIn().get_variable_value('${Testcases.Testcase3.shlgng}')
        tcobject.ip_1 = BuiltIn().get_variable_value('${Testcases.Testcase3.ip_1}')
        tcobject.ip_2 = BuiltIn().get_variable_value('${Testcases.Testcase3.ip_2}')
        tcobject.mask = BuiltIn().get_variable_value('${Testcases.Testcase3.mask}')
	tcobject.intf_1 = BuiltIn().get_variable_value('${Testcases.Testcase3.intf_1}')
	tcobject.intf_2 = BuiltIn().get_variable_value('${Testcases.Testcase3.intf_2}')
	tcobject.as_1 = BuiltIn().get_variable_value('${Testcases.Testcase3.as_1}')
	tcobject.as_2 = BuiltIn().get_variable_value('${Testcases.Testcase3.as_2}')
	tcobject.desc_1 = BuiltIn().get_variable_value('${Testcases.Testcase3.desc_1}')
	tcobject.desc_2 = BuiltIn().get_variable_value('${Testcases.Testcase3.desc_2}')
	tcobject.fake_ip = BuiltIn().get_variable_value('${Testcases.Testcase3.fake_ip}')	
	tcobject.sleep = BuiltIn().get_variable_value('${Testcases.Testcase3.sleep}')
        tcobject.dutall = BuiltIn().get_variable_value('${Common.DeviceList}')
        tcobject.dh = BuiltIn().get_variable_value('${dutobj}')
        return tcobject

    def testcase4_initialize(self):
        tcobject = Bfd_Sub_Interface_63_0()
        tcobject.id = BuiltIn().get_variable_value('${Testcases.Testcase4.id}')
	tcobject.shbfd = BuiltIn().get_variable_value('${Testcases.Testcase4.shbfd}')
	tcobject.shclk = BuiltIn().get_variable_value('${Testcases.Testcase4.shclk}')
	tcobject.shlgng = BuiltIn().get_variable_value('${Testcases.Testcase4.shlgng}')
        tcobject.ip_1 = BuiltIn().get_variable_value('${Testcases.Testcase4.ip_1}')
        tcobject.ip_2 = BuiltIn().get_variable_value('${Testcases.Testcase4.ip_2}')
        tcobject.mask = BuiltIn().get_variable_value('${Testcases.Testcase4.mask}')
	tcobject.intf_1 = BuiltIn().get_variable_value('${Testcases.Testcase4.intf_1}')
	tcobject.intf_2 = BuiltIn().get_variable_value('${Testcases.Testcase4.intf_2}')
	tcobject.dot1q_1 = BuiltIn().get_variable_value('${Testcases.Testcase4.dot1q_1}')
	tcobject.dot1q_2 = BuiltIn().get_variable_value('${Testcases.Testcase4.dot1q_2}')
	tcobject.as_1 = BuiltIn().get_variable_value('${Testcases.Testcase4.as_1}')
	tcobject.as_2 = BuiltIn().get_variable_value('${Testcases.Testcase4.as_2}')
	tcobject.desc_1 = BuiltIn().get_variable_value('${Testcases.Testcase4.desc_1}')
	tcobject.desc_2 = BuiltIn().get_variable_value('${Testcases.Testcase4.desc_2}')
	tcobject.fake_ip = BuiltIn().get_variable_value('${Testcases.Testcase4.fake_ip}')	
	tcobject.sleep = BuiltIn().get_variable_value('${Testcases.Testcase4.sleep}')
        tcobject.dutall = BuiltIn().get_variable_value('${Common.DeviceList}')
        tcobject.dh = BuiltIn().get_variable_value('${dutobj}')
        return tcobject
    
    def testcase_setup(self,tcobj):
	tcobj.setup()

    def testcase_test(self,tcobj):
 	tcobj.test()

    def testcase_cleanup(self,tcobj):
 	tcobj.cleanup()

