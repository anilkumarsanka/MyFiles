class variableLib():
        def __init__(self,dutsdetails):
                self.dutsdetails=dutsdetails
                self.dutslist=[]
                self.dutvariables()

	def __call__(self):
		self.dutvariables()

        def dutvariables(self):
		keys=self.dutsdetails.keys()
                for dut in keys:
       	                self.dutslist+=[dut]
               	        setattr(self,dut,self._dutvariables(dut,self.dutsdetails[dut],dut))

	def _dutvariables(self,dut,dutdetails,parentattr=""):
              self.dut=dut
              for attr in dutdetails.keys():
			newattr=attr if parentattr=="" else parentattr+"__"+attr
			#print "TYPE:",type(dutdetails[attr])
			#print "NEWATTR:",newattr
			if isinstance(dutdetails[attr],dict)!=True:
				#print "FINAL:",newattr
				#print "Newattr-Val",newattr,dutdetails[attr]
                       		setattr(self,newattr,dutdetails[attr])
			else:
				#print "One more round:",newattr
				self._dutvariables(dut,dutdetails[attr],newattr)
                
